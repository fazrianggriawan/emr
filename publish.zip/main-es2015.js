(self["webpackChunkiniapps"] = self["webpackChunkiniapps"] || []).push([["main"],{

/***/ 98255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ (function(module) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 98255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 90158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": function() { return /* binding */ AppRoutingModule; }
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _components_rikkes_rikkes_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/rikkes/rikkes.component */ 2304);
/* harmony import */ var _templates_login_login_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./templates/login/login.component */ 15710);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);





const routes = [
    { path: '', component: _templates_login_login_component__WEBPACK_IMPORTED_MODULE_1__.LoginComponent },
    { path: 'rikkes', component: _components_rikkes_rikkes_component__WEBPACK_IMPORTED_MODULE_0__.RikkesComponent },
    { path: 'medical_record', loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_modules_medical-record_medical-record_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./modules/medical-record/medical-record.module */ 47247)).then(m => m.MedicalRecordModule) },
    { path: 'registrasi', loadChildren: () => __webpack_require__.e(/*! import() */ "default-src_app_modules_registrasi_registrasi_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./modules/registrasi/registrasi.module */ 23757)).then(m => m.RegistrasiModule) },
    { path: 'rawatJalan', loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_modules_registrasi_registrasi_module_ts"), __webpack_require__.e("src_app_modules_rawat-jalan_rawat-jalan_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modules/rawat-jalan/rawat-jalan.module */ 10225)).then(m => m.RawatJalanModule) },
    { path: 'kasir', loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_modules_kasir_kasir_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./modules/kasir/kasir.module */ 86050)).then(m => m.KasirModule) },
    { path: 'farmasi', loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_modules_farmasi_farmasi_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./modules/farmasi/farmasi.module */ 26701)).then(m => m.FarmasiModule) }
    // { path: 'subjective', component: SubjectiveComponent },
    // { path: 'diagnosa_prosedur', component: DiagnosaComponent },
    // { path: 'plan', component: PlanComponent },
    // { path: 'pemeriksaan', component: PemeriksaanComponent },
    // { path: 'order', component: OrderComponent },
    // { path: 'form-order', component: FormOrderComponent },
    // { path: 'urologi', component: UrologiComponent },
    // { path: 'pasien', component: PasienComponent },
    // { path: 'cppt', component: CpptFormComponent },
    // { path: 'pengkajian_awal_medis', component: PengkajianAwalWatlanComponent },
    // { path: 'bukti_pelayanan_tindakan', component: BuktiPelayananTindakanComponent },
    // { path: 'hasil_usg_urologi', component: HasilUsgUrologiComponent },
    // { path: 'lap_bedah_anest_lokal', component: LaporanBedahAnestesiLokalComponent },
    // { path: 'lap_pemantauan_anest_lokal', component: LaporanPemantauanTindakanAnestLokalComponent },
    // { path: 'surat_masuk_perawatan', component: SuratMasukPerawatanComponent },
    // { path: 'pengajuan_pembedahaan', component: PengajuanPembedahaanComponent },
    // { path: 'objective/objective_note', component: ObjectiveNoteComponent },
    // { path: 'assessment/tindakan', component: TindakanComponent },
    // { path: 'planning/test_order', component: TestOrderComponent },
    // { path: 'planning/rawat_bersama', component: RawatBersamaComponent },
    // { path: 'summary_discharge/disposisi_pasien', component: DisposisiPasienComponent },
    // { path: 'summary_discharge/medical_resume', component: MedicalResumeComponent },
    // { path: 'konva', component: KonvaComponent },
    // { path: 'header', component: HeaderRegistrasiComponent, outlet: 'header' },
    // { path: 'tablet/farmasi', component: TabletFarmasiComponent },
];
class AppRoutingModule {
}
AppRoutingModule.ɵfac = function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); };
AppRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled' })], _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule] }); })();


/***/ }),

/***/ 55041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": function() { return /* binding */ AppComponent; }
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/api */ 88055);
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/loading.service */ 4471);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _templates_menu_menu_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./templates/menu/menu.component */ 72462);
/* harmony import */ var _templates_menu_emr_menu_emr_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./templates/menu-emr/menu-emr.component */ 74905);
/* harmony import */ var primeng_progressspinner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/progressspinner */ 968);










function AppComponent_header_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "header", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "span", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "SIMRSMANDIRI");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, ".io");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "app-menu");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](10, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](11, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function AppComponent_app_menu_emr_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-menu-emr");
} }
function AppComponent_div_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "p-progressSpinner", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Loading...");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
class AppComponent {
    constructor(primeNgConfig, router, loadingService) {
        this.primeNgConfig = primeNgConfig;
        this.router = router;
        this.loadingService = loadingService;
        this.appVersionAttr = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.appVersion;
        this.title = 'iniapps';
        this.loading = false;
        this.currentRoute = '';
    }
    ngOnInit() {
        this.primeNgConfig.ripple = true;
        this.loadingService.status.subscribe(data => this.loading = data);
        this.router.events.subscribe(event => {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_5__.NavigationEnd) {
                // Hide progress spinner or progress bar
                this.currentRoute = event.url;
            }
        });
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_6__.PrimeNGConfig), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_loading_service__WEBPACK_IMPORTED_MODULE_1__.LoadingService)); };
AppComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], hostVars: 1, hostBindings: function AppComponent_HostBindings(rf, ctx) { if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵattribute"]("app-version", ctx.appVersionAttr);
    } }, decls: 9, vars: 5, consts: [["class", "navbar navbar-header navbar-header-fixed", 4, "ngIf"], [1, "content", "content-components", "p-4", "ml-0", "mr-0"], [1, "content", "p-0"], [1, "row", "justify-content-center"], [1, "col-10", "pb-3", "pt-0", 2, "background", "#f9f9f9"], [4, "ngIf"], ["class", "loading", 4, "ngIf"], [1, "navbar", "navbar-header", "navbar-header-fixed"], [1, "row"], [1, "col-auto"], [1, "p-pl-3", "p-pt-2"], [1, "df-logo", 2, "color", "white"], [2, "color", "#75bfff"], [1, "col-3"], [1, "col", "tx-right"], [1, "loading"], ["strokeWidth", "2"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](0, AppComponent_header_0_Template, 12, 0, "header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, AppComponent_app_menu_emr_5_Template, 1, 0, "app-menu-emr", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, AppComponent_div_7_Template, 4, 0, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](8, "async");
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.currentRoute != "/");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.currentRoute != "/");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](8, 3, ctx.loadingService.status));
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterOutlet, _templates_menu_menu_component__WEBPACK_IMPORTED_MODULE_2__.MenuComponent, _templates_menu_emr_menu_emr_component__WEBPACK_IMPORTED_MODULE_3__.MenuEmrComponent, primeng_progressspinner__WEBPACK_IMPORTED_MODULE_8__.ProgressSpinner], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.AsyncPipe], styles: [".content-components[_ngcontent-%COMP%] {\r\n    font-size: 14px;\r\n    padding: 0;\r\n    max-width: unset;\r\n}\r\n\r\n.content[_ngcontent-%COMP%] {\r\n    padding: 1rem;\r\n    padding-top: 0;\r\n}\r\n\r\n.loading-container[_ngcontent-%COMP%] {\r\n    position: fixed;\r\n    top: 20px;\r\n    left: 250px;\r\n    z-index: 9999;\r\n}\r\n\r\n.loading[_ngcontent-%COMP%] {\r\n    position: fixed;\r\n    width: 100%;\r\n    height: 100%;\r\n    top: 0;\r\n    left: 0;\r\n    background: rgba(255, 255, 255, 0.8);\r\n    z-index: 99999;\r\n    text-align: center;\r\n    padding-top: 20%;\r\n}\r\n\r\n.loading[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{\r\n    -webkit-animation: blinker 0.8s linear infinite;\r\n            animation: blinker 0.8s linear infinite;\r\n}\r\n\r\n@-webkit-keyframes blinker {\r\n    50% {\r\n      opacity: 0;\r\n    }\r\n  }\r\n\r\n@keyframes blinker {\r\n    50% {\r\n      opacity: 0;\r\n    }\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZUFBZTtJQUNmLFVBQVU7SUFDVixnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxhQUFhO0lBQ2IsY0FBYztBQUNsQjs7QUFFQTtJQUNJLGVBQWU7SUFDZixTQUFTO0lBQ1QsV0FBVztJQUNYLGFBQWE7QUFDakI7O0FBRUE7SUFDSSxlQUFlO0lBQ2YsV0FBVztJQUNYLFlBQVk7SUFDWixNQUFNO0lBQ04sT0FBTztJQUNQLG9DQUFvQztJQUNwQyxjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLCtDQUF1QztZQUF2Qyx1Q0FBdUM7QUFDM0M7O0FBRUE7SUFDSTtNQUNFLFVBQVU7SUFDWjtFQUNGOztBQUpGO0lBQ0k7TUFDRSxVQUFVO0lBQ1o7RUFDRiIsImZpbGUiOiJhcHAuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250ZW50LWNvbXBvbmVudHMge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIG1heC13aWR0aDogdW5zZXQ7XHJcbn1cclxuXHJcbi5jb250ZW50IHtcclxuICAgIHBhZGRpbmc6IDFyZW07XHJcbiAgICBwYWRkaW5nLXRvcDogMDtcclxufVxyXG5cclxuLmxvYWRpbmctY29udGFpbmVyIHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHRvcDogMjBweDtcclxuICAgIGxlZnQ6IDI1MHB4O1xyXG4gICAgei1pbmRleDogOTk5OTtcclxufVxyXG5cclxuLmxvYWRpbmcge1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjgpO1xyXG4gICAgei1pbmRleDogOTk5OTk7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwYWRkaW5nLXRvcDogMjAlO1xyXG59XHJcblxyXG4ubG9hZGluZyBkaXZ7XHJcbiAgICBhbmltYXRpb246IGJsaW5rZXIgMC44cyBsaW5lYXIgaW5maW5pdGU7XHJcbn1cclxuXHJcbkBrZXlmcmFtZXMgYmxpbmtlciB7XHJcbiAgICA1MCUge1xyXG4gICAgICBvcGFjaXR5OiAwO1xyXG4gICAgfVxyXG4gIH0iXX0= */"] });


/***/ }),

/***/ 36747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": function() { return /* binding */ AppModule; }
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/platform-browser */ 71570);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-routing.module */ 90158);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component */ 55041);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/platform-browser/animations */ 20718);
/* harmony import */ var ng_dicomviewer__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ng-dicomviewer */ 9919);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _templates_user_user_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./templates/user/user.component */ 44906);
/* harmony import */ var _templates_calendar_calendar_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./templates/calendar/calendar.component */ 66367);
/* harmony import */ var _templates_menu_menu_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./templates/menu/menu.component */ 72462);
/* harmony import */ var _templates_menu_emr_menu_emr_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./templates/menu-emr/menu-emr.component */ 74905);
/* harmony import */ var _templates_login_login_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./templates/login/login.component */ 15710);
/* harmony import */ var _providers_http_interceptor__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./providers/http.interceptor */ 57829);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/menu */ 63493);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/overlaypanel */ 59502);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/dropdown */ 14170);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var primeng_progressspinner__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/progressspinner */ 968);
/* harmony import */ var _components_rikkes_data_peserta_data_peserta_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/rikkes/data-peserta/data-peserta.component */ 33042);
/* harmony import */ var _components_rikkes_upload_file_upload_file_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/rikkes/upload-file/upload-file.component */ 84353);
/* harmony import */ var _components_rikkes_rikkes_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/rikkes/rikkes.component */ 2304);
/* harmony import */ var _modules_shared_shared_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./modules/shared/shared.module */ 72271);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/fileupload */ 81592);
/* harmony import */ var _components_rikkes_radiologi_radiologi_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/rikkes/radiologi/radiologi.component */ 54064);
/* harmony import */ var _components_rikkes_laboratorium_laboratorium_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./components/rikkes/laboratorium/laboratorium.component */ 82286);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 2316);


























class AppModule {
}
AppModule.ɵfac = function AppModule_Factory(t) { return new (t || AppModule)(); };
AppModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent] });
AppModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineInjector"]({ providers: [
        _angular_common__WEBPACK_IMPORTED_MODULE_15__.DatePipe,
        { provide: _angular_common__WEBPACK_IMPORTED_MODULE_15__.LocationStrategy, useClass: _angular_common__WEBPACK_IMPORTED_MODULE_15__.HashLocationStrategy },
        { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_16__.HTTP_INTERCEPTORS, useClass: _providers_http_interceptor__WEBPACK_IMPORTED_MODULE_7__.HttpProvider, multi: true },
        { provide: _providers_http_interceptor__WEBPACK_IMPORTED_MODULE_7__.DEFAULT_TIMEOUT, useValue: 50000 }
    ], imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_15__.CommonModule,
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__.BrowserModule,
            _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_16__.HttpClientModule,
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_18__.BrowserAnimationsModule,
            ng_dicomviewer__WEBPACK_IMPORTED_MODULE_19__.DicomViewerModule,
            primeng_menu__WEBPACK_IMPORTED_MODULE_20__.MenuModule,
            primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_21__.OverlayPanelModule,
            primeng_dropdown__WEBPACK_IMPORTED_MODULE_22__.DropdownModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_23__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_23__.ReactiveFormsModule,
            primeng_progressspinner__WEBPACK_IMPORTED_MODULE_24__.ProgressSpinnerModule,
            primeng_fileupload__WEBPACK_IMPORTED_MODULE_25__.FileUploadModule,
            _modules_shared_shared_module__WEBPACK_IMPORTED_MODULE_11__.SharedModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent,
        _templates_user_user_component__WEBPACK_IMPORTED_MODULE_2__.UserComponent,
        _templates_menu_emr_menu_emr_component__WEBPACK_IMPORTED_MODULE_5__.MenuEmrComponent,
        _templates_calendar_calendar_component__WEBPACK_IMPORTED_MODULE_3__.CalendarComponent,
        _templates_menu_menu_component__WEBPACK_IMPORTED_MODULE_4__.MenuComponent,
        _templates_login_login_component__WEBPACK_IMPORTED_MODULE_6__.LoginComponent,
        _components_rikkes_rikkes_component__WEBPACK_IMPORTED_MODULE_10__.RikkesComponent,
        _components_rikkes_data_peserta_data_peserta_component__WEBPACK_IMPORTED_MODULE_8__.DataPesertaComponent,
        _components_rikkes_upload_file_upload_file_component__WEBPACK_IMPORTED_MODULE_9__.UploadFileComponent,
        _components_rikkes_radiologi_radiologi_component__WEBPACK_IMPORTED_MODULE_12__.RadiologiComponent,
        _components_rikkes_laboratorium_laboratorium_component__WEBPACK_IMPORTED_MODULE_13__.LaboratoriumComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.CommonModule,
        _angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__.BrowserModule,
        _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule,
        _angular_common_http__WEBPACK_IMPORTED_MODULE_16__.HttpClientModule,
        _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_18__.BrowserAnimationsModule,
        ng_dicomviewer__WEBPACK_IMPORTED_MODULE_19__.DicomViewerModule,
        primeng_menu__WEBPACK_IMPORTED_MODULE_20__.MenuModule,
        primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_21__.OverlayPanelModule,
        primeng_dropdown__WEBPACK_IMPORTED_MODULE_22__.DropdownModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_23__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_23__.ReactiveFormsModule,
        primeng_progressspinner__WEBPACK_IMPORTED_MODULE_24__.ProgressSpinnerModule,
        primeng_fileupload__WEBPACK_IMPORTED_MODULE_25__.FileUploadModule,
        _modules_shared_shared_module__WEBPACK_IMPORTED_MODULE_11__.SharedModule] }); })();


/***/ }),

/***/ 33042:
/*!**************************************************************************!*\
  !*** ./src/app/components/rikkes/data-peserta/data-peserta.component.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataPesertaComponent": function() { return /* binding */ DataPesertaComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _data_peserta_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./data-peserta.service */ 33890);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/table */ 6536);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/api */ 88055);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 54364);






const _c0 = ["dt"];
function DataPesertaComponent_ng_template_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "tr", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "No. Urut");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "No. Peserta");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6, "Nama");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8, "Tgl. Lahir");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10, "Jns. Kelamin");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function DataPesertaComponent_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function DataPesertaComponent_ng_template_6_Template_button_click_2_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r5); const item_r3 = restoredCtx.$implicit; const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r4.selectedPeserta(item_r3); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](8, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](13, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item_r3.noUrut);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item_r3.noPeserta);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](8, 5, item_r3.nama));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item_r3.tglLahir);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](13, 7, item_r3.jnsKelamin));
} }
const _c1 = function () { return ["noUrut", "noPeserta", "nama", "tglLahir", "jnsKelamin"]; };
class DataPesertaComponent {
    constructor(dataPesertaService) {
        this.dataPesertaService = dataPesertaService;
        this.dataPeserta = [];
        this.filterKey = '';
    }
    ngOnInit() {
        this.dataPesertaService.dataPeserta.subscribe(data => this.dataPeserta = data);
        this.dataPesertaService.getDataPeserta();
    }
    loadCarsLazy(e) {
        this.dataPesertaService.getDataPeserta();
    }
    selectedPeserta(data) {
        this.dataPesertaService.peserta.next(data);
        this.dataPesertaService.closeDialog();
    }
    filtering(e) {
        if (e.code == 'Enter') {
            this.dt.filterGlobal(this.filterKey, 'startsWith');
        }
    }
}
DataPesertaComponent.ɵfac = function DataPesertaComponent_Factory(t) { return new (t || DataPesertaComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_data_peserta_service__WEBPACK_IMPORTED_MODULE_0__.DataPesertaService)); };
DataPesertaComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: DataPesertaComponent, selectors: [["app-data-peserta"]], viewQuery: function DataPesertaComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c0, 5);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.dt = _t.first);
    } }, decls: 7, vars: 4, consts: [[1, "row"], [1, "col", 2, "height", "80%"], ["type", "text", "placeholder", "Keyword Pencarian... Tekan Enter Untuk Memulai", 1, "form-control", "mb-1", "mt-1", 3, "ngModel", "ngModelChange", "keyup"], [3, "value", "globalFilterFields"], ["dt", ""], ["pTemplate", "header"], ["pTemplate", "body"], [1, "bg-gray-300"], [1, "btn", "btn-sm", "btn-secondary", 3, "click"]], template: function DataPesertaComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "input", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DataPesertaComponent_Template_input_ngModelChange_2_listener($event) { return ctx.filterKey = $event; })("keyup", function DataPesertaComponent_Template_input_keyup_2_listener($event) { return ctx.filtering($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "p-table", 3, 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, DataPesertaComponent_ng_template_5_Template, 11, 0, "ng-template", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, DataPesertaComponent_ng_template_6_Template, 14, 9, "ng-template", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.filterKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", ctx.dataPeserta)("globalFilterFields", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](3, _c1));
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgModel, primeng_table__WEBPACK_IMPORTED_MODULE_3__.Table, primeng_api__WEBPACK_IMPORTED_MODULE_4__.PrimeTemplate], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.UpperCasePipe], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkYXRhLXBlc2VydGEuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 33890:
/*!************************************************************************!*\
  !*** ./src/app/components/rikkes/data-peserta/data-peserta.service.ts ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataPesertaService": function() { return /* binding */ DataPesertaService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/loading.service */ 4471);





class DataPesertaService {
    constructor(http, loadingService) {
        this.http = http;
        this.loadingService = loadingService;
        this.dataPeserta = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject('');
        this.peserta = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject('');
        this.dialog = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject(false);
    }
    getDataPeserta() {
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/dataPeserta'))
            .subscribe(data => {
            this.dataPeserta.next(data.data);
        });
    }
    getPesertaByNoUrut(noUrut) {
        this.loadingService.status.next(true);
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/peserta/noUrut/' + noUrut))
            .subscribe(data => {
            this.peserta.next(data.data);
            this.loadingService.status.next(false);
        });
    }
    openDialog() {
        this.dialog.next(true);
    }
    closeDialog() {
        this.dialog.next(false);
    }
}
DataPesertaService.ɵfac = function DataPesertaService_Factory(t) { return new (t || DataPesertaService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_1__.LoadingService)); };
DataPesertaService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: DataPesertaService, factory: DataPesertaService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 82286:
/*!**************************************************************************!*\
  !*** ./src/app/components/rikkes/laboratorium/laboratorium.component.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LaboratoriumComponent": function() { return /* binding */ LaboratoriumComponent; }
/* harmony export */ });
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/api */ 88055);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _laboratorium_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./laboratorium.service */ 53862);
/* harmony import */ var _data_peserta_data_peserta_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../data-peserta/data-peserta.service */ 33890);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/table */ 6536);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/inputtextarea */ 90777);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/toast */ 92076);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/dropdown */ 14170);












function LaboratoriumComponent_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2, "Pemeriksaan");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, "Hasil");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6, "Nilai Rujukan");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} }
function LaboratoriumComponent_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "tr", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "td", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 1, item_r3.group));
} }
function LaboratoriumComponent_ng_template_12_ng_template_6_div_0_Template(rf, ctx) { if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "input", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function LaboratoriumComponent_ng_template_12_ng_template_6_div_0_Template_input_ngModelChange_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r17); const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).$implicit; return item_r4.hasil = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", item_r4.hasil);
} }
const _c0 = function () { return { "width": "100%" }; };
function LaboratoriumComponent_ng_template_12_ng_template_6_div_1_p_dropdown_1_Template(rf, ctx) { if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "p-dropdown", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function LaboratoriumComponent_ng_template_12_ng_template_6_div_1_p_dropdown_1_Template_p_dropdown_ngModelChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r22); const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3).$implicit; return item_r4.hasil = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3).$implicit;
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](6, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("showClear", true)("options", ctx_r19.golDarah)("autoDisplayFirst", false)("ngModel", item_r4.hasil);
} }
function LaboratoriumComponent_ng_template_12_ng_template_6_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, LaboratoriumComponent_ng_template_12_ng_template_6_div_1_p_dropdown_1_Template, 1, 7, "p-dropdown", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", item_r4.name === "GOLONGAN DARAH");
} }
function LaboratoriumComponent_ng_template_12_ng_template_6_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "p-dropdown", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function LaboratoriumComponent_ng_template_12_ng_template_6_div_2_Template_p_dropdown_ngModelChange_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r27); const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).$implicit; return item_r4.hasil = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).$implicit;
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](6, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("showClear", true)("options", ctx_r11.positiveNegative)("autoDisplayFirst", false)("ngModel", item_r4.hasil);
} }
function LaboratoriumComponent_ng_template_12_ng_template_6_div_3_Template(rf, ctx) { if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "p-dropdown", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function LaboratoriumComponent_ng_template_12_ng_template_6_div_3_Template_p_dropdown_ngModelChange_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r31); const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).$implicit; return item_r4.hasil = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).$implicit;
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](6, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("showClear", true)("options", ctx_r12.reactive)("autoDisplayFirst", false)("ngModel", item_r4.hasil);
} }
function LaboratoriumComponent_ng_template_12_ng_template_6_div_4_Template(rf, ctx) { if (rf & 1) {
    const _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "p-dropdown", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function LaboratoriumComponent_ng_template_12_ng_template_6_div_4_Template_p_dropdown_ngModelChange_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r35); const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).$implicit; return item_r4.hasil = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).$implicit;
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](6, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("showClear", true)("options", ctx_r13.positiveNegative2)("autoDisplayFirst", false)("ngModel", item_r4.hasil);
} }
function LaboratoriumComponent_ng_template_12_ng_template_6_div_5_Template(rf, ctx) { if (rf & 1) {
    const _r39 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "p-dropdown", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function LaboratoriumComponent_ng_template_12_ng_template_6_div_5_Template_p_dropdown_ngModelChange_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r39); const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).$implicit; return item_r4.hasil = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).$implicit;
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](6, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("showClear", true)("options", ctx_r14.normalAbnormal)("autoDisplayFirst", false)("ngModel", item_r4.hasil);
} }
function LaboratoriumComponent_ng_template_12_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, LaboratoriumComponent_ng_template_12_ng_template_6_div_0_Template, 2, 1, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, LaboratoriumComponent_ng_template_12_ng_template_6_div_1_Template, 2, 1, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, LaboratoriumComponent_ng_template_12_ng_template_6_div_2_Template, 2, 7, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, LaboratoriumComponent_ng_template_12_ng_template_6_div_3_Template, 2, 7, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](4, LaboratoriumComponent_ng_template_12_ng_template_6_div_4_Template, 2, 7, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](5, LaboratoriumComponent_ng_template_12_ng_template_6_div_5_Template, 2, 7, "div", 22);
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", item_r4.name != "ANTIGEN SARS COV-2" && item_r4.name != "TES KEHAMILAN" && item_r4.name != "AMPHETAMINE" && item_r4.name != "METAMPHETAMINE" && item_r4.name != "THC" && item_r4.name != "BENZODIAZEPINES" && item_r4.name != "MORPHINE" && item_r4.name != "SILINDER" && item_r4.name != "KRISTAL" && item_r4.name != "BAKTERI" && item_r4.name != "GOLONGAN DARAH" && item_r4.name != "PROTEIN" && item_r4.name != "BILIRUBIN" && item_r4.name != "REDUKSI" && item_r4.name != "NITRIT" && item_r4.name != "KETON" && item_r4.name != "DARAH" && item_r4.name != "UROBILINOGE" && item_r4.name != "ANTI - HIV (RAPID T)" && item_r4.name != "HBSAG" && item_r4.name != "PROTEIN" && item_r4.name != "BILIRUBIN" && item_r4.name != "REDUKSI" && item_r4.name != "NITRIT" && item_r4.name != "KETON" && item_r4.name != "DARAH" && item_r4.name != "UROBILINOGEN");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", item_r4.name === "GOLONGAN DARAH");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", item_r4.name === "ANTIGEN SARS COV-2" || item_r4.name === "TES KEHAMILAN" || item_r4.name === "AMPHETAMINE" || item_r4.name === "METAMPHETAMINE" || item_r4.name === "THC" || item_r4.name === "BENZODIAZEPINES" || item_r4.name === "MORPHINE" || item_r4.name === "SILINDER" || item_r4.name === "KRISTAL" || item_r4.name === "BAKTERI");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", item_r4.name === "ANTI - HIV (RAPID T)" || item_r4.name === "HBSAG");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", item_r4.name === "PROTEIN" || item_r4.name === "BILIRUBIN" || item_r4.name === "REDUKSI" || item_r4.name === "NITRIT" || item_r4.name === "KETON" || item_r4.name === "DARAH");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", item_r4.name === "UROBILINOGEN");
} }
function LaboratoriumComponent_ng_template_12_ng_template_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "input", 26);
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpropertyInterpolate"]("value", item_r4.hasil);
} }
function LaboratoriumComponent_ng_template_12_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    const _r45 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "input", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function LaboratoriumComponent_ng_template_12_ng_template_10_Template_input_ngModelChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r45); const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit; return item_r4.nilaiRujukan = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", item_r4.nilaiRujukan);
} }
function LaboratoriumComponent_ng_template_12_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](0);
} if (rf & 2) {
    const item_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", item_r4.nilaiRujukan, " ");
} }
function LaboratoriumComponent_ng_template_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "p-cellEditor");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](6, LaboratoriumComponent_ng_template_12_ng_template_6_Template, 6, 6, "ng-template", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](7, LaboratoriumComponent_ng_template_12_ng_template_7_Template, 1, 1, "ng-template", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "p-cellEditor");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](10, LaboratoriumComponent_ng_template_12_ng_template_10_Template, 1, 1, "ng-template", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](11, LaboratoriumComponent_ng_template_12_ng_template_11_Template, 1, 1, "ng-template", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](item_r4.name);
} }
const _c1 = function () { return { width: "100%", minHeight: "80px" }; };
class LaboratoriumComponent {
    constructor(laboratoriumService, dataPesertaService, messageService) {
        this.laboratoriumService = laboratoriumService;
        this.dataPesertaService = dataPesertaService;
        this.messageService = messageService;
        this.hasilLab = [];
        this.keterangan = { catatan: '', pemeriksa: '' };
        this.golDarah = [
            { name: 'A' },
            { name: 'B' },
            { name: 'AB' },
            { name: 'O' }
        ];
        this.positiveNegative = [
            { name: 'NEGATIF' },
            { name: 'POSITIF' }
        ];
        this.reactive = [
            { name: 'REAKTIF' },
            { name: 'NON REAKTIF' }
        ];
        this.positiveNegative2 = [
            { name: 'NEGATIF' },
            { name: 'POSITIF' },
            { name: 'POSITIF 2' },
            { name: 'POSITIF 3' },
        ];
        this.normalAbnormal = [
            { name: 'NORMAL' },
            { name: 'ABNORMAL' }
        ];
    }
    ngOnInit() {
        this.initHasilLab();
        this.dataPesertaService.peserta.subscribe(data => this.peserta = data);
        this.laboratoriumService.hasilLab.subscribe(data => this.handleHasilLab(data));
        this.laboratoriumService.dialog.subscribe(data => {
            if (data) {
                this.laboratoriumService.getHasilLab(this.peserta.id);
            }
            else {
                this.initHasilLab();
                this.keterangan = { catatan: '', pemeriksa: '' };
            }
        });
        this.laboratoriumService.saveStatus.subscribe(data => {
            if (data) {
                this.messageService.add({ severity: 'success', summary: 'Sukses !', detail: 'Data Berhasil Disimpan.' });
            }
        });
    }
    handleHasilLab(data) {
        if (data.hasil) {
            if (data.hasil.length > 0) {
                this.hasilLab = data.hasil;
            }
        }
        else {
            this.initHasilLab();
        }
        if (data.keterangan) {
            if (data.keterangan[0]) {
                this.keterangan = { catatan: data.keterangan[0].catatan, pemeriksa: data.keterangan[0].pemeriksa };
            }
        }
        else {
            this.keterangan = { catatan: '', pemeriksa: '' };
        }
    }
    initHasilLab() {
        this.hasilLab = [
            { name: 'HEMOGLOBIN', hasil: '', nilaiRujukan: 'P (13.0 -17.0 GR/DL)', group: 'hematologi' },
            { name: 'HEMATOKRIT', hasil: '', nilaiRujukan: 'P (40 - 48 GR %)', group: 'hematologi' },
            { name: 'ERITROSIT', hasil: '', nilaiRujukan: 'DWS (4.0-5.9JUTA/UL)', group: 'hematologi' },
            { name: 'LEKOSIT', hasil: '', nilaiRujukan: 'DWS ( 4-10 RIBU/UL)', group: 'hematologi' },
            { name: 'LED I', hasil: '', nilaiRujukan: 'P (0 - 15 MM/JAM)', group: 'hematologi' },
            { name: 'TROMBOSIT', hasil: '', nilaiRujukan: 'DWS (150-440 RIBU/UL)', group: 'hematologi' },
            { name: 'GOLONGAN DARAH', hasil: '', nilaiRujukan: '', group: 'hematologi' },
            { name: 'RH', hasil: '', nilaiRujukan: '', group: 'hematologi' },
            { name: 'GULA DARAH SEWAKTU', hasil: '', nilaiRujukan: '( < 140 MG/DL )', group: 'kimia darah' },
            { name: 'UREUM', hasil: '', nilaiRujukan: '( 20 - 50 MG/DL )', group: 'kimia darah' },
            { name: 'KREATININ', hasil: '', nilaiRujukan: '( 0.5 - 1.5 MG/DL )', group: 'kimia darah' },
            { name: 'SGOT', hasil: '', nilaiRujukan: '( <41 U/I)', group: 'kimia darah' },
            { name: 'SGPT', hasil: '', nilaiRujukan: '( <41 U/I)', group: 'kimia darah' },
            { name: 'WARNA', hasil: '', nilaiRujukan: '', group: 'urin' },
            { name: 'PH', hasil: '', nilaiRujukan: '5.0 - 8.0', group: 'urin' },
            { name: 'BERAT', hasil: '', nilaiRujukan: '1.000 - 1.030', group: 'urin' },
            { name: 'PROTEIN', hasil: '', nilaiRujukan: 'NEGATIF', group: 'urin' },
            { name: 'BILIRUBIN', hasil: '', nilaiRujukan: 'NEGATIF', group: 'urin' },
            { name: 'REDUKSI', hasil: '', nilaiRujukan: 'NEGATIF', group: 'urin' },
            { name: 'UROBILINOGEN', hasil: '', nilaiRujukan: 'NORMAL', group: 'urin' },
            { name: 'NITRIT', hasil: '', nilaiRujukan: 'NEGATIF', group: 'urin' },
            { name: 'KETON', hasil: '', nilaiRujukan: 'NEGATIF', group: 'urin' },
            { name: 'DARAH', hasil: '', nilaiRujukan: 'NEGATIF', group: 'urin' },
            { name: 'LEKOSIT', hasil: '', nilaiRujukan: '/LPB', group: 'urin' },
            { name: 'ERITROSIT', hasil: '', nilaiRujukan: '/LPB', group: 'urin' },
            { name: 'SILINDER', hasil: '', nilaiRujukan: '', group: 'urin' },
            { name: 'EPITEL', hasil: '', nilaiRujukan: '/LPK', group: 'urin' },
            { name: 'KRISTAL', hasil: '', nilaiRujukan: '', group: 'urin' },
            { name: 'BAKTERI', hasil: '', nilaiRujukan: '', group: 'urin' },
            { name: 'ANTI - HIV (RAPID T)', hasil: 'NON REAKTIF', nilaiRujukan: 'NON REAKTIF', group: 'serologi' },
            { name: 'AMPHETAMINE', hasil: 'NEGATIF', nilaiRujukan: 'NEGATIF', group: 'tes narkoba' },
            { name: 'METAMPHETAMINE', hasil: 'NEGATIF', nilaiRujukan: 'NEGATIF', group: 'tes narkoba' },
            { name: 'THC', hasil: 'NEGATIF', nilaiRujukan: 'NEGATIF', group: 'tes narkoba' },
            { name: 'BENZODIAZEPINES', hasil: 'NEGATIF', nilaiRujukan: 'NEGATIF', group: 'tes narkoba' },
            { name: 'MORPHINE', hasil: 'NEGATIF', nilaiRujukan: 'NEGATIF', group: 'tes narkoba' },
            { name: 'ANTIGEN SARS COV-2', hasil: 'NEGATIF', nilaiRujukan: 'NEGATIF', group: 'imunologi' },
            { name: 'HBSAG', hasil: 'NEGATIF', nilaiRujukan: '', group: 'tes' },
            { name: 'TES KEHAMILAN', hasil: '', nilaiRujukan: '', group: 'tes' },
        ];
    }
    save() {
        let data = {
            idPeserta: this.peserta.id,
            data: this.hasilLab,
            keterangan: this.keterangan
        };
        this.laboratoriumService.save(data);
    }
    print() {
        let iframe = '<iframe src="' + src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/printHasilLab/idPeserta/' + this.peserta.id) + '" style="height:calc(100% - 4px);width:calc(100% - 4px)"></iframe>';
        let win = window.open("", "", "width=" + screen.availWidth + ",height=" + screen.availHeight + ",toolbar=no,menubar=no,resizable=yes");
        win.document.write(iframe);
    }
}
LaboratoriumComponent.ɵfac = function LaboratoriumComponent_Factory(t) { return new (t || LaboratoriumComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_laboratorium_service__WEBPACK_IMPORTED_MODULE_1__.LaboratoriumService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_data_peserta_data_peserta_service__WEBPACK_IMPORTED_MODULE_2__.DataPesertaService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_4__.MessageService)); };
LaboratoriumComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: LaboratoriumComponent, selectors: [["app-laboratorium"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵProvidersFeature"]([primeng_api__WEBPACK_IMPORTED_MODULE_4__.MessageService])], decls: 24, vars: 7, consts: [[1, "row"], [1, "col-12", "bg-gray-300", "p-3", "m-3", "sticky-top"], [1, "btn", "btn-primary", "mr-1", 3, "click"], [1, "bi", "bi-save", "mr-1"], [1, "btn", "btn-secondary", 3, "click"], [1, "bi", "bi-printer", "mr-1"], [1, "col-12"], ["editMode", "column", "dataKey", "name", "responsiveLayout", "scroll", "rowGroupMode", "subheader", "groupRowsBy", "group", 3, "value"], ["pTemplate", "header"], ["pTemplate", "groupheader"], ["pTemplate", "body"], [1, "col-12", "mt-2"], [1, "col"], ["pInputTextarea", "", 3, "ngModel", "autoResize", "ngModelChange"], ["type", "text", 1, "form-control", 3, "ngModel", "ngModelChange"], ["position", "top-center"], ["pRowGroupHeader", ""], ["colspan", "5", 1, "tx-bold"], [1, "ml-3"], ["pEditableColumn", ""], ["pTemplate", "input"], ["pTemplate", "output"], [4, "ngIf"], ["pInputText", "", "type", "text", 1, "form-control", 3, "ngModel", "ngModelChange"], ["appendTo", "body", "optionValue", "name", "optionLabel", "name", 3, "showClear", "options", "autoDisplayFirst", "ngModel", "style", "ngModelChange", 4, "ngIf"], ["appendTo", "body", "optionValue", "name", "optionLabel", "name", 3, "showClear", "options", "autoDisplayFirst", "ngModel", "ngModelChange"], ["type", "text", "readOnly", "", 1, "form-control", 3, "value"], ["pInputText", "", "type", "text", 3, "ngModel", "ngModelChange"]], template: function LaboratoriumComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LaboratoriumComponent_Template_button_click_2_listener() { return ctx.save(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "i", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, " Simpan");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LaboratoriumComponent_Template_button_click_5_listener() { return ctx.print(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](6, "i", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7, " Print Hasil");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "p-table", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](10, LaboratoriumComponent_ng_template_10_Template, 7, 0, "ng-template", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](11, LaboratoriumComponent_ng_template_11_Template, 4, 3, "ng-template", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](12, LaboratoriumComponent_ng_template_12_Template, 12, 1, "ng-template", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](13, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](17, "Catatan :");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "textarea", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function LaboratoriumComponent_Template_textarea_ngModelChange_18_listener($event) { return ctx.keterangan.catatan = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](19, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](20, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](21, "Pemeriksa :");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](22, "input", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function LaboratoriumComponent_Template_input_ngModelChange_22_listener($event) { return ctx.keterangan.pemeriksa = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](23, "p-toast", 15);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("value", ctx.hasilLab);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](6, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ctx.keterangan.catatan)("autoResize", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ctx.keterangan.pemeriksa);
    } }, directives: [primeng_table__WEBPACK_IMPORTED_MODULE_5__.Table, primeng_api__WEBPACK_IMPORTED_MODULE_4__.PrimeTemplate, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_7__.InputTextarea, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, primeng_toast__WEBPACK_IMPORTED_MODULE_8__.Toast, primeng_table__WEBPACK_IMPORTED_MODULE_5__.RowGroupHeader, primeng_table__WEBPACK_IMPORTED_MODULE_5__.EditableColumn, primeng_table__WEBPACK_IMPORTED_MODULE_5__.CellEditor, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, primeng_dropdown__WEBPACK_IMPORTED_MODULE_10__.Dropdown], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.UpperCasePipe], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsYWJvcmF0b3JpdW0uY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 53862:
/*!************************************************************************!*\
  !*** ./src/app/components/rikkes/laboratorium/laboratorium.service.ts ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LaboratoriumService": function() { return /* binding */ LaboratoriumService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 53882);




class LaboratoriumService {
    constructor(http) {
        this.http = http;
        this.dialog = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(false);
        this.hasilLab = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
        this.saveStatus = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(false);
        this.hasilLabKeterangan = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
    }
    save(data) {
        this.http.post(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/save/hasilLab'), data)
            .subscribe(data => {
            if (data.code == 200) {
                this.saveStatus.next(true);
            }
            else {
                this.saveStatus.next(false);
            }
        });
    }
    getHasilLab(idPeserta) {
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/getHasilLab/idPeserta/' + idPeserta))
            .subscribe(data => this.hasilLab.next(data.data));
    }
    getHasilLabKeterangan(idPeserta) {
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/getHasilLabKeterangan/idPeserta/' + idPeserta))
            .subscribe(data => this.hasilLabKeterangan.next(data.data));
    }
    openDialog() {
        this.dialog.next(true);
    }
    closeDialog() {
        this.dialog.next(false);
    }
    dataTest() {
        let data = [
            { nama: 'hemoglobin', nilaiRujukan: 'W(12.0-16.0 GR/DL)' },
            { nama: 'hematokrit', nilaiRujukan: 'W(37-43G%)' },
            { nama: 'eritrosit', nilaiRujukan: 'DWS (4.0-5.9 JUTA/UL' },
            { nama: 'lekosit', nilaiRujukan: 'AN (9-12 RIBU/UL)' },
            { nama: 'led I', nilaiRujukan: 'W (0-20 MM/JAM)' },
            { nama: 'trombosit', nilaiRujukan: 'DWS (150-440 RIBU/UL)' },
            { nama: 'golongan darah', nilaiRujukan: '' },
            { nama: 'rh', nilaiRujukan: '' },
            { nama: 'gula darah sewaktu', nilaiRujukan: '(< 140 MG/DL)' },
            { nama: 'ureum', nilaiRujukan: '(20-50 MG/DL)' },
            { nama: 'kreatinin', nilaiRujukan: '(20-50 MG/DL)' },
            { nama: 'sgot', nilaiRujukan: '(< 41 U/I)' },
        ];
    }
}
LaboratoriumService.ɵfac = function LaboratoriumService_Factory(t) { return new (t || LaboratoriumService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient)); };
LaboratoriumService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: LaboratoriumService, factory: LaboratoriumService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 54064:
/*!********************************************************************!*\
  !*** ./src/app/components/rikkes/radiologi/radiologi.component.ts ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RadiologiComponent": function() { return /* binding */ RadiologiComponent; }
/* harmony export */ });
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/api */ 88055);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _radiologi_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./radiologi.service */ 7958);
/* harmony import */ var _data_peserta_data_peserta_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../data-peserta/data-peserta.service */ 33890);
/* harmony import */ var _upload_file_upload_file_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../upload-file/upload-file.component */ 84353);
/* harmony import */ var primeng_editor__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/editor */ 89080);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/toast */ 92076);










function RadiologiComponent_ng_template_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "select", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "option", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "option", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "option", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](5, "option", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](8, "button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "button", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
const _c0 = function () { return { "min-height": "100px" }; };
class RadiologiComponent {
    constructor(radiologiService, messageService, dataPesertaService) {
        this.radiologiService = radiologiService;
        this.messageService = messageService;
        this.dataPesertaService = dataPesertaService;
        this.uploadedFiles = [];
        this.currentFiles = [];
        this.hasil = '';
        this.dokter = 'dr.Priatna,Sp.Rad';
    }
    ngOnInit() {
        this.radiologiService.saveStatus.subscribe(data => {
            if (data) {
                this.messageService.add({ severity: 'success', summary: 'Sukses !', detail: 'Data Berhasil Disimpan.' });
            }
        });
        this.dataPesertaService.peserta.subscribe(data => this.peserta = data);
        this.radiologiService.dialog.subscribe(data => {
            if (data) {
                this.radiologiService.getDataHasil(this.peserta.id);
            }
            else {
                this.hasil = '';
                this.dokter = 'dr.Priatna,Sp.Rad';
            }
        });
        this.radiologiService.hasil.subscribe(data => {
            if (data) {
                this.hasil = data.keterangan;
                this.dokter = data.dokter;
            }
        });
    }
    save() {
        this.radiologiService.save({ hasil: this.hasil, idPeserta: this.peserta.id, dokter: this.dokter });
    }
    print() {
        let iframe = '<iframe src="' + src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/printHasilRadiologi/idPeserta/' + this.peserta.id) + '" style="height:calc(100% - 4px);width:calc(100% - 4px)"></iframe>';
        let win = window.open("", "", "width=" + screen.availWidth + ",height=" + screen.availHeight + ",toolbar=no,menubar=no,resizable=yes");
        win.document.write(iframe);
    }
}
RadiologiComponent.ɵfac = function RadiologiComponent_Factory(t) { return new (t || RadiologiComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_radiologi_service__WEBPACK_IMPORTED_MODULE_1__.RadiologiService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_5__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_data_peserta_data_peserta_service__WEBPACK_IMPORTED_MODULE_2__.DataPesertaService)); };
RadiologiComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: RadiologiComponent, selectors: [["app-radiologi"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵProvidersFeature"]([primeng_api__WEBPACK_IMPORTED_MODULE_5__.MessageService])], decls: 19, vars: 7, consts: [[1, "row"], [1, "col"], [1, "tx-semibold", "tx-16", "mb-2"], [3, "ngModel", "ngModelChange"], ["pTemplate", "header"], [1, "mt-1"], ["type", "text", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "mt-2", "p-3", "bg-gray-300"], [1, "btn", "btn-primary", "btn-sm", "mr-1", 3, "disabled", "click"], [1, "bi", "bi-save", "mr-1"], [1, "btn", "btn-secondary", "btn-sm", "mr-1", 3, "disabled", "click"], [1, "bi", "bi-printer", "mr-1"], ["position", "top-center"], [1, "ql-formats"], [1, "ql-size"], ["value", "small"], ["selected", ""], ["value", "large"], ["value", "huge"], ["type", "button", "aria-label", "Bold", 1, "ql-bold"], ["type", "button", "aria-label", "Italic", 1, "ql-italic"], ["type", "button", "aria-label", "Underline", 1, "ql-underline"]], template: function RadiologiComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "app-upload-file");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "Hasil Radiologi :");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "p-editor", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function RadiologiComponent_Template_p_editor_ngModelChange_6_listener($event) { return ctx.hasil = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, RadiologiComponent_ng_template_7_Template, 10, 0, "ng-template", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, " Dokter Pemeriksa : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "input", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function RadiologiComponent_Template_input_ngModelChange_10_listener($event) { return ctx.dokter = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function RadiologiComponent_Template_button_click_12_listener() { return ctx.save(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](13, "i", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14, " Simpan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function RadiologiComponent_Template_button_click_15_listener() { return ctx.print(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](16, "i", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17, " Print Hasil");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](18, "p-toast", 12);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](6, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx.hasil);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx.dokter);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", !ctx.hasil);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", !ctx.hasil);
    } }, directives: [_upload_file_upload_file_component__WEBPACK_IMPORTED_MODULE_3__.UploadFileComponent, primeng_editor__WEBPACK_IMPORTED_MODULE_6__.Editor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgModel, primeng_api__WEBPACK_IMPORTED_MODULE_5__.PrimeTemplate, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, primeng_toast__WEBPACK_IMPORTED_MODULE_8__.Toast, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgSelectMultipleOption"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyYWRpb2xvZ2kuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 7958:
/*!******************************************************************!*\
  !*** ./src/app/components/rikkes/radiologi/radiologi.service.ts ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RadiologiService": function() { return /* binding */ RadiologiService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 53882);




class RadiologiService {
    constructor(http) {
        this.http = http;
        this.dialog = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(false);
        this.saveStatus = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(false);
        this.hasil = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
    }
    save(data) {
        this.http.post(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/save/hasilRadiologi'), data)
            .subscribe(data => {
            if (data.code == 200) {
                this.saveStatus.next(true);
            }
            else {
                this.saveStatus.next(false);
            }
        });
    }
    getDataHasil(idPeserta) {
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/getHasilRadiologi/idPeserta/' + idPeserta))
            .subscribe(data => {
            if (data.data) {
                this.hasil.next(data.data);
            }
        });
    }
    openDialog() {
        this.dialog.next(true);
    }
    closeDialog() {
        this.dialog.next(false);
    }
}
RadiologiService.ɵfac = function RadiologiService_Factory(t) { return new (t || RadiologiService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient)); };
RadiologiService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: RadiologiService, factory: RadiologiService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 2304:
/*!*******************************************************!*\
  !*** ./src/app/components/rikkes/rikkes.component.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RikkesComponent": function() { return /* binding */ RikkesComponent; }
/* harmony export */ });
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/api */ 88055);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _rikkes_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rikkes.service */ 42469);
/* harmony import */ var _data_peserta_data_peserta_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./data-peserta/data-peserta.service */ 33890);
/* harmony import */ var _upload_file_upload_file_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./upload-file/upload-file.service */ 60834);
/* harmony import */ var _radiologi_radiologi_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./radiologi/radiologi.service */ 7958);
/* harmony import */ var _laboratorium_laboratorium_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./laboratorium/laboratorium.service */ 53862);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/dialog */ 75657);
/* harmony import */ var _data_peserta_data_peserta_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./data-peserta/data-peserta.component */ 33042);
/* harmony import */ var _upload_file_upload_file_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./upload-file/upload-file.component */ 84353);
/* harmony import */ var _laboratorium_laboratorium_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./laboratorium/laboratorium.component */ 82286);
/* harmony import */ var _radiologi_radiologi_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./radiologi/radiologi.component */ 54064);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/menu */ 63493);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/inputtextarea */ 90777);
/* harmony import */ var primeng_editor__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/editor */ 89080);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/dropdown */ 14170);
/* harmony import */ var primeng_selectbutton__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/selectbutton */ 27925);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/toast */ 92076);






















function RikkesComponent_ng_template_40_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "button", 159);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_ng_template_40_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r6.setSimbolOdontogram(""); });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "i", 160);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, " Hapus");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} }
function RikkesComponent_div_326_span_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, "\u00A0");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} }
function RikkesComponent_div_326_span_3_i_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 8);
} }
function RikkesComponent_div_326_span_3_i_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 9);
} }
function RikkesComponent_div_326_span_3_i_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 10);
} }
function RikkesComponent_div_326_span_3_i_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 11);
} }
function RikkesComponent_div_326_span_3_i_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 12);
} }
function RikkesComponent_div_326_span_3_i_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 13);
} }
function RikkesComponent_div_326_span_3_img_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "img", 173);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", "assets/ac.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
} }
function RikkesComponent_div_326_span_3_img_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "img", 173);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", "assets/ds.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
} }
function RikkesComponent_div_326_span_3_img_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "img", 173);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", "assets/dc.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
} }
function RikkesComponent_div_326_span_3_img_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "img", 174);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", "assets/cs.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
} }
function RikkesComponent_div_326_span_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span", 164);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, RikkesComponent_div_326_span_3_i_1_Template, 1, 0, "i", 165);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, RikkesComponent_div_326_span_3_i_2_Template, 1, 0, "i", 166);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](3, RikkesComponent_div_326_span_3_i_3_Template, 1, 0, "i", 167);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](4, RikkesComponent_div_326_span_3_i_4_Template, 1, 0, "i", 168);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](5, RikkesComponent_div_326_span_3_i_5_Template, 1, 0, "i", 169);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](6, RikkesComponent_div_326_span_3_i_6_Template, 1, 0, "i", 170);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](7, RikkesComponent_div_326_span_3_img_7_Template, 1, 1, "img", 171);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](8, RikkesComponent_div_326_span_3_img_8_Template, 1, 1, "img", 171);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](9, RikkesComponent_div_326_span_3_img_9_Template, 1, 1, "img", 171);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](10, RikkesComponent_div_326_span_3_img_10_Template, 1, 1, "img", 172);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.atas == "s");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.atas == "c");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.atas == "x");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.atas == "ck");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.atas == "cf");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.atas == "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.atas == "ac");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.atas == "ds");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.atas == "dc");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.atas == "cs");
} }
function RikkesComponent_div_326_span_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, "\u00A0");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} }
function RikkesComponent_div_326_span_8_i_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 8);
} }
function RikkesComponent_div_326_span_8_i_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 9);
} }
function RikkesComponent_div_326_span_8_i_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 10);
} }
function RikkesComponent_div_326_span_8_i_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 11);
} }
function RikkesComponent_div_326_span_8_i_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 12);
} }
function RikkesComponent_div_326_span_8_i_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 13);
} }
function RikkesComponent_div_326_span_8_img_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "img", 173);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", "assets/ac.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
} }
function RikkesComponent_div_326_span_8_img_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "img", 173);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", "assets/ds.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
} }
function RikkesComponent_div_326_span_8_img_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "img", 173);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", "assets/dc.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
} }
function RikkesComponent_div_326_span_8_img_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "img", 174);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", "assets/cs.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
} }
function RikkesComponent_div_326_span_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span", 164);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, RikkesComponent_div_326_span_8_i_1_Template, 1, 0, "i", 165);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, RikkesComponent_div_326_span_8_i_2_Template, 1, 0, "i", 166);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](3, RikkesComponent_div_326_span_8_i_3_Template, 1, 0, "i", 167);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](4, RikkesComponent_div_326_span_8_i_4_Template, 1, 0, "i", 168);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](5, RikkesComponent_div_326_span_8_i_5_Template, 1, 0, "i", 169);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](6, RikkesComponent_div_326_span_8_i_6_Template, 1, 0, "i", 170);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](7, RikkesComponent_div_326_span_8_img_7_Template, 1, 1, "img", 171);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](8, RikkesComponent_div_326_span_8_img_8_Template, 1, 1, "img", 171);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](9, RikkesComponent_div_326_span_8_img_9_Template, 1, 1, "img", 171);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](10, RikkesComponent_div_326_span_8_img_10_Template, 1, 1, "img", 172);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.bawah == "s");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.bawah == "c");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.bawah == "x");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.bawah == "ck");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.bawah == "cf");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.bawah == "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.bawah == "ac");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.bawah == "ds");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.bawah == "dc");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.bawah == "cs");
} }
const _c0 = function (a0) { return { "ml-3 pl-3 border-left": a0 }; };
function RikkesComponent_div_326_Template(rf, ctx) { if (rf & 1) {
    const _r37 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 161);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "div", 162);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_div_326_Template_div_click_1_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r37); const idx_r9 = restoredCtx.index; const item_r8 = restoredCtx.$implicit; const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r36.openDialogSimbolOdontogram(idx_r9, item_r8, "atas"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, RikkesComponent_div_326_span_2_Template, 2, 0, "span", 157);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](3, RikkesComponent_div_326_span_3_Template, 11, 10, "span", 163);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](6, "div", 162);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_div_326_Template_div_click_6_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r37); const idx_r9 = restoredCtx.index; const item_r8 = restoredCtx.$implicit; const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](); return ctx_r38.openDialogSimbolOdontogram(idx_r9, item_r8, "bawah"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](7, RikkesComponent_div_326_span_7_Template, 2, 0, "span", 157);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](8, RikkesComponent_div_326_span_8_Template, 11, 10, "span", 163);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r8 = ctx.$implicit;
    const idx_r9 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](6, _c0, idx_r9 === 8));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !item_r8.atas);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.atas);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](item_r8.keterangan);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !item_r8.bawah);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.bawah);
} }
function RikkesComponent_ng_template_488_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 175);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r39 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](item_r39.name);
} }
function RikkesComponent_span_495_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " Simpan");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} }
function RikkesComponent_span_496_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " Update");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} }
const _c1 = function () { return { width: "75%" }; };
const _c2 = function () { return { width: "700px" }; };
const _c3 = function () { return { width: "50%" }; };
const _c4 = function () { return { "960px": "75vw" }; };
const _c5 = function () { return { width: "100%" }; };
class RikkesComponent {
    constructor(fb, rikkesService, dataPesertaService, uploadFileService, radiologiService, laboratoriumService, messageService) {
        this.fb = fb;
        this.rikkesService = rikkesService;
        this.dataPesertaService = dataPesertaService;
        this.uploadFileService = uploadFileService;
        this.radiologiService = radiologiService;
        this.laboratoriumService = laboratoriumService;
        this.messageService = messageService;
        this.dialogDataPeserta = false;
        this.dialogUploadFile = false;
        this.dialogRadiologi = false;
        this.dialogLaboratorium = false;
        this.dialogPrintSticker = false;
        this.dialogSimbolOdontogram = false;
        this.odontogram = [];
        this.hasil = [{ id: 1, name: 'MS' }, { id: 0, name: 'TMS' }];
        this.printNoUrut = { dari: '', sampai: '' };
        this.hasilBmi = '';
        this.keswaKesimpulan = [
            { name: 'TD' },
            { name: 'DD' },
            { name: 'D' }
        ];
    }
    ngOnInit() {
        this.initForm();
        this.dataPesertaService.peserta.subscribe(data => this.setFormPeserta(data));
        this.dataPesertaService.dialog.subscribe(data => this.dialogDataPeserta = data);
        this.uploadFileService.dialog.subscribe(data => this.dialogUploadFile = data);
        this.radiologiService.dialog.subscribe(data => this.dialogRadiologi = data);
        this.laboratoriumService.dialog.subscribe(data => this.dialogLaboratorium = data);
        this.rikkesService.dataRikkes.subscribe(data => this.setFormRikkes(data));
        this.laboratoriumService.hasilLabKeterangan.subscribe(data => {
            var _a;
            if (data) {
                if (data.length > 0)
                    (_a = this.form.get('hasilLab')) === null || _a === void 0 ? void 0 : _a.patchValue(data[0].catatan);
            }
        });
        this.radiologiService.hasil.subscribe(data => {
            var _a;
            if (data) {
                (_a = this.form.get('hasilRadiologi')) === null || _a === void 0 ? void 0 : _a.patchValue(data.keterangan);
            }
        });
        this.rikkesService.saveStatus.subscribe(data => {
            if (data) {
                this.messageService.add({ severity: 'success', summary: 'Sukses !', detail: 'Data Berhasil Disimpan.' });
            }
        });
        this.menuExport = [
            { label: 'Summary', icon: 'bi bi-file-earmark-ruled', command: (() => { this.exportExcel(); }) },
            { label: 'All Data', icon: 'bi bi-file-earmark-ruled', command: (() => { this.exportExcelAllData(); }) },
        ];
        this.initPeserta();
    }
    setFormPeserta(data) {
        if (data) {
            this.peserta = {
                id: data.id,
                noUrut: data.noUrut,
                noPeserta: data.noPeserta,
                nama: data.nama,
                jnsKelamin: data.jnsKelamin,
                tglLahir: data.tglLahir
            };
            this.rikkesService.getDataRikkes(this.peserta.id);
            this.laboratoriumService.getHasilLabKeterangan(this.peserta.id);
            this.radiologiService.getDataHasil(this.peserta.id);
        }
    }
    initPeserta() {
        this.peserta = {
            id: '',
            noUrut: '',
            noPeserta: '',
            nama: '',
            jnsKelamin: ''
        };
    }
    initForm() {
        this.hasilBmi = '';
        this.initPeserta();
        this.initOdontogram();
        this.form = this.fb.group({
            id: [''],
            anamnesa: [''],
            tinggi: [''],
            berat: [''],
            imt: [''],
            tekananDarah: [''],
            nadi: [''],
            tubuhBentuk: [''],
            tubuhGerak: [''],
            kepala: [''],
            muka: [''],
            leher: [''],
            mata: [''],
            od1: [''],
            od2: [''],
            od3: [''],
            os1: [''],
            os2: [''],
            os3: [''],
            campus: [''],
            kenalWarna: [''],
            lainLain: [''],
            telinga: [''],
            ad: [''],
            as: [''],
            tajamPend: [''],
            membranTymp: [''],
            penyTel: [''],
            gigiMulut: [''],
            gigiD: [''],
            gigiM: [''],
            gigiF: [''],
            karang: [''],
            protesa: [''],
            penyMulut: [''],
            hidung: [''],
            tenggorokan: [''],
            thoraxPernafasan: [''],
            thoraxBentuk: [''],
            cor: [''],
            pulmo: [''],
            abdomen: [''],
            lien: [''],
            hepar: [''],
            regioInguinalis: [''],
            genitalia: [''],
            perineum: [''],
            angGerakAtas: [''],
            angGerakBawah: [''],
            kulit: [''],
            refleks: [''],
            kesimpulanPemeriksaan: [''],
            U: [''],
            A: [''],
            B: [''],
            D: [''],
            L: [''],
            G: [''],
            J: [''],
            stakes: [''],
            hasil: [''],
            hasilLab: [''],
            hasilEkg: [''],
            hasilRadiologi: [''],
            hasilAudiometri: [''],
            hasilKeswaKode: [''],
            hasilKeswaKeterangan: [''],
            odontogramIdentifikasi: [''],
            peserta: []
        });
    }
    initOdontogram() {
        this.odontogram = [
            { keterangan: '8', posisi: 'kiri', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '7', posisi: 'kiri', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '6', posisi: 'kiri', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '5', posisi: 'kiri', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '4', posisi: 'kiri', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '3', posisi: 'kiri', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '2', posisi: 'kiri', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '1', posisi: 'kiri', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '1', posisi: 'kanan', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '2', posisi: 'kanan', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '3', posisi: 'kanan', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '4', posisi: 'kanan', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '5', posisi: 'kanan', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '6', posisi: 'kanan', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '7', posisi: 'kanan', atas: '', bawah: '', idPeserta: '' },
            { keterangan: '8', posisi: 'kanan', atas: '', bawah: '', idPeserta: '' }
        ];
    }
    clearForm() {
        let noUrut = this.peserta.noUrut;
        this.initForm();
        this.peserta.noUrut = noUrut;
    }
    setFormRikkes(data) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43;
        if (data.rikkes) {
            let rikkes = data.rikkes;
            (_a = this.form.get('id')) === null || _a === void 0 ? void 0 : _a.patchValue(rikkes.id);
            (_b = this.form.get('anamnesa')) === null || _b === void 0 ? void 0 : _b.patchValue(rikkes.anamnesa);
            (_c = this.form.get('tinggi')) === null || _c === void 0 ? void 0 : _c.patchValue(rikkes.tinggi);
            (_d = this.form.get('berat')) === null || _d === void 0 ? void 0 : _d.patchValue(rikkes.berat);
            (_e = this.form.get('imt')) === null || _e === void 0 ? void 0 : _e.patchValue(rikkes.imt);
            (_f = this.form.get('tekananDarah')) === null || _f === void 0 ? void 0 : _f.patchValue(rikkes.tekananDarah);
            (_g = this.form.get('nadi')) === null || _g === void 0 ? void 0 : _g.patchValue(rikkes.nadi);
            (_h = this.form.get('tubuhBentuk')) === null || _h === void 0 ? void 0 : _h.patchValue(rikkes.tubuhBentuk);
            (_j = this.form.get('tubuhGerak')) === null || _j === void 0 ? void 0 : _j.patchValue(rikkes.tubuhGerak);
            (_k = this.form.get('kepala')) === null || _k === void 0 ? void 0 : _k.patchValue(rikkes.kepala);
            (_l = this.form.get('muka')) === null || _l === void 0 ? void 0 : _l.patchValue(rikkes.muka);
            (_m = this.form.get('leher')) === null || _m === void 0 ? void 0 : _m.patchValue(rikkes.leher);
            (_o = this.form.get('mata')) === null || _o === void 0 ? void 0 : _o.patchValue(rikkes.mata);
            (_p = this.form.get('od1')) === null || _p === void 0 ? void 0 : _p.patchValue(rikkes.od1);
            (_q = this.form.get('od2')) === null || _q === void 0 ? void 0 : _q.patchValue(rikkes.od2);
            (_r = this.form.get('od3')) === null || _r === void 0 ? void 0 : _r.patchValue(rikkes.od3);
            (_s = this.form.get('os1')) === null || _s === void 0 ? void 0 : _s.patchValue(rikkes.os1);
            (_t = this.form.get('os2')) === null || _t === void 0 ? void 0 : _t.patchValue(rikkes.os2);
            (_u = this.form.get('os3')) === null || _u === void 0 ? void 0 : _u.patchValue(rikkes.os3);
            (_v = this.form.get('campus')) === null || _v === void 0 ? void 0 : _v.patchValue(rikkes.campus);
            (_w = this.form.get('kenalWarna')) === null || _w === void 0 ? void 0 : _w.patchValue(rikkes.kenalWarna);
            (_x = this.form.get('lainLain')) === null || _x === void 0 ? void 0 : _x.patchValue(rikkes.lainLain);
            (_y = this.form.get('telinga')) === null || _y === void 0 ? void 0 : _y.patchValue(rikkes.telinga);
            (_z = this.form.get('ad')) === null || _z === void 0 ? void 0 : _z.patchValue(rikkes.ad);
            (_0 = this.form.get('as')) === null || _0 === void 0 ? void 0 : _0.patchValue(rikkes.as);
            (_1 = this.form.get('tajamPend')) === null || _1 === void 0 ? void 0 : _1.patchValue(rikkes.tajamPend);
            (_2 = this.form.get('membranTymp')) === null || _2 === void 0 ? void 0 : _2.patchValue(rikkes.membranTymp);
            (_3 = this.form.get('penyTel')) === null || _3 === void 0 ? void 0 : _3.patchValue(rikkes.penyTel);
            (_4 = this.form.get('gigiMulut')) === null || _4 === void 0 ? void 0 : _4.patchValue(rikkes.gigiMulut);
            (_5 = this.form.get('gigiD')) === null || _5 === void 0 ? void 0 : _5.patchValue(rikkes.gigiD);
            (_6 = this.form.get('gigiM')) === null || _6 === void 0 ? void 0 : _6.patchValue(rikkes.gigiM);
            (_7 = this.form.get('gigiF')) === null || _7 === void 0 ? void 0 : _7.patchValue(rikkes.gigiF);
            (_8 = this.form.get('karang')) === null || _8 === void 0 ? void 0 : _8.patchValue(rikkes.karang);
            (_9 = this.form.get('protesa')) === null || _9 === void 0 ? void 0 : _9.patchValue(rikkes.protesa);
            (_10 = this.form.get('penyMulut')) === null || _10 === void 0 ? void 0 : _10.patchValue(rikkes.penyMulut);
            (_11 = this.form.get('hidung')) === null || _11 === void 0 ? void 0 : _11.patchValue(rikkes.hidung);
            (_12 = this.form.get('tenggorokan')) === null || _12 === void 0 ? void 0 : _12.patchValue(rikkes.tenggorokan);
            (_13 = this.form.get('thoraxPernafasan')) === null || _13 === void 0 ? void 0 : _13.patchValue(rikkes.thoraxPernafasan);
            (_14 = this.form.get('thoraxBentuk')) === null || _14 === void 0 ? void 0 : _14.patchValue(rikkes.thoraxBentuk);
            (_15 = this.form.get('cor')) === null || _15 === void 0 ? void 0 : _15.patchValue(rikkes.cor);
            (_16 = this.form.get('pulmo')) === null || _16 === void 0 ? void 0 : _16.patchValue(rikkes.pulmo);
            (_17 = this.form.get('abdomen')) === null || _17 === void 0 ? void 0 : _17.patchValue(rikkes.abdomen);
            (_18 = this.form.get('lien')) === null || _18 === void 0 ? void 0 : _18.patchValue(rikkes.lien);
            (_19 = this.form.get('hepar')) === null || _19 === void 0 ? void 0 : _19.patchValue(rikkes.hepar);
            (_20 = this.form.get('regioInguinalis')) === null || _20 === void 0 ? void 0 : _20.patchValue(rikkes.regioInguinalis);
            (_21 = this.form.get('genitalia')) === null || _21 === void 0 ? void 0 : _21.patchValue(rikkes.genitalia);
            (_22 = this.form.get('perineum')) === null || _22 === void 0 ? void 0 : _22.patchValue(rikkes.perineum);
            (_23 = this.form.get('angGerakAtas')) === null || _23 === void 0 ? void 0 : _23.patchValue(rikkes.angGerakAtas);
            (_24 = this.form.get('angGerakBawah')) === null || _24 === void 0 ? void 0 : _24.patchValue(rikkes.angGerakBawah);
            (_25 = this.form.get('kulit')) === null || _25 === void 0 ? void 0 : _25.patchValue(rikkes.kulit);
            (_26 = this.form.get('refleks')) === null || _26 === void 0 ? void 0 : _26.patchValue(rikkes.refleks);
            (_27 = this.form.get('kesimpulanPemeriksaan')) === null || _27 === void 0 ? void 0 : _27.patchValue(rikkes.kesimpulanPemeriksaan);
            (_28 = this.form.get('U')) === null || _28 === void 0 ? void 0 : _28.patchValue(rikkes.U);
            (_29 = this.form.get('A')) === null || _29 === void 0 ? void 0 : _29.patchValue(rikkes.A);
            (_30 = this.form.get('B')) === null || _30 === void 0 ? void 0 : _30.patchValue(rikkes.B);
            (_31 = this.form.get('D')) === null || _31 === void 0 ? void 0 : _31.patchValue(rikkes.D);
            (_32 = this.form.get('L')) === null || _32 === void 0 ? void 0 : _32.patchValue(rikkes.L);
            (_33 = this.form.get('G')) === null || _33 === void 0 ? void 0 : _33.patchValue(rikkes.G);
            (_34 = this.form.get('J')) === null || _34 === void 0 ? void 0 : _34.patchValue(rikkes.J);
            (_35 = this.form.get('stakes')) === null || _35 === void 0 ? void 0 : _35.patchValue(rikkes.stakes);
            (_36 = this.form.get('hasil')) === null || _36 === void 0 ? void 0 : _36.patchValue(rikkes.hasil);
            (_37 = this.form.get('hasilLab')) === null || _37 === void 0 ? void 0 : _37.patchValue(rikkes.hasilLab);
            (_38 = this.form.get('hasilEkg')) === null || _38 === void 0 ? void 0 : _38.patchValue(rikkes.hasilEkg);
            (_39 = this.form.get('hasilRadiologi')) === null || _39 === void 0 ? void 0 : _39.patchValue(rikkes.hasilRadiologi);
            (_40 = this.form.get('hasilAudiometri')) === null || _40 === void 0 ? void 0 : _40.patchValue(rikkes.hasilAudiometri);
            (_41 = this.form.get('hasilKeswaKode')) === null || _41 === void 0 ? void 0 : _41.patchValue(rikkes.hasilKeswaKode);
            (_42 = this.form.get('hasilKeswaKeterangan')) === null || _42 === void 0 ? void 0 : _42.patchValue(rikkes.hasilKeswaKeterangan);
            (_43 = this.form.get('odontogramIdentifikasi')) === null || _43 === void 0 ? void 0 : _43.patchValue(rikkes.odontogramIdentifikasi);
            this.odontogram = data.odontogram;
        }
    }
    listenGetPeserta(e) {
        if (e.code === 'Enter') {
            this.getPeserta();
        }
        else {
            if (this.peserta.noUrut.length === 0) {
                this.initPeserta();
            }
        }
    }
    getPeserta() {
        this.dataPesertaService.getPesertaByNoUrut(this.peserta.noUrut);
    }
    getDataRikkes() {
        this.rikkesService.getDataRikkes(this.peserta.id);
    }
    save() {
        var _a;
        (_a = this.form.get('peserta')) === null || _a === void 0 ? void 0 : _a.patchValue(this.peserta);
        this.form.value.odontogram = this.odontogram;
        this.rikkesService.save(this.form.value);
    }
    update() {
        this.messageService.add({ severity: 'success', summary: 'Sukses!', detail: 'Data Berhasil Disimpan.' });
    }
    hitungBmi() {
        var _a, _b, _c;
        let tinggi = parseInt((_a = this.form.get('tinggi')) === null || _a === void 0 ? void 0 : _a.value) / 100;
        let berat = parseInt((_b = this.form.get('berat')) === null || _b === void 0 ? void 0 : _b.value);
        if (tinggi && berat) {
            let bmi = berat / (tinggi * tinggi);
            bmi = Math.round(bmi * 10) / 10;
            if (this.peserta.jnsKelamin.toLowerCase() == 'perempuan') {
                if (bmi >= 19 && bmi <= 23.9) {
                    this.hasilBmi = 'STAKES 1';
                }
                else if (bmi >= 24 && bmi <= 25.9) {
                    this.hasilBmi = 'STAKES 2';
                }
                else if (bmi >= 18.5 && bmi <= 18.9) {
                    this.hasilBmi = 'STAKES 2';
                }
                else if (bmi >= 26 && bmi <= 28.9) {
                    this.hasilBmi = 'STAKES 3';
                }
                else if (bmi >= 15 && bmi <= 18.4) {
                    this.hasilBmi = 'STAKES 3';
                }
                else if (bmi >= 29 || bmi <= 14.9) {
                    this.hasilBmi = 'STAKES 4';
                }
            }
            if (this.peserta.jnsKelamin.toLowerCase() == 'laki-laki') {
                if (bmi >= 20 && bmi <= 24.9) {
                    this.hasilBmi = 'STAKES 1';
                }
                else if (bmi >= 18.5 && bmi <= 19.9) {
                    this.hasilBmi = 'STAKES 2';
                }
                else if (bmi >= 15 && bmi <= 18.4) {
                    this.hasilBmi = 'STAKES 2';
                }
                else if (bmi >= 27 && bmi <= 29.9) {
                    this.hasilBmi = 'STAKES 3';
                }
                else if (bmi >= 30 || bmi <= 14.9) {
                    this.hasilBmi = 'STAKES 4';
                }
            }
            (_c = this.form.get('imt')) === null || _c === void 0 ? void 0 : _c.patchValue(bmi);
        }
    }
    openDialogSimbolOdontogram(idx, data, location) {
        data.idx = idx;
        data.location = location;
        this.selectedOdontogram = data;
        this.dialogSimbolOdontogram = true;
    }
    setSimbolOdontogram(simbol) {
        let idx = this.selectedOdontogram.idx;
        if (this.selectedOdontogram.location == 'atas') {
            this.odontogram[idx].atas = simbol;
        }
        else if (this.selectedOdontogram.location == 'bawah') {
            this.odontogram[idx].bawah = simbol;
        }
        this.dialogSimbolOdontogram = false;
    }
    printSticker() {
        let iframe = '<iframe src="' + src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/printSticker/noUrut/' + this.peserta.noUrut) + '" style="height:calc(100% - 4px);width:calc(100% - 4px)"></iframe>';
        let win = window.open("", "", "width=1024,height=510,toolbar=no,menubar=no,resizable=yes");
        win.document.write(iframe);
    }
    printStickerPesertaRange() {
        let iframe = '<iframe src="' + src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/printStickerAllPeserta/dari/' + this.printNoUrut.dari + '/sampai/' + this.printNoUrut.sampai) + '" style="height:calc(100% - 4px);width:calc(100% - 4px)"></iframe>';
        let win = window.open("", "", "width=1024,height=510,toolbar=no,menubar=no,resizable=yes");
        win.document.write(iframe);
    }
    exportExcel() {
        let iframe = '<iframe src="' + src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/export') + '" style="height:calc(100% - 4px);width:calc(100% - 4px)"></iframe>';
        let win = window.open("", "", "width=1024,height=510,toolbar=no,menubar=no,resizable=yes");
        win.document.write(iframe);
    }
    exportExcelAllData() {
        let iframe = '<iframe src="' + src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/exportAllData') + '" style="height:calc(100% - 4px);width:calc(100% - 4px)"></iframe>';
        let win = window.open("", "", "width=1024,height=510,toolbar=no,menubar=no,resizable=yes");
        win.document.write(iframe);
    }
}
RikkesComponent.ɵfac = function RikkesComponent_Factory(t) { return new (t || RikkesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_rikkes_service__WEBPACK_IMPORTED_MODULE_1__.RikkesService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_data_peserta_data_peserta_service__WEBPACK_IMPORTED_MODULE_2__.DataPesertaService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_upload_file_upload_file_service__WEBPACK_IMPORTED_MODULE_3__.UploadFileService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_radiologi_radiologi_service__WEBPACK_IMPORTED_MODULE_4__.RadiologiService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_laboratorium_laboratorium_service__WEBPACK_IMPORTED_MODULE_5__.LaboratoriumService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_12__.MessageService)); };
RikkesComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({ type: RikkesComponent, selectors: [["app-rikkes"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵProvidersFeature"]([primeng_api__WEBPACK_IMPORTED_MODULE_12__.MessageService])], decls: 498, vars: 96, consts: [["header", "Data Peserta", 3, "visible", "modal", "draggable", "visibleChange", "onHide"], ["header", "Upload File / Photo", 3, "visible", "modal", "draggable", "visibleChange", "onHide"], ["header", "Laboratorium", 3, "visible", "modal", "draggable", "visibleChange", "onHide"], ["header", "Radiologi", 3, "visible", "modal", "draggable", "visibleChange", "onHide"], ["appendTo", "body", "header", "Simbol Identifikasi", 3, "visible", "modal", "showHeader", "visibleChange"], [1, "row", "tx-24"], [1, "col", "p-2"], [1, "btn", "btn-light", "tx-black", 3, "click"], [1, "bi", "bi-square"], [1, "bi", "bi-circle"], [1, "bi", "bi-x-lg"], [1, "bi", "bi-check-lg"], [1, "bi", "bi-circle-fill"], [1, "bi", "bi-activity"], [1, "btn", "btn-light", "tx-black", "pt-2", 3, "click"], ["height", "25", 1, "mb-1", 3, "src"], ["height", "28", 1, "mb-1", 3, "src"], ["pTemplate", "footer"], ["header", "Print Sticker Peserta", 3, "visible", "breakpoints", "modal", "draggable", "visibleChange"], [1, "row", "mb-3", "pb-3", "border-bottom"], [1, "col-4"], ["type", "text", 1, "form-control", 3, "ngModel"], [1, "col-2"], [1, "btn", "btn-primary", 3, "disabled", "click"], [1, "bi", "bi-printer", "mr-1"], [1, "row", "mt-0"], [1, "col-auto"], ["type", "text", "placeholder", "No.Urut Dari", "maxlength", "5", 1, "form-control", 3, "ngModel", "ngModelChange"], ["type", "text", "placeholder", "No.Urut Sampai", "maxlength", "5", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "col"], [1, "row", "pl-3", "pr-3", "sticky-top", 2, "margin-left", "-14px", "margin-right", "-14px", "top", "45px"], [1, "col", "p-3", "bg-gray-400"], [1, "row"], [1, "btn", "btn-sm", "btn-secondary", "mr-1", "mb-1", 3, "click"], [1, "bi", "bi-file-earmark-person", "mr-1"], [1, "btn", "btn-sm", "btn-secondary", "mr-1", "mb-1", 3, "disabled", "click"], [1, "bi", "bi-upload", "mr-1"], [1, "bi", "bi-droplet-half", "mr-1"], [1, "bi", "bi-radioactive", "mr-1"], [1, "bi", "bi-file-earmark-ruled", "mr-1"], [1, "bi", "bi-chevron-down"], ["appendTo", "body", "appendTo", "body", 3, "popup", "model"], ["submenuExport", ""], [1, "btn", "btn-sm", "btn-secondary", "mr-5", "mb-1", 3, "click"], [1, "bi", "bi-arrow-repeat", "mr-1"], [1, "row", "m-0", "bg-light", "p-3", "mb-3"], [1, "col-md-4", "col-sm-6"], [1, "input-group"], ["type", "text", "placeholder", "No. Urut", 1, "form-control", 3, "readOnly", "ngModel", "click", "ngModelChange", "keyup"], ["type", "text", "placeholder", "No. Peserta", "readonly", "", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "input-group-append"], [1, "btn", "btn-secondary", 3, "click"], [1, "bi", "bi-search"], ["type", "text", "readonly", "", 1, "form-control", "tx-uppercase", 3, "ngModel", "ngModelChange"], [1, "col-md-2", "col-sm-6"], [1, "row", "pl-3", "pr-3", "mb-3"], [1, "col-md-6", "col-sm-12"], [3, "formGroup"], [1, "row", "mb-2"], [1, "col-3", "col-form-label"], ["type", "text", "formControlName", "anamnesa", 1, "form-control"], ["type", "text", "formControlName", "tinggi", 1, "form-control", 3, "blur"], [1, "input-group-text"], ["type", "text", "formControlName", "berat", 1, "form-control", 3, "blur"], ["type", "text", "formControlName", "imt", 1, "form-control"], [1, "input-group-text", "pl-3", "pr-3"], ["type", "text", "formControlName", "tekananDarah", 1, "form-control"], ["type", "text", "formControlName", "nadi", 1, "form-control"], [1, "col-3"], ["type", "text", "formControlName", "tubuhBentuk", 1, "form-control"], [1, "w-100", "mb-2"], ["type", "text", "formControlName", "tubuhGerak", 1, "form-control"], ["type", "text", "formControlName", "kepala", 1, "form-control"], ["type", "text", "formControlName", "muka", 1, "form-control"], ["type", "text", "formControlName", "leher", 1, "form-control"], ["type", "text", "formControlName", "mata", 1, "form-control"], [1, "w-100"], [1, "col", "mt-2"], [1, "table", "border-bottom"], ["type", "text", "formControlName", "od1", 1, "form-control"], ["type", "text", "formControlName", "od2", 1, "form-control"], [1, "pr-0"], ["type", "text", "formControlName", "od3", 1, "form-control"], ["type", "text", "formControlName", "os1", 1, "form-control"], ["type", "text", "formControlName", "os2", 1, "form-control"], ["type", "text", "formControlName", "os3", 1, "form-control"], [1, "col-4", "pl-4"], ["type", "text", "formControlName", "campus", 1, "form-control"], ["type", "text", "formControlName", "kenalWarna", 1, "form-control"], ["type", "text", "formControlName", "lainLain", 1, "form-control"], [1, "col-auto", "col-form-label"], ["type", "text", "formControlName", "telinga", 1, "form-control"], [1, "input-group-prepend"], ["type", "text", "formControlName", "ad", 1, "form-control"], ["type", "text", "formControlName", "as", 1, "form-control"], ["type", "text", "formControlName", "tajamPend", 1, "form-control"], ["type", "text", "formControlName", "membranTymp", 1, "form-control"], ["type", "text", "formControlName", "penyTel", 1, "form-control"], [1, "col-4", "col-form-label"], ["type", "text", "formControlName", "hidung", 1, "form-control"], ["type", "text", "formControlName", "tenggorokan", 1, "form-control"], ["type", "text", "formControlName", "gigiMulut", 1, "form-control"], [1, "w-100", "mt-2", "mb-1"], [1, "col-5"], [1, "col-2", "col-form-label"], ["type", "text", "formControlName", "gigiD", 1, "form-control"], ["type", "text", "formControlName", "gigiM", 1, "form-control"], ["type", "text", "formControlName", "gigiF", 1, "form-control"], [1, "col-7"], ["type", "text", "formControlName", "karang", 1, "form-control"], ["type", "text", "formControlName", "protesa", 1, "form-control"], ["type", "text", "formControlName", "penyMulut", 1, "form-control"], [1, "tx-center", "tx-14"], [1, "mb-2"], ["type", "text", "formControlName", "odontogramIdentifikasi", 1, "form-control"], [1, "d-flex", "flex-row", "mb-3", "justify-content-center"], ["class", "mr-1 flex-fill tx-center", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "col-auto", "pt-0", "col-form-label"], ["type", "text", "formControlName", "thoraxPernafasan", 1, "form-control"], ["type", "text", "formControlName", "thoraxBentuk", 1, "form-control"], ["type", "text", "formControlName", "cor", 1, "form-control"], ["type", "text", "formControlName", "pulmo", 1, "form-control"], ["type", "text", "formControlName", "abdomen", 1, "form-control"], ["type", "text", "formControlName", "lien", 1, "form-control"], ["type", "text", "formControlName", "hepar", 1, "form-control"], ["type", "text", "formControlName", "regioInguinalis", 1, "form-control"], ["type", "text", "formControlName", "genitalia", 1, "form-control"], ["type", "text", "formControlName", "perineum", 1, "form-control"], ["type", "text", "formControlName", "angGerakAtas", 1, "form-control"], ["type", "text", "formControlName", "angGerakBawah", 1, "form-control"], ["type", "text", "formControlName", "kulit", 1, "form-control"], ["type", "text", "formControlName", "refleks", 1, "form-control"], [1, "col", "col-form-label"], ["pInputTextarea", "", "formControlName", "hasilLab", 3, "autoResize"], ["pInputTextarea", "", "formControlName", "hasilEkg", 3, "autoResize"], ["styleClass", "hiddenToolbar", "formControlName", "hasilRadiologi"], ["pInputTextarea", "", "formControlName", "hasilAudiometri", 3, "autoResize"], ["optionLabel", "name", "optionValue", "name", "formControlName", "hasilKeswaKode", "styleClass", "mb-1", 3, "options", "autoDisplayFirst"], ["pInputTextarea", "", "formControlName", "hasilKeswaKeterangan", 3, "autoResize"], [1, "col-12", "mt-5"], [1, "tx-16", "mb-2"], ["pInputTextarea", "", "formControlName", "kesimpulanPemeriksaan", 3, "autoResize"], [1, "tx-center", "pl-0"], [1, "tx-center"], [1, "pl-0"], ["type", "text", "formControlName", "U", 1, "form-control"], ["type", "text", "formControlName", "A", 1, "form-control"], ["type", "text", "formControlName", "B", 1, "form-control"], ["type", "text", "formControlName", "D", 1, "form-control"], ["type", "text", "formControlName", "L", 1, "form-control"], ["type", "text", "formControlName", "G", 1, "form-control"], ["type", "text", "formControlName", "J", 1, "form-control"], ["type", "text", "formControlName", "stakes", 1, "form-control", "mb-2"], ["optionLabel", "name", "optionValue", "name", "formControlName", "hasil", 3, "options"], [1, "row", "bg-gray-400", "p-3"], [1, "col-10"], [1, "bi", "bi-save", "mr-1"], [4, "ngIf"], ["position", "top-center"], [1, "btn", "btn-xs", "btn-icon", "btn-dark", 3, "click"], [1, "bi", "bi-trash", "mr-1"], [1, "mr-1", "flex-fill", "tx-center", 3, "ngClass"], [1, "clickable", "bg-gray-200", "tx-16", 3, "click"], ["class", "tx-black", 4, "ngIf"], [1, "tx-black"], ["class", "bi bi-square", 4, "ngIf"], ["class", "bi bi-circle", 4, "ngIf"], ["class", "bi bi-x-lg", 4, "ngIf"], ["class", "bi bi-check-lg", 4, "ngIf"], ["class", "bi bi-circle-fill", 4, "ngIf"], ["class", "bi bi-activity", 4, "ngIf"], ["height", "16", "style", "margin-top: -4px;", 3, "src", 4, "ngIf"], ["height", "16", "style", "margin-top: -2px;", 3, "src", 4, "ngIf"], ["height", "16", 2, "margin-top", "-4px", 3, "src"], ["height", "16", 2, "margin-top", "-2px", 3, "src"], [1, "p-2", "tx-bold", "pl-4", "pr-4"]], template: function RikkesComponent_Template(rf, ctx) { if (rf & 1) {
        const _r40 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "p-dialog", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("visibleChange", function RikkesComponent_Template_p_dialog_visibleChange_0_listener($event) { return ctx.dialogDataPeserta = $event; })("onHide", function RikkesComponent_Template_p_dialog_onHide_0_listener() { return ctx.dataPesertaService.closeDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "app-data-peserta");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "p-dialog", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("visibleChange", function RikkesComponent_Template_p_dialog_visibleChange_2_listener($event) { return ctx.dialogUploadFile = $event; })("onHide", function RikkesComponent_Template_p_dialog_onHide_2_listener() { return ctx.uploadFileService.closeDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](3, "app-upload-file");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "p-dialog", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("visibleChange", function RikkesComponent_Template_p_dialog_visibleChange_4_listener($event) { return ctx.dialogLaboratorium = $event; })("onHide", function RikkesComponent_Template_p_dialog_onHide_4_listener() { return ctx.laboratoriumService.closeDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](5, "app-laboratorium");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](6, "p-dialog", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("visibleChange", function RikkesComponent_Template_p_dialog_visibleChange_6_listener($event) { return ctx.dialogRadiologi = $event; })("onHide", function RikkesComponent_Template_p_dialog_onHide_6_listener() { return ctx.radiologiService.closeDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](7, "app-radiologi");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](8, "p-dialog", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("visibleChange", function RikkesComponent_Template_p_dialog_visibleChange_8_listener($event) { return ctx.dialogSimbolOdontogram = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](9, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](11, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_11_listener() { return ctx.setSimbolOdontogram("s"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](12, "i", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](13, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](14, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_14_listener() { return ctx.setSimbolOdontogram("c"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](15, "i", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](16, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](17, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_17_listener() { return ctx.setSimbolOdontogram("x"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](18, "i", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](19, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](20, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_20_listener() { return ctx.setSimbolOdontogram("ck"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](21, "i", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](22, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](23, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_23_listener() { return ctx.setSimbolOdontogram("cf"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](24, "i", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](25, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](26, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_26_listener() { return ctx.setSimbolOdontogram("a"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](27, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](28, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](29, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_29_listener() { return ctx.setSimbolOdontogram("ac"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](30, "img", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](31, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](32, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_32_listener() { return ctx.setSimbolOdontogram("dc"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](33, "img", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](34, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](35, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_35_listener() { return ctx.setSimbolOdontogram("ds"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](36, "img", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](37, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](38, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_38_listener() { return ctx.setSimbolOdontogram("cs"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](39, "img", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](40, RikkesComponent_ng_template_40_Template, 3, 0, "ng-template", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](41, "p-dialog", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("visibleChange", function RikkesComponent_Template_p_dialog_visibleChange_41_listener($event) { return ctx.dialogPrintSticker = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](42, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](43, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](44, "Nama : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](45, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](46, "uppercase");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](47, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](48, "No.Urut : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](49, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](50, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](51, "No.Peserta :");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](52, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](53, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](54, "Jns.Kelamin :");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](55, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](56, "uppercase");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](57, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](58, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](59, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_59_listener() { return ctx.printSticker(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](60, "i", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](61, " Print");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](62, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](63, "Print Sticker Berdasarkan Rentang No.Urut");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](64, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](65, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](66, "input", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function RikkesComponent_Template_input_ngModelChange_66_listener($event) { return ctx.printNoUrut.dari = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](67, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](68, "input", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function RikkesComponent_Template_input_ngModelChange_68_listener($event) { return ctx.printNoUrut.sampai = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](69, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](70, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_70_listener() { return ctx.printStickerPesertaRange(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](71, "i", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](72, " Print");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](73, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](74, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](75, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](76, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](77, "button", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_77_listener() { return ctx.dataPesertaService.openDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](78, "i", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](79, " Data Peserta");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](80, "button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_80_listener() { return ctx.uploadFileService.openDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](81, "i", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](82, " Upload File / Photo");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](83, "button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_83_listener() { return ctx.laboratoriumService.openDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](84, "i", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](85, " Laboratorium");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](86, "button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_86_listener() { return ctx.radiologiService.openDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](87, "i", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](88, " Radiologi");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](89, "button", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_89_listener() { return ctx.dialogPrintSticker = true; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](90, "i", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](91, " Print Sticker");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](92, "button", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_92_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r40); const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](97); return _r1.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](93, "i", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](94, " Export XSL ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](95, "i", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](96, "p-menu", 41, 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](98, "button", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_98_listener() { return ctx.initForm(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](99, "i", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](100, " Refresh");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](101, "div", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](102, "div", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](103, " Nomor Peserta : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](104, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](105, "input", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_input_click_105_listener() { return ctx.clearForm(); })("ngModelChange", function RikkesComponent_Template_input_ngModelChange_105_listener($event) { return ctx.peserta.noUrut = $event; })("keyup", function RikkesComponent_Template_input_keyup_105_listener($event) { return ctx.listenGetPeserta($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](106, "input", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function RikkesComponent_Template_input_ngModelChange_106_listener($event) { return ctx.peserta.noPeserta = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](107, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](108, "button", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_108_listener() { return ctx.getPeserta(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](109, "i", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](110, "div", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](111, " Nama : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](112, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](113, "input", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function RikkesComponent_Template_input_ngModelChange_113_listener($event) { return ctx.peserta.nama = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](114, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](115, " Tgl. Lahir : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](116, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](117, "input", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function RikkesComponent_Template_input_ngModelChange_117_listener($event) { return ctx.peserta.tglLahir = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](118, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](119, " Jenis Kelamin : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](120, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](121, "input", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function RikkesComponent_Template_input_ngModelChange_121_listener($event) { return ctx.peserta.jnsKelamin = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](122, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](123, "div", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](124, "form", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](125, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](126, "label", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](127, " Anamnese ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](128, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](129, "input", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](130, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](131, "label", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](132, " Tinggi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](133, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](134, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](135, "input", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("blur", function RikkesComponent_Template_input_blur_135_listener() { return ctx.hitungBmi(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](136, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](137, "span", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](138, "Cm");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](139, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](140, "label", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](141, " Berat ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](142, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](143, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](144, "input", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("blur", function RikkesComponent_Template_input_blur_144_listener() { return ctx.hitungBmi(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](145, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](146, "span", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](147, "Kg");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](148, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](149, "label", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](150, " IMT ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](151, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](152, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](153, "input", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](154, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](155, "span", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](156);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](157, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](158, "label", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](159, " Tekanan Darah ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](160, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](161, "input", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](162, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](163, "label", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](164, " Nadi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](165, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](166, "input", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](167, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](168, "label", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](169, " Tubuh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](170, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](171, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](172, "div", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](173, "Bentuk");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](174, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](175, "input", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](176, "div", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](177, "div", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](178, "Gerakan");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](179, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](180, "input", 71);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](181, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](182, "label", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](183, " Kepala ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](184, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](185, "input", 72);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](186, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](187, "label", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](188, " Muka ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](189, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](190, "input", 73);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](191, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](192, "label", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](193, " Leher ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](194, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](195, "input", 74);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](196, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](197, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](198, "label", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](199, " Mata ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](200, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](201, "input", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](202, "div", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](203, "label", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](204, "div", 77);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](205, "table", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](206, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](207, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](208, "O.D");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](209, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](210, "input", 79);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](211, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](212, "input", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](213, "td", 81);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](214, "input", 82);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](215, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](216, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](217, "O.S");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](218, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](219, "input", 83);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](220, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](221, "input", 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](222, "td", 81);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](223, "input", 85);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](224, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](225, "div", 86);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](226, "Campus");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](227, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](228, "input", 87);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](229, "div", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](230, "div", 86);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](231, "Kenal Warna");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](232, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](233, "input", 88);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](234, "div", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](235, "div", 86);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](236, "Lain-lain");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](237, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](238, "input", 89);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](239, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](240, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](241, "label", 90);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](242, " Telinga ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](243, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](244, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](245, "input", 91);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](246, "div", 92);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](247, "span", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](248, "AD");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](249, "input", 93);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](250, "div", 92);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](251, "span", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](252, "AS");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](253, "input", 94);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](254, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](255, "div", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](256, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](257, "Tajam Pend.");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](258, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](259, "input", 95);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](260, "div", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](261, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](262, "Membran Tymp");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](263, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](264, "input", 96);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](265, "div", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](266, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](267, "Peny. Tel");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](268, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](269, "input", 97);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](270, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](271, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](272, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](273, " Hidung ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](274, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](275, "input", 99);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](276, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](277, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](278, " Tenggorokan ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](279, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](280, "input", 100);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](281, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](282, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](283, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](284, " Gigi - Mulut ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](285, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](286, "input", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](287, "div", 102);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](288, "div", 103);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](289, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](290, "label", 104);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](291, " D ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](292, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](293, "input", 105);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](294, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](295, "label", 104);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](296, " M ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](297, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](298, "input", 106);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](299, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](300, "label", 104);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](301, " F ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](302, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](303, "input", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](304, "div", 108);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](305, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](306, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](307, " Karang ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](308, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](309, "input", 109);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](310, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](311, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](312, " Protesa ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](313, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](314, "input", 110);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](315, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](316, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](317, " Peny. Mulut ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](318, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](319, "input", 111);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](320, "div", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](321, "h4", 112);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](322, "ODONTOGRAM IDENTIFIKASI");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](323, "div", 113);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](324, "input", 114);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](325, "div", 115);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](326, RikkesComponent_div_326_Template, 9, 8, "div", 116);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](327, "div", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](328, "form", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](329, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](330, "label", 117);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](331, " Thorax ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](332, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](333, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](334, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](335, "a. Pernafasan");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](336, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](337, "input", 118);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](338, "div", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](339, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](340, "b. Bentuk");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](341, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](342, "input", 119);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](343, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](344, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](345, " COR ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](346, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](347, "input", 120);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](348, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](349, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](350, " Pulmo ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](351, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](352, "input", 121);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](353, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](354, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](355, " Abdomen ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](356, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](357, "input", 122);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](358, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](359, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](360, " Lien ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](361, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](362, "input", 123);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](363, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](364, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](365, " Hepar ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](366, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](367, "input", 124);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](368, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](369, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](370, " Regio Inguinalis ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](371, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](372, "input", 125);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](373, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](374, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](375, " Genitalia ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](376, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](377, "input", 126);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](378, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](379, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](380, " Perineum ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](381, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](382, "input", 127);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](383, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](384, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](385, " Ang. Gerak Atas ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](386, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](387, "input", 128);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](388, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](389, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](390, " Ang. Gerak Bawah ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](391, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](392, "input", 129);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](393, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](394, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](395, " Kulit ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](396, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](397, "input", 130);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](398, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](399, "label", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](400, " Refleks ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](401, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](402, "input", 131);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](403, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](404, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](405, "label", 132);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](406, " Hasil Lab ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](407, "div", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](408, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](409, "textarea", 133);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](410, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](411, "label", 132);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](412, " Hasil EKG ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](413, "div", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](414, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](415, "textarea", 134);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](416, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](417, "label", 132);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](418, " Hasil Radiologi ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](419, "div", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](420, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](421, "p-editor", 135);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](422, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](423, "label", 132);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](424, " Hasil Audiometri ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](425, "div", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](426, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](427, "textarea", 136);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](428, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](429, "label", 132);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](430, " Hasil Keswa ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](431, "div", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](432, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](433, "p-dropdown", 137);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](434, "textarea", 138);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](435, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](436, "div", 139);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](437, "form", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](438, "h4", 140);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](439, "KESIMPULAN PEMERIKSAAN");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](440, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](441, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](442, "textarea", 141);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](443, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](444, "label", 104);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](445, " Rumus ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](446, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](447, "table", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](448, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](449, "td", 142);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](450, "U");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](451, "td", 143);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](452, "A");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](453, "td", 143);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](454, "B");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](455, "td", 143);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](456, "D");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](457, "td", 143);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](458, "L");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](459, "td", 143);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](460, "G");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](461, "td", 143);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](462, "J");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](463, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](464, "td", 144);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](465, "input", 145);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](466, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](467, "input", 146);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](468, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](469, "input", 147);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](470, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](471, "input", 148);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](472, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](473, "input", 149);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](474, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](475, "input", 150);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](476, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](477, "input", 151);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](478, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](479, "label", 104);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](480, " Stakes ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](481, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](482, "input", 152);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](483, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](484, "label", 104);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](485, " Hasil ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](486, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](487, "p-selectButton", 153);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](488, RikkesComponent_ng_template_488_Template, 2, 1, "ng-template");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](489, "div", 154);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](490, "label", 104);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](491, "\u00A0");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](492, "div", 155);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](493, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function RikkesComponent_Template_button_click_493_listener() { return ctx.save(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](494, "i", 156);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](495, RikkesComponent_span_495_Template, 2, 0, "span", 157);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](496, RikkesComponent_span_496_Template, 2, 0, "span", 157);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](497, "p-toast", 158);
    } if (rf & 2) {
        let tmp_67_0;
        let tmp_68_0;
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](84, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("visible", ctx.dialogDataPeserta)("modal", true)("draggable", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](85, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("visible", ctx.dialogUploadFile)("modal", true)("draggable", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](86, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("visible", ctx.dialogLaboratorium)("modal", true)("draggable", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](87, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("visible", ctx.dialogRadiologi)("modal", true)("draggable", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("visible", ctx.dialogSimbolOdontogram)("modal", true)("showHeader", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](22);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", "assets/ac.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", "assets/dc.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", "assets/ds.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", "assets/cs.png", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](88, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("visible", ctx.dialogPrintSticker)("breakpoints", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](89, _c4))("modal", true)("draggable", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](46, 80, ctx.peserta.nama));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", ctx.peserta.noUrut);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", ctx.peserta.noPeserta);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](56, 82, ctx.peserta.jnsKelamin));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx.peserta.noUrut);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", ctx.printNoUrut.dari);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", ctx.printNoUrut.sampai);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx.printNoUrut.dari || !ctx.printNoUrut.sampai);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx.peserta.id);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx.peserta.id);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx.peserta.id);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("popup", true)("model", ctx.menuExport);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("readOnly", ctx.peserta.nama)("ngModel", ctx.peserta.noUrut);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", ctx.peserta.noPeserta);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", ctx.peserta.nama);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", ctx.peserta.tglLahir);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngModel", ctx.peserta.jnsKelamin);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx.form);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](32);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](ctx.hasilBmi);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](170);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.odontogram);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx.form);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](81);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](90, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("autoResize", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](91, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("autoResize", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](92, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("autoResize", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](93, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("options", ctx.keswaKesimpulan)("autoDisplayFirst", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](94, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("autoResize", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx.form);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction0"](95, _c5));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("autoResize", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](45);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("options", ctx.hasil);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", ctx.form.invalid || !ctx.peserta.id);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !((tmp_67_0 = ctx.form.get("id")) == null ? null : tmp_67_0.value));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", (tmp_68_0 = ctx.form.get("id")) == null ? null : tmp_68_0.value);
    } }, directives: [primeng_dialog__WEBPACK_IMPORTED_MODULE_13__.Dialog, _data_peserta_data_peserta_component__WEBPACK_IMPORTED_MODULE_6__.DataPesertaComponent, _upload_file_upload_file_component__WEBPACK_IMPORTED_MODULE_7__.UploadFileComponent, _laboratorium_laboratorium_component__WEBPACK_IMPORTED_MODULE_8__.LaboratoriumComponent, _radiologi_radiologi_component__WEBPACK_IMPORTED_MODULE_9__.RadiologiComponent, primeng_api__WEBPACK_IMPORTED_MODULE_12__.PrimeTemplate, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.MaxLengthValidator, primeng_menu__WEBPACK_IMPORTED_MODULE_14__.Menu, _angular_forms__WEBPACK_IMPORTED_MODULE_11__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormControlName, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgForOf, primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_16__.InputTextarea, primeng_editor__WEBPACK_IMPORTED_MODULE_17__.Editor, primeng_dropdown__WEBPACK_IMPORTED_MODULE_18__.Dropdown, primeng_selectbutton__WEBPACK_IMPORTED_MODULE_19__.SelectButton, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, primeng_toast__WEBPACK_IMPORTED_MODULE_20__.Toast, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgClass], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.UpperCasePipe], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyaWtrZXMuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 42469:
/*!*****************************************************!*\
  !*** ./src/app/components/rikkes/rikkes.service.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RikkesService": function() { return /* binding */ RikkesService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 53882);




class RikkesService {
    constructor(http) {
        this.http = http;
        this.dataRikkes = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
        this.saveStatus = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(false);
    }
    save(data) {
        this.http.post(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/save'), data)
            .subscribe(res => {
            if (res.code == 200) {
                this.saveStatus.next(true);
                this.getDataRikkes(data.peserta.id);
            }
        });
    }
    getDataRikkes(idPeserta) {
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('rikkes/getData/idPeserta/' + idPeserta))
            .subscribe(data => this.dataRikkes.next(data.data));
    }
}
RikkesService.ɵfac = function RikkesService_Factory(t) { return new (t || RikkesService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient)); };
RikkesService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: RikkesService, factory: RikkesService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 84353:
/*!************************************************************************!*\
  !*** ./src/app/components/rikkes/upload-file/upload-file.component.ts ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UploadFileComponent": function() { return /* binding */ UploadFileComponent; }
/* harmony export */ });
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var _data_peserta_data_peserta_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data-peserta/data-peserta.service */ 33890);
/* harmony import */ var _upload_file_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./upload-file.service */ 60834);
/* harmony import */ var primeng_fileupload__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/fileupload */ 81592);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/api */ 88055);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var primeng_progressbar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/progressbar */ 35019);
/* harmony import */ var primeng_image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/image */ 21902);










const _c0 = ["fileInput"];
const _c1 = function () { return { height: "4px" }; };
function UploadFileComponent_ng_template_4_p_progressBar_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "p-progressBar", 12);
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](2, _c1));
} }
function UploadFileComponent_ng_template_4_tr_18_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "p-image", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UploadFileComponent_ng_template_4_tr_18_Template_button_click_8_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6); const item_r4 = restoredCtx.$implicit; const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2); return ctx_r5.deleteImage(item_r4); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](9, "i", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10, " Hapus");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpropertyInterpolate"]("alt", item_r4.filename);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", ctx_r3.getImage(item_r4.file_location))("preview", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](item_r4.filename);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](item_r4.size);
} }
function UploadFileComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, UploadFileComponent_ng_template_4_p_progressBar_0_Template, 1, 3, "p-progressBar", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "h2", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "i", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, " UPLOAD FILES");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6, "Pilih File atau Drag and Drop Di Sini.");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "table", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "thead");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](11, "Photo / File");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](13, "Filename");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Size");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](17, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](18, UploadFileComponent_ng_template_4_tr_18_Template, 11, 5, "tr", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r1.loading);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx_r1.uploadedFiles);
} }
class UploadFileComponent {
    constructor(http, dataPesertaService, uploadFileService) {
        this.http = http;
        this.dataPesertaService = dataPesertaService;
        this.uploadFileService = uploadFileService;
        this.uploadedFiles = [];
        this.loading = false;
    }
    ngOnInit() {
        this.dataPesertaService.peserta.subscribe(data => this.handleGetPeserta(data));
        this.uploadFileService.filesUplaoded.subscribe(data => this.uploadedFiles = data);
        this.uploadFileService.loading.subscribe(data => this.loading = data);
        this.uploadFileService.deleteStatus.subscribe(data => {
            if (data)
                this.uploadFileService.getFilesUploaded(this.peserta.id);
        });
    }
    handleGetPeserta(data) {
        if (data) {
            this.peserta = data;
            this.uploadFileService.getFilesUploaded(this.peserta.id);
        }
        else {
            this.uploadedFiles = [];
        }
    }
    onUpload(event) {
        const formData = new FormData();
        event.files.forEach((element) => {
            this.uploadFileService.loading.next(true);
            formData.append('file', element);
            formData.append('idPeserta', this.peserta.id);
            this.http.post(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('upload'), formData)
                .subscribe(data => {
                this.uploadedFiles.push(data.data);
                let i = event.files.length--;
                this.fileInput.remove(event, i);
                this.uploadFileService.loading.next(false);
            });
        });
    }
    getImage(image) {
        return src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.host + '/' + image;
    }
    deleteImage(item) {
        this.uploadFileService.deleteImage(item);
    }
    view(e) {
        console.log(e);
    }
}
UploadFileComponent.ɵfac = function UploadFileComponent_Factory(t) { return new (t || UploadFileComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_data_peserta_data_peserta_service__WEBPACK_IMPORTED_MODULE_1__.DataPesertaService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_upload_file_service__WEBPACK_IMPORTED_MODULE_2__.UploadFileService)); };
UploadFileComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: UploadFileComponent, selectors: [["app-upload-file"]], viewQuery: function UploadFileComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.fileInput = _t.first);
    } }, decls: 5, vars: 4, consts: [[1, "row"], [1, "col"], ["chooseLabel", "Pilih File", 3, "multiple", "customUpload", "auto", "chooseIcon", "uploadHandler"], ["fileInput", ""], ["pTemplate", "content"], ["mode", "indeterminate", 3, "style", 4, "ngIf"], [1, "rounded", "border", "bg-gray-100", "tx-center", "p-5", "tx-gray-500", "mt-1"], [1, "tx-gray-800"], [1, "bi", "bi-cloud-upload-fill", "mr-2"], [1, "tx-15"], [1, "table", "table-hover", "table-striped"], [4, "ngFor", "ngForOf"], ["mode", "indeterminate"], ["appendTo", "body", "height", "50", 3, "src", "alt", "preview"], [1, "btn", "btn-sm", "btn-outline-secondary", 3, "click"], [1, "bi", "bi-trash", "mr-1"]], template: function UploadFileComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "p-fileUpload", 2, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("uploadHandler", function UploadFileComponent_Template_p_fileUpload_uploadHandler_2_listener($event) { return ctx.onUpload($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](4, UploadFileComponent_ng_template_4_Template, 19, 2, "ng-template", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("multiple", true)("customUpload", true)("auto", false)("chooseIcon", "bi bi-upload");
    } }, directives: [primeng_fileupload__WEBPACK_IMPORTED_MODULE_5__.FileUpload, primeng_api__WEBPACK_IMPORTED_MODULE_6__.PrimeTemplate, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, primeng_progressbar__WEBPACK_IMPORTED_MODULE_8__.ProgressBar, primeng_image__WEBPACK_IMPORTED_MODULE_9__.Image], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ1cGxvYWQtZmlsZS5jb21wb25lbnQuY3NzIn0= */"] });


/***/ }),

/***/ 60834:
/*!**********************************************************************!*\
  !*** ./src/app/components/rikkes/upload-file/upload-file.service.ts ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UploadFileService": function() { return /* binding */ UploadFileService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 53882);




class UploadFileService {
    constructor(http) {
        this.http = http;
        this.dialog = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(false);
        this.filesUplaoded = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
        this.loading = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(false);
        this.deleteStatus = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(false);
    }
    getFilesUploaded(idPeserta) {
        this.loading.next(true);
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('upload/getFiles/idPeserta/' + idPeserta))
            .subscribe(data => {
            this.filesUplaoded.next(data.data);
            this.loading.next(false);
        });
    }
    deleteImage(item) {
        this.loading;
        this.http.post(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('upload/delete/image'), item)
            .subscribe(data => this.deleteStatus.next(true));
    }
    openDialog() {
        this.dialog.next(true);
    }
    closeDialog() {
        this.dialog.next(false);
    }
}
UploadFileService.ɵfac = function UploadFileService_Factory(t) { return new (t || UploadFileService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient)); };
UploadFileService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: UploadFileService, factory: UploadFileService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 39698:
/*!***************************!*\
  !*** ./src/app/config.ts ***!
  \***************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": function() { return /* binding */ config; }
/* harmony export */ });
var host = 'http://simrsmandiri.com/emr/api';
var hostVclaim = 'http://simrsmandiri.com/emr/vclaim/public/';
var hostPublic = 'http://182.253.22.220';
const config = {
    host: host,
    api_url: function (url) { return host + '/public/' + url; },
    api_vclaim: function (url) { return hostVclaim + url; },
    api_public: function (url) { return hostPublic + '/vclaim/index.php' + url; },
};


/***/ }),

/***/ 40946:
/*!******************************************!*\
  !*** ./src/app/error-handler.service.ts ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ErrorHandlerService": function() { return /* binding */ ErrorHandlerService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 45871);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);


class ErrorHandlerService {
    constructor() { }
    handleIt(error) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            // console.error('An error occurred:', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            // console.error(error);
            alert(error.message);
            //  console.error(
            //     `Backend returned code ${error.status}, ` +
            //     `body was: ${error.error}`);
        }
        // return an observable with a user-facing error message
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_0__.throwError)('Something bad happened; please try again later.');
        // return throwError(error || "Server Error");
    }
}
ErrorHandlerService.ɵfac = function ErrorHandlerService_Factory(t) { return new (t || ErrorHandlerService)(); };
ErrorHandlerService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: ErrorHandlerService, factory: ErrorHandlerService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 95819:
/*!**********************************************************************************!*\
  !*** ./src/app/modules/registrasi/components/data-pasien/data-pasien.service.ts ***!
  \**********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataPasienService": function() { return /* binding */ DataPasienService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/loading.service */ 4471);





class DataPasienService {
    constructor(http, loadingService) {
        this.http = http;
        this.loadingService = loadingService;
        this.dataPasien = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject('');
        this.sendToForm = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject(false);
        this.pasien = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject('');
        // showDialog = new BehaviorSubject<boolean>(false);
        this.dialog = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject(false);
    }
    getDataPasien(data) {
        this.loadingService.status.next(true);
        this.http.post(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('pasien/filtering'), data).subscribe(data => this.dataPasien.next(data.data));
    }
    openDialog() {
        this.dialog.next(true);
    }
    closeDialog() {
        this.dialog.next(false);
    }
}
DataPasienService.ɵfac = function DataPasienService_Factory(t) { return new (t || DataPasienService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_1__.LoadingService)); };
DataPasienService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: DataPasienService, factory: DataPasienService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 99787:
/*!***************************************************************************!*\
  !*** ./src/app/modules/shared/numpad-racikan/numpad-racikan.component.ts ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumpadRacikanComponent": function() { return /* binding */ NumpadRacikanComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _numpad_racikan_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./numpad-racikan.service */ 88989);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 54364);



function NumpadRacikanComponent_div_3_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_div_3_div_1_Template_div_click_0_listener($event) { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r6); const item2_r4 = restoredCtx.$implicit; const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2); return ctx_r5.selectNumber(item2_r4, $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item2_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item2_r4);
} }
function NumpadRacikanComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, NumpadRacikanComponent_div_3_div_1_Template, 2, 1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", item_r2);
} }
function NumpadRacikanComponent_div_6_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_div_6_div_1_Template_div_click_0_listener($event) { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r11); const item2_r9 = restoredCtx.$implicit; const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2); return ctx_r10.selectNumber(item2_r9, $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item2_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item2_r9);
} }
function NumpadRacikanComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, NumpadRacikanComponent_div_6_div_1_Template, 2, 1, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", item_r7);
} }
class NumpadRacikanComponent {
    constructor(numpadRacikanService) {
        this.numpadRacikanService = numpadRacikanService;
        this.numbers = [];
        this.numbersHundred = [];
        this.number = '';
        this.satuan = '';
    }
    ngOnInit() {
        this.numpadRacikanService.value.subscribe(data => this.handleValue(data));
        this.parsingNomor();
        this.resetActiveNumpad();
    }
    handleValue(value) {
        if (value == '') {
            this.resetActiveNumpad();
        }
    }
    selectNumber(number, e) {
        this.number = number;
        this.setActiveNumpad(e, 'number');
        this.updateText();
    }
    selectSatuan(satuan, e) {
        this.satuan = satuan;
        this.setActiveNumpad(e, 'satuan');
        this.updateText();
    }
    updateText() {
        let value = this.number + ' ' + this.satuan;
        this.numpadRacikanService.value.next(value);
    }
    setActiveNumpad(event, type) {
        let childs;
        if (type == 'number')
            childs = document.getElementsByClassName('node-number');
        if (type == 'satuan')
            childs = document.getElementsByClassName('node-satuan');
        Array.prototype.forEach.call(childs, function (el) {
            el.style.background = 'white';
            el.style.fontWeight = 'normal';
        });
        event.target.style.color = 'black';
        event.target.style.background = 'orange';
        event.target.style.fontWeight = '500';
    }
    resetActiveNumpad() {
        let childs = document.getElementsByClassName('numpad');
        Array.prototype.forEach.call(childs, function (el) {
            el.style.background = 'white';
            el.style.fontWeight = 'normal';
        });
    }
    parsingNomor() {
        var a = [];
        var b = [];
        for (let index = 0; index <= 100; index++) {
            b.push(index);
        }
        var i, j, temporary, chunk = 10;
        for (i = 1, j = b.length; i < j; i += chunk) {
            temporary = b.slice(i, i + chunk);
            a.push(temporary);
        }
        var c = [];
        var d = [];
        for (let index = 100; index <= 1000; index++) {
            if (index && index % 50 === 0) {
                c.push(index);
            }
        }
        var i, j, temporary, chunk = 2;
        for (i = 1, j = c.length; i < j; i += chunk) {
            temporary = c.slice(i, i + chunk);
            d.push(temporary);
        }
        this.numbers = a;
        this.numbersHundred = d;
    }
}
NumpadRacikanComponent.ɵfac = function NumpadRacikanComponent_Factory(t) { return new (t || NumpadRacikanComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_numpad_racikan_service__WEBPACK_IMPORTED_MODULE_0__.NumpadRacikanService)); };
NumpadRacikanComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: NumpadRacikanComponent, selectors: [["app-numpad-racikan"]], decls: 44, vars: 2, consts: [[1, "row", "p-3"], [1, "col-auto", "p-0", "mr-2"], [2, "width", "315px"], ["style", "display: inline-flex;", 4, "ngFor", "ngForOf"], [1, "col-auto", "p-0", "mr-3"], [2, "width", "88px"], [1, "col-auto", "p-0", "mr-4"], [1, "node-number", "numpad", "tx-center", "clickable", "bd", "pt-1", 3, "click"], [1, "col-auto", "p-0", "m-0"], [1, "node-satuan", "numpad", "tx-center", "clickable", "bd", "p-1", 3, "click"], [2, "display", "inline-flex"], ["class", "node-number numpad tx-center clickable bd pt-1", 3, "click", 4, "ngFor", "ngForOf"], ["class", "node-number numpad tx-center clickable bd pt-1", "style", "width: 40px;", 3, "click", 4, "ngFor", "ngForOf"], [1, "node-number", "numpad", "tx-center", "clickable", "bd", "pt-1", 2, "width", "40px", 3, "click"]], template: function NumpadRacikanComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, NumpadRacikanComponent_div_3_Template, 2, 1, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, NumpadRacikanComponent_div_6_Template, 2, 1, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_8_listener($event) { return ctx.selectNumber("0.1", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "0.1");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_10_listener($event) { return ctx.selectNumber("0.2", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11, "0.2");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_12_listener($event) { return ctx.selectNumber("0.3", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, "0.3");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_14_listener($event) { return ctx.selectNumber("0.4", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "0.4");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_16_listener($event) { return ctx.selectNumber("0.5", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](17, "0.5");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_18_listener($event) { return ctx.selectNumber("0.6", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](19, "0.6");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_20_listener($event) { return ctx.selectNumber("0.7", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](21, "0.7");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_22_listener($event) { return ctx.selectNumber("0.8", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](23, "0.8");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_24_listener($event) { return ctx.selectNumber("0.9", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](25, "0.9");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](26, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_27_listener($event) { return ctx.selectNumber("1/4", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](28, "1/4");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](29, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_29_listener($event) { return ctx.selectNumber("1/2", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30, "1/2");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](31, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_31_listener($event) { return ctx.selectNumber("3/4", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](32, "3/4");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](33, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](34, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_34_listener($event) { return ctx.selectSatuan("%", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](35, "%");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](36, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_36_listener($event) { return ctx.selectSatuan("tab", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](37, "tab");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](38, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_38_listener($event) { return ctx.selectSatuan("gr", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](39, "gr");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](40, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_40_listener($event) { return ctx.selectSatuan("ml", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](41, "ml");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](42, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadRacikanComponent_Template_div_click_42_listener($event) { return ctx.selectSatuan("cc", $event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](43, "cc");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.numbers);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.numbersHundred);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf], styles: [".node-number[_ngcontent-%COMP%] {\r\n    width: 30px;\r\n    height: 30px;\r\n}\r\n\r\n.node-number[_ngcontent-%COMP%]:hover {\r\n    background: lightyellow;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm51bXBhZC1yYWNpa2FuLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxXQUFXO0lBQ1gsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLHVCQUF1QjtBQUMzQiIsImZpbGUiOiJudW1wYWQtcmFjaWthbi5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm5vZGUtbnVtYmVyIHtcclxuICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG59XHJcblxyXG4ubm9kZS1udW1iZXI6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZDogbGlnaHR5ZWxsb3c7XHJcbn0iXX0= */"] });


/***/ }),

/***/ 88989:
/*!*************************************************************************!*\
  !*** ./src/app/modules/shared/numpad-racikan/numpad-racikan.service.ts ***!
  \*************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumpadRacikanService": function() { return /* binding */ NumpadRacikanService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);


class NumpadRacikanService {
    constructor() {
        this.value = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.event = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(false);
    }
    reset() {
        this.value.next('');
    }
}
NumpadRacikanService.ɵfac = function NumpadRacikanService_Factory(t) { return new (t || NumpadRacikanService)(); };
NumpadRacikanService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: NumpadRacikanService, factory: NumpadRacikanService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 5052:
/*!***********************************************************!*\
  !*** ./src/app/modules/shared/numpad/numpad.component.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumpadComponent": function() { return /* binding */ NumpadComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _numpad_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./numpad.service */ 58439);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/overlaypanel */ 59502);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/api */ 88055);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);





const _c0 = ["op"];
function NumpadComponent_ng_template_2_div_0_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NumpadComponent_ng_template_2_div_0_div_1_Template_div_click_0_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r7); const item2_r5 = restoredCtx.$implicit; const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3); return ctx_r6.selectNumber(item2_r5); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item2_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item2_r5);
} }
function NumpadComponent_ng_template_2_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, NumpadComponent_ng_template_2_div_0_div_1_Template, 2, 1, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", item_r3);
} }
function NumpadComponent_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, NumpadComponent_ng_template_2_div_0_Template, 2, 1, "div", 3);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r1.numbers);
} }
const _c1 = function () { return { width: "330px" }; };
class NumpadComponent {
    constructor(numpadService) {
        this.numpadService = numpadService;
    }
    ngOnInit() {
        this.numpadService.event.subscribe(event => {
            if (event) {
                this.openPanel(event);
            }
        });
        this.parsingNomor();
    }
    openPanel(e) {
        this.op.toggle(e);
    }
    selectNumber(number) {
        this.numpadService.number.next(number);
        this.op.hide();
    }
    parsingNomor() {
        var a = [];
        var b = [];
        for (let index = 0; index <= 100; index++) {
            b.push(index);
        }
        var i, j, temporary, chunk = 10;
        for (i = 1, j = b.length; i < j; i += chunk) {
            temporary = b.slice(i, i + chunk);
            a.push(temporary);
        }
        this.numbers = a;
    }
}
NumpadComponent.ɵfac = function NumpadComponent_Factory(t) { return new (t || NumpadComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_numpad_service__WEBPACK_IMPORTED_MODULE_0__.NumpadService)); };
NumpadComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: NumpadComponent, selectors: [["app-numpad"]], viewQuery: function NumpadComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c0, 5);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.op = _t.first);
    } }, decls: 3, vars: 3, consts: [["appendTo", "body"], ["op", ""], ["pTemplate", ""], ["style", "display: inline-flex;", 4, "ngFor", "ngForOf"], [2, "display", "inline-flex"], ["class", "node-number tx-center clickable bd pt-1", 3, "click", 4, "ngFor", "ngForOf"], [1, "node-number", "tx-center", "clickable", "bd", "pt-1", 3, "click"]], template: function NumpadComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "p-overlayPanel", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, NumpadComponent_ng_template_2_Template, 1, 1, "ng-template", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](2, _c1));
    } }, directives: [primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_2__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_3__.PrimeTemplate, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgForOf], styles: [".node-number[_ngcontent-%COMP%] {\r\n    width: 30px;\r\n    height: 30px;\r\n}\r\n\r\n.node-number[_ngcontent-%COMP%]:hover {\r\n    background: lightyellow;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm51bXBhZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksV0FBVztJQUNYLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSx1QkFBdUI7QUFDM0IiLCJmaWxlIjoibnVtcGFkLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubm9kZS1udW1iZXIge1xyXG4gICAgd2lkdGg6IDMwcHg7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbn1cclxuXHJcbi5ub2RlLW51bWJlcjpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kOiBsaWdodHllbGxvdztcclxufSJdfQ== */"] });


/***/ }),

/***/ 58439:
/*!*********************************************************!*\
  !*** ./src/app/modules/shared/numpad/numpad.service.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumpadService": function() { return /* binding */ NumpadService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);


class NumpadService {
    constructor() {
        this.number = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('1');
        this.event = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
    }
    reset() {
        this.number.next('1');
        this.event.next('');
    }
}
NumpadService.ɵfac = function NumpadService_Factory(t) { return new (t || NumpadService)(); };
NumpadService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: NumpadService, factory: NumpadService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 72271:
/*!*************************************************!*\
  !*** ./src/app/modules/shared/shared.module.ts ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SharedModule": function() { return /* binding */ SharedModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _vclaim_vclaim_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vclaim/vclaim.component */ 90107);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/dropdown */ 14170);
/* harmony import */ var primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/inputtextarea */ 90777);
/* harmony import */ var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/radiobutton */ 41751);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/calendar */ 11454);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/dialog */ 75657);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/table */ 6536);
/* harmony import */ var primeng_inputmask__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/inputmask */ 71838);
/* harmony import */ var primeng_selectbutton__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/selectbutton */ 27925);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/tabview */ 46304);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/autocomplete */ 91900);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/menu */ 63493);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/overlaypanel */ 59502);
/* harmony import */ var primeng_progressspinner__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! primeng/progressspinner */ 968);
/* harmony import */ var src_app_modules_shared_numpad_numpad_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/modules/shared/numpad/numpad.component */ 5052);
/* harmony import */ var _numpad_racikan_numpad_racikan_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./numpad-racikan/numpad-racikan.component */ 99787);
/* harmony import */ var primeng_checkbox__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! primeng/checkbox */ 47664);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/toast */ 92076);
/* harmony import */ var primeng_scrollpanel__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! primeng/scrollpanel */ 98778);
/* harmony import */ var _vclaim_surat_kontrol_form_surat_kontrol_form_surat_kontrol_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./vclaim/surat-kontrol/form-surat-kontrol/form-surat-kontrol.component */ 36972);
/* harmony import */ var _vclaim_prb_form_prb_form_prb_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./vclaim/prb/form-prb/form-prb.component */ 61997);
/* harmony import */ var _vclaim_surat_kontrol_surat_kontrol_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./vclaim/surat-kontrol/surat-kontrol.component */ 4690);
/* harmony import */ var _vclaim_prb_prb_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./vclaim/prb/prb.component */ 46092);
/* harmony import */ var _vclaim_rujukan_rujukan_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./vclaim/rujukan/rujukan.component */ 44794);
/* harmony import */ var _vclaim_history_history_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./vclaim/history/history.component */ 25917);
/* harmony import */ var _vclaim_rujukan_form_rujukan_keluar_form_rujukan_keluar_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./vclaim/rujukan/form-rujukan-keluar/form-rujukan-keluar.component */ 65375);
/* harmony import */ var _vclaim_pulang_sep_pulang_sep_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./vclaim/pulang-sep/pulang-sep.component */ 99691);
/* harmony import */ var primeng_progressbar__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! primeng/progressbar */ 35019);
/* harmony import */ var primeng_image__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/image */ 21902);
/* harmony import */ var primeng_editor__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! primeng/editor */ 89080);
/* harmony import */ var primeng_menubar__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! primeng/menubar */ 46103);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @angular/core */ 2316);


































let primeModules = [
    primeng_dropdown__WEBPACK_IMPORTED_MODULE_11__.DropdownModule,
    primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_12__.InputTextareaModule,
    primeng_radiobutton__WEBPACK_IMPORTED_MODULE_13__.RadioButtonModule,
    primeng_calendar__WEBPACK_IMPORTED_MODULE_14__.CalendarModule,
    primeng_dialog__WEBPACK_IMPORTED_MODULE_15__.DialogModule,
    primeng_table__WEBPACK_IMPORTED_MODULE_16__.TableModule,
    primeng_inputmask__WEBPACK_IMPORTED_MODULE_17__.InputMaskModule,
    primeng_selectbutton__WEBPACK_IMPORTED_MODULE_18__.SelectButtonModule,
    primeng_tabview__WEBPACK_IMPORTED_MODULE_19__.TabViewModule,
    primeng_autocomplete__WEBPACK_IMPORTED_MODULE_20__.AutoCompleteModule,
    primeng_menu__WEBPACK_IMPORTED_MODULE_21__.MenuModule,
    primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_22__.OverlayPanelModule,
    primeng_progressspinner__WEBPACK_IMPORTED_MODULE_23__.ProgressSpinnerModule,
    primeng_checkbox__WEBPACK_IMPORTED_MODULE_24__.CheckboxModule,
    primeng_scrollpanel__WEBPACK_IMPORTED_MODULE_25__.ScrollPanelModule,
    primeng_progressbar__WEBPACK_IMPORTED_MODULE_26__.ProgressBarModule,
    primeng_toast__WEBPACK_IMPORTED_MODULE_27__.ToastModule,
    primeng_image__WEBPACK_IMPORTED_MODULE_28__.ImageModule,
    primeng_editor__WEBPACK_IMPORTED_MODULE_29__.EditorModule,
    primeng_menubar__WEBPACK_IMPORTED_MODULE_30__.MenubarModule
];
let sharedComponent = [
    _vclaim_vclaim_component__WEBPACK_IMPORTED_MODULE_0__.VclaimComponent,
    src_app_modules_shared_numpad_numpad_component__WEBPACK_IMPORTED_MODULE_1__.NumpadComponent,
    _numpad_racikan_numpad_racikan_component__WEBPACK_IMPORTED_MODULE_2__.NumpadRacikanComponent,
    _vclaim_surat_kontrol_form_surat_kontrol_form_surat_kontrol_component__WEBPACK_IMPORTED_MODULE_3__.FormSuratKontrolComponent,
    _vclaim_prb_form_prb_form_prb_component__WEBPACK_IMPORTED_MODULE_4__.FormPrbComponent,
    _vclaim_prb_prb_component__WEBPACK_IMPORTED_MODULE_6__.PrbComponent,
    _vclaim_rujukan_rujukan_component__WEBPACK_IMPORTED_MODULE_7__.RujukanComponent,
    _vclaim_history_history_component__WEBPACK_IMPORTED_MODULE_8__.HistoryComponent,
    _vclaim_surat_kontrol_surat_kontrol_component__WEBPACK_IMPORTED_MODULE_5__.SuratKontrolComponent,
    _vclaim_rujukan_form_rujukan_keluar_form_rujukan_keluar_component__WEBPACK_IMPORTED_MODULE_9__.FormRujukanKeluarComponent,
];
class SharedModule {
}
SharedModule.ɵfac = function SharedModule_Factory(t) { return new (t || SharedModule)(); };
SharedModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_31__["ɵɵdefineNgModule"]({ type: SharedModule });
SharedModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_31__["ɵɵdefineInjector"]({ imports: [[
            primeModules,
            _angular_common__WEBPACK_IMPORTED_MODULE_32__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_33__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_33__.ReactiveFormsModule
        ], primeng_dropdown__WEBPACK_IMPORTED_MODULE_11__.DropdownModule,
        primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_12__.InputTextareaModule,
        primeng_radiobutton__WEBPACK_IMPORTED_MODULE_13__.RadioButtonModule,
        primeng_calendar__WEBPACK_IMPORTED_MODULE_14__.CalendarModule,
        primeng_dialog__WEBPACK_IMPORTED_MODULE_15__.DialogModule,
        primeng_table__WEBPACK_IMPORTED_MODULE_16__.TableModule,
        primeng_inputmask__WEBPACK_IMPORTED_MODULE_17__.InputMaskModule,
        primeng_selectbutton__WEBPACK_IMPORTED_MODULE_18__.SelectButtonModule,
        primeng_tabview__WEBPACK_IMPORTED_MODULE_19__.TabViewModule,
        primeng_autocomplete__WEBPACK_IMPORTED_MODULE_20__.AutoCompleteModule,
        primeng_menu__WEBPACK_IMPORTED_MODULE_21__.MenuModule,
        primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_22__.OverlayPanelModule,
        primeng_progressspinner__WEBPACK_IMPORTED_MODULE_23__.ProgressSpinnerModule,
        primeng_checkbox__WEBPACK_IMPORTED_MODULE_24__.CheckboxModule,
        primeng_scrollpanel__WEBPACK_IMPORTED_MODULE_25__.ScrollPanelModule,
        primeng_progressbar__WEBPACK_IMPORTED_MODULE_26__.ProgressBarModule,
        primeng_toast__WEBPACK_IMPORTED_MODULE_27__.ToastModule,
        primeng_image__WEBPACK_IMPORTED_MODULE_28__.ImageModule,
        primeng_editor__WEBPACK_IMPORTED_MODULE_29__.EditorModule,
        primeng_menubar__WEBPACK_IMPORTED_MODULE_30__.MenubarModule, _angular_forms__WEBPACK_IMPORTED_MODULE_33__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_33__.ReactiveFormsModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_31__["ɵɵsetNgModuleScope"](SharedModule, { declarations: [_vclaim_vclaim_component__WEBPACK_IMPORTED_MODULE_0__.VclaimComponent,
        src_app_modules_shared_numpad_numpad_component__WEBPACK_IMPORTED_MODULE_1__.NumpadComponent,
        _numpad_racikan_numpad_racikan_component__WEBPACK_IMPORTED_MODULE_2__.NumpadRacikanComponent,
        _vclaim_surat_kontrol_form_surat_kontrol_form_surat_kontrol_component__WEBPACK_IMPORTED_MODULE_3__.FormSuratKontrolComponent,
        _vclaim_prb_form_prb_form_prb_component__WEBPACK_IMPORTED_MODULE_4__.FormPrbComponent,
        _vclaim_prb_prb_component__WEBPACK_IMPORTED_MODULE_6__.PrbComponent,
        _vclaim_rujukan_rujukan_component__WEBPACK_IMPORTED_MODULE_7__.RujukanComponent,
        _vclaim_history_history_component__WEBPACK_IMPORTED_MODULE_8__.HistoryComponent,
        _vclaim_surat_kontrol_surat_kontrol_component__WEBPACK_IMPORTED_MODULE_5__.SuratKontrolComponent,
        _vclaim_rujukan_form_rujukan_keluar_form_rujukan_keluar_component__WEBPACK_IMPORTED_MODULE_9__.FormRujukanKeluarComponent, _vclaim_pulang_sep_pulang_sep_component__WEBPACK_IMPORTED_MODULE_10__.PulangSepComponent], imports: [primeng_dropdown__WEBPACK_IMPORTED_MODULE_11__.DropdownModule,
        primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_12__.InputTextareaModule,
        primeng_radiobutton__WEBPACK_IMPORTED_MODULE_13__.RadioButtonModule,
        primeng_calendar__WEBPACK_IMPORTED_MODULE_14__.CalendarModule,
        primeng_dialog__WEBPACK_IMPORTED_MODULE_15__.DialogModule,
        primeng_table__WEBPACK_IMPORTED_MODULE_16__.TableModule,
        primeng_inputmask__WEBPACK_IMPORTED_MODULE_17__.InputMaskModule,
        primeng_selectbutton__WEBPACK_IMPORTED_MODULE_18__.SelectButtonModule,
        primeng_tabview__WEBPACK_IMPORTED_MODULE_19__.TabViewModule,
        primeng_autocomplete__WEBPACK_IMPORTED_MODULE_20__.AutoCompleteModule,
        primeng_menu__WEBPACK_IMPORTED_MODULE_21__.MenuModule,
        primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_22__.OverlayPanelModule,
        primeng_progressspinner__WEBPACK_IMPORTED_MODULE_23__.ProgressSpinnerModule,
        primeng_checkbox__WEBPACK_IMPORTED_MODULE_24__.CheckboxModule,
        primeng_scrollpanel__WEBPACK_IMPORTED_MODULE_25__.ScrollPanelModule,
        primeng_progressbar__WEBPACK_IMPORTED_MODULE_26__.ProgressBarModule,
        primeng_toast__WEBPACK_IMPORTED_MODULE_27__.ToastModule,
        primeng_image__WEBPACK_IMPORTED_MODULE_28__.ImageModule,
        primeng_editor__WEBPACK_IMPORTED_MODULE_29__.EditorModule,
        primeng_menubar__WEBPACK_IMPORTED_MODULE_30__.MenubarModule, _angular_common__WEBPACK_IMPORTED_MODULE_32__.CommonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_33__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_33__.ReactiveFormsModule], exports: [_vclaim_vclaim_component__WEBPACK_IMPORTED_MODULE_0__.VclaimComponent,
        src_app_modules_shared_numpad_numpad_component__WEBPACK_IMPORTED_MODULE_1__.NumpadComponent,
        _numpad_racikan_numpad_racikan_component__WEBPACK_IMPORTED_MODULE_2__.NumpadRacikanComponent,
        _vclaim_surat_kontrol_form_surat_kontrol_form_surat_kontrol_component__WEBPACK_IMPORTED_MODULE_3__.FormSuratKontrolComponent,
        _vclaim_prb_form_prb_form_prb_component__WEBPACK_IMPORTED_MODULE_4__.FormPrbComponent,
        _vclaim_prb_prb_component__WEBPACK_IMPORTED_MODULE_6__.PrbComponent,
        _vclaim_rujukan_rujukan_component__WEBPACK_IMPORTED_MODULE_7__.RujukanComponent,
        _vclaim_history_history_component__WEBPACK_IMPORTED_MODULE_8__.HistoryComponent,
        _vclaim_surat_kontrol_surat_kontrol_component__WEBPACK_IMPORTED_MODULE_5__.SuratKontrolComponent,
        _vclaim_rujukan_form_rujukan_keluar_form_rujukan_keluar_component__WEBPACK_IMPORTED_MODULE_9__.FormRujukanKeluarComponent, primeng_dropdown__WEBPACK_IMPORTED_MODULE_11__.DropdownModule,
        primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_12__.InputTextareaModule,
        primeng_radiobutton__WEBPACK_IMPORTED_MODULE_13__.RadioButtonModule,
        primeng_calendar__WEBPACK_IMPORTED_MODULE_14__.CalendarModule,
        primeng_dialog__WEBPACK_IMPORTED_MODULE_15__.DialogModule,
        primeng_table__WEBPACK_IMPORTED_MODULE_16__.TableModule,
        primeng_inputmask__WEBPACK_IMPORTED_MODULE_17__.InputMaskModule,
        primeng_selectbutton__WEBPACK_IMPORTED_MODULE_18__.SelectButtonModule,
        primeng_tabview__WEBPACK_IMPORTED_MODULE_19__.TabViewModule,
        primeng_autocomplete__WEBPACK_IMPORTED_MODULE_20__.AutoCompleteModule,
        primeng_menu__WEBPACK_IMPORTED_MODULE_21__.MenuModule,
        primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_22__.OverlayPanelModule,
        primeng_progressspinner__WEBPACK_IMPORTED_MODULE_23__.ProgressSpinnerModule,
        primeng_checkbox__WEBPACK_IMPORTED_MODULE_24__.CheckboxModule,
        primeng_scrollpanel__WEBPACK_IMPORTED_MODULE_25__.ScrollPanelModule,
        primeng_progressbar__WEBPACK_IMPORTED_MODULE_26__.ProgressBarModule,
        primeng_toast__WEBPACK_IMPORTED_MODULE_27__.ToastModule,
        primeng_image__WEBPACK_IMPORTED_MODULE_28__.ImageModule,
        primeng_editor__WEBPACK_IMPORTED_MODULE_29__.EditorModule,
        primeng_menubar__WEBPACK_IMPORTED_MODULE_30__.MenubarModule, _angular_forms__WEBPACK_IMPORTED_MODULE_33__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_33__.ReactiveFormsModule] }); })();


/***/ }),

/***/ 25917:
/*!********************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/history/history.component.ts ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HistoryComponent": function() { return /* binding */ HistoryComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _vclaim_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../vclaim.service */ 82398);
/* harmony import */ var _history_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./history.service */ 2261);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/calendar */ 11454);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 54364);






function HistoryComponent_tbody_29_tr_1_span_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, "RAWAT INAP");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function HistoryComponent_tbody_29_tr_1_span_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, "RAWAT JALAN");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function HistoryComponent_tbody_29_tr_1_span_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](item_r3.poli);
} }
function HistoryComponent_tbody_29_tr_1_span_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, "-");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function HistoryComponent_tbody_29_tr_1_button_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, "Form Pulang");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function HistoryComponent_tbody_29_tr_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](4, HistoryComponent_tbody_29_tr_1_span_4_Template, 2, 0, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](5, HistoryComponent_tbody_29_tr_1_span_5_Template, 2, 0, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](7, HistoryComponent_tbody_29_tr_1_span_7_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](8, HistoryComponent_tbody_29_tr_1_span_8_Template, 2, 0, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](17, HistoryComponent_tbody_29_tr_1_button_17_Template, 2, 0, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](item_r3.noSep);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", item_r3.jnsPelayanan === "1");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", item_r3.jnsPelayanan === "2");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", item_r3.poli);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !item_r3.poli);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](item_r3.ppkPelayanan);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](item_r3.noRujukan);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](item_r3.tglSep);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", item_r3.tglPlgSep, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !item_r3.tglPlgSep);
} }
function HistoryComponent_tbody_29_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, HistoryComponent_tbody_29_tr_1_Template, 18, 10, "tr", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx_r0.dataHistory.histori);
} }
function HistoryComponent_tfoot_30_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "tfoot");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "td", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3, "Tidak ada data saat ini.");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
const _c0 = function () { return { width: "120px" }; };
class HistoryComponent {
    constructor(vclaimService, historyService) {
        this.vclaimService = vclaimService;
        this.historyService = historyService;
        this.dataHistory = [];
        this.filter = { from: new Date, to: new Date };
        this.today = new Date;
    }
    ngOnInit() {
        this.vclaimService.peserta.subscribe(data => this.handlePeserta(data));
        this.historyService.dataHistory.subscribe(data => this.dataHistory = data);
        let defaultFilterFrom = new Date().setDate(this.today.getDate() - 30);
        this.filter.from = new Date(defaultFilterFrom);
    }
    handlePeserta(data) {
        if (data) {
            this.peserta = data.peserta;
            this.getDataHistory();
        }
    }
    getDataHistory() {
        setTimeout(() => {
            this.historyService.getDataHistory(this.peserta.noKartu, this.filter.from, this.filter.to);
        }, 50);
    }
}
HistoryComponent.ɵfac = function HistoryComponent_Factory(t) { return new (t || HistoryComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_vclaim_service__WEBPACK_IMPORTED_MODULE_0__.VclaimService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_history_service__WEBPACK_IMPORTED_MODULE_1__.HistoryService)); };
HistoryComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: HistoryComponent, selectors: [["app-history"]], decls: 31, vars: 14, consts: [[1, "row", "pt-3", "pb-3"], [1, "col", "mb-2", "clearfix"], [1, "float-left"], [1, "btn", "btn-sm", "btn-secondary", 3, "click"], [1, "bi", "bi-arrow-clockwise"], [1, "float-left", "ml-3", "pl-3", "border-left"], ["dateFormat", "d M yy", "appendTo", "body", "styleClass", "mr-2", 3, "ngModel", "readonlyInput", "maxDate", "ngModelChange"], ["dateFormat", "d M yy", "appendTo", "body", 3, "ngModel", "readonlyInput", "maxDate", "ngModelChange"], [1, "w-100", "border-bottom"], [1, "col", "p-0"], [1, "table", "table-striped", "table-hover", "border-bottom"], [1, "bg-gray-300"], ["width", "100"], [4, "ngIf"], [4, "ngFor", "ngForOf"], ["class", "btn btn-xs btn-outline-primary p-1", 4, "ngIf"], [1, "btn", "btn-xs", "btn-outline-primary", "p-1"], ["colspan", "7", 1, "tx-center"]], template: function HistoryComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function HistoryComponent_Template_button_click_3_listener() { return ctx.getDataHistory(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](4, "i", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, " Dari : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "p-calendar", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function HistoryComponent_Template_p_calendar_ngModelChange_7_listener($event) { return ctx.filter.from = $event; })("ngModelChange", function HistoryComponent_Template_p_calendar_ngModelChange_7_listener() { return ctx.getDataHistory(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](8, " Sampai : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "p-calendar", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function HistoryComponent_Template_p_calendar_ngModelChange_9_listener($event) { return ctx.filter.to = $event; })("ngModelChange", function HistoryComponent_Template_p_calendar_ngModelChange_9_listener() { return ctx.getDataHistory(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](10, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "table", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "tr", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](16, "No. SEP");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](18, "Jns. Pelayanan");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](20, "Poli / Ruangan");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](21, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](22, "PPK");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](24, "No. Rujukan");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](25, "th", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](26, "Tgl. SEP");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](27, "th", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](28, "Tgl. Pulang");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](29, HistoryComponent_tbody_29_Template, 2, 1, "tbody", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](30, HistoryComponent_tfoot_30_Template, 4, 0, "tfoot", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](12, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx.filter.from)("readonlyInput", true)("maxDate", ctx.today);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](13, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx.filter.to)("readonlyInput", true)("maxDate", ctx.today);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.dataHistory);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.dataHistory);
    } }, directives: [primeng_calendar__WEBPACK_IMPORTED_MODULE_3__.Calendar, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgModel, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJoaXN0b3J5LmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 2261:
/*!******************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/history/history.service.ts ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HistoryService": function() { return /* binding */ HistoryService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var src_app_services_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/app.service */ 66475);





class HistoryService {
    constructor(http, appService) {
        this.http = http;
        this.appService = appService;
        this.dataHistory = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject('');
    }
    getDataHistory(nomorKartu, from, to) {
        let filterFrom = this.appService.reformatDate(from);
        let filterTo = this.appService.reformatDate(to);
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_vclaim('history/nomorKartu/' + nomorKartu + '/from/' + filterFrom + '/to/' + filterTo))
            .subscribe(data => this.dataHistory.next(data.response));
    }
}
HistoryService.ɵfac = function HistoryService_Factory(t) { return new (t || HistoryService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](src_app_services_app_service__WEBPACK_IMPORTED_MODULE_1__.AppService)); };
HistoryService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: HistoryService, factory: HistoryService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 61997:
/*!**************************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/prb/form-prb/form-prb.component.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormPrbComponent": function() { return /* binding */ FormPrbComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/dropdown */ 14170);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/autocomplete */ 91900);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 54364);




function FormPrbComponent_tr_55_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "input", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "input", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "input", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "td", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "i", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, " Hapus");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r2.obat.nama);
} }
function FormPrbComponent_tbody_56_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "td", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Tidak Ada Obat");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
const _c0 = function () { return { width: "100%" }; };
const _c1 = function () { return { "width": "100%" }; };
class FormPrbComponent {
    constructor() {
        this.dataObat = [];
    }
    ngOnInit() {
    }
}
FormPrbComponent.ɵfac = function FormPrbComponent_Factory(t) { return new (t || FormPrbComponent)(); };
FormPrbComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FormPrbComponent, selectors: [["app-form-prb"]], decls: 62, vars: 16, consts: [[1, "row", "mb-1"], [1, "col-2", "col-form-label"], ["ng-show", "formPrb.sep.$error.required", 1, "fontello-icon-attention-circle", "error"], [1, "col"], ["appendTo", "body"], ["ng-show", "formPrb.programPrb.$error.required", 1, "fontello-icon-attention-circle", "error"], ["ng-show", "formPrb.dokter.$error.required", 1, "fontello-icon-attention-circle", "error"], ["ng-show", "formPrb.keterangan.$error.required", 1, "fontello-icon-attention-circle", "error"], ["type", "text", "name", "keterangan", 1, "form-control"], ["ng-show", "formPrb.saran.$error.required", 1, "fontello-icon-attention-circle", "error"], ["type", "text", "name", "saran", 1, "form-control"], ["ng-show", "formPrb.email.$error.required", 1, "fontello-icon-attention-circle", "error"], ["type", "text", "name", "email", 1, "form-control"], [1, "tx-16", "tx-semibold"], ["placeholder", "Cari Nama Obat...", 3, "inputStyle"], [1, "table", "table-striped", "table-hover"], ["width", "100"], [4, "ngFor", "ngForOf"], [4, "ngIf"], [1, "row", "bg-gray-500", "p-3"], [1, "col", "tx-right"], [1, "btn", "btn-sm", "btn-primary"], [1, "bi", "bi-save", "mr-1"], ["type", "text", "ng-model", "dataObatPrb[$index].signa1", 1, "input-block-level"], ["type", "text", "ng-model", "dataObatPrb[$index].signa2", 1, "input-block-level"], ["type", "text", "ng-model", "dataObatPrb[$index].jumlah", 1, "input-block-level"], ["align", "center"], [1, "btn", "btn-sm", "btn-secondary"], [1, "bi", "bi-trash", "mr-1"], ["colspan", "5", 1, "text-center"]], template: function FormPrbComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "SEP Rawat Jalan ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "span", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "p-dropdown", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Program PRB ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "p-dropdown", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "Dokter / DPJP ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "p-dropdown", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "Keterangan ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Saran ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](27, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "input", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, "Email ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](33, "span", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](35, "input", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](36, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](40, "Obat-Obatan");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](41, "p-autoComplete", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "table", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](45, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](46, "Nama Obat");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](48, "Signa 1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](50, "Signa 2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "th", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](52, "Jumlah");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](53, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](55, FormPrbComponent_tr_55_Template, 13, 1, "tr", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](56, FormPrbComponent_tbody_56_Template, 4, 0, "tbody", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](58, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](60, "i", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](61, " Simpan");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](11, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](12, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](13, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](14, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("inputStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](15, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.dataObat);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.dataObat.length < 1);
    } }, directives: [primeng_dropdown__WEBPACK_IMPORTED_MODULE_1__.Dropdown, primeng_autocomplete__WEBPACK_IMPORTED_MODULE_2__.AutoComplete, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb3JtLXByYi5jb21wb25lbnQuY3NzIn0= */"] });


/***/ }),

/***/ 11277:
/*!************************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/prb/form-prb/form-prb.service.ts ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormPrbService": function() { return /* binding */ FormPrbService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);


class FormPrbService {
    constructor() {
        this.dialog = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(false);
    }
    openDialog() {
        this.dialog.next(true);
    }
    closeDialog() {
        this.dialog.next(true);
    }
}
FormPrbService.ɵfac = function FormPrbService_Factory(t) { return new (t || FormPrbService)(); };
FormPrbService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: FormPrbService, factory: FormPrbService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 46092:
/*!************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/prb/prb.component.ts ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrbComponent": function() { return /* binding */ PrbComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _prb_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./prb.service */ 68610);
/* harmony import */ var _form_prb_form_prb_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./form-prb/form-prb.service */ 11277);
/* harmony import */ var _vclaim_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../vclaim.service */ 82398);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/calendar */ 11454);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/dialog */ 75657);
/* harmony import */ var _form_prb_form_prb_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./form-prb/form-prb.component */ 61997);









function PrbComponent_tbody_32_tr_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.noSEP);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.noSRB);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.tglSRB);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.DPJP.nama);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.programPRB.nama);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.keterangan);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.saran);
} }
function PrbComponent_tbody_32_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, PrbComponent_tbody_32_tr_1_Template, 15, 7, "tr", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r0.dataPrb.prb.list);
} }
function PrbComponent_tfoot_33_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tfoot");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "td", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Tidak ada saat ini.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
const _c0 = function () { return { width: "120px" }; };
const _c1 = function () { return { width: "800px" }; };
class PrbComponent {
    constructor(prbService, formPrbService, vclaimService) {
        this.prbService = prbService;
        this.formPrbService = formPrbService;
        this.vclaimService = vclaimService;
        this.today = new Date;
        this.dialogFormPrb = false;
        this.filter = { from: new Date, to: new Date };
        this.dataPrb = [];
    }
    ngOnInit() {
        this.formPrbService.dialog.subscribe(data => { this.dialogFormPrb = data; });
        this.vclaimService.peserta.subscribe(data => this.handlePeserta(data));
        this.prbService.dataPrb.subscribe(data => this.dataPrb = data);
        let defaultFilterFrom = new Date().setDate(this.today.getDate() - 30);
        this.filter.from = new Date(defaultFilterFrom);
    }
    handlePeserta(data) {
        if (data) {
            this.peserta = data.peserta;
            this.getDataPrb();
        }
    }
    getDataPrb() {
        setTimeout(() => {
            this.prbService.getDataPrb(this.peserta.noKartu, this.filter.from, this.filter.to);
        }, 50);
    }
}
PrbComponent.ɵfac = function PrbComponent_Factory(t) { return new (t || PrbComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_prb_service__WEBPACK_IMPORTED_MODULE_0__.PrbService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_form_prb_form_prb_service__WEBPACK_IMPORTED_MODULE_1__.FormPrbService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_vclaim_service__WEBPACK_IMPORTED_MODULE_2__.VclaimService)); };
PrbComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: PrbComponent, selectors: [["app-prb"]], decls: 36, vars: 19, consts: [[1, "row", "pt-3", "pb-3"], [1, "col", "mb-2", "clearfix"], [1, "float-left"], [1, "btn", "btn-sm", "btn-primary", "mr-1", 3, "click"], [1, "bi", "bi-plus-lg"], [1, "btn", "btn-sm", "btn-secondary", 3, "click"], [1, "bi", "bi-arrow-clockwise"], [1, "float-left", "ml-3", "pl-3", "border-left"], ["dateFormat", "d M yy", "appendTo", "body", "styleClass", "mr-2", 3, "ngModel", "readonlyInput", "maxDate", "ngModelChange"], ["dateFormat", "d M yy", "appendTo", "body", 3, "ngModel", "readonlyInput", "maxDate", "ngModelChange"], [1, "w-100", "border-bottom"], [1, "col", "p-0"], [1, "table", "table-striped", "table-hover", "border-bottom"], [1, "bg-gray-300"], ["width", "100"], [4, "ngIf"], ["header", "Form Pasien Rujuk Balik / PRB", "appendTo", "body", 3, "visible", "modal", "visibleChange"], [4, "ngFor", "ngForOf"], ["colspan", "7", 1, "tx-center"]], template: function PrbComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function PrbComponent_Template_button_click_3_listener() { return ctx.formPrbService.openDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "i", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, " Data Baru");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function PrbComponent_Template_button_click_6_listener() { return ctx.getDataPrb(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "i", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, " Dari : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "p-calendar", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function PrbComponent_Template_p_calendar_ngModelChange_10_listener($event) { return ctx.filter.from = $event; })("ngModelChange", function PrbComponent_Template_p_calendar_ngModelChange_10_listener() { return ctx.getDataPrb(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, " Sampai : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "p-calendar", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function PrbComponent_Template_p_calendar_ngModelChange_12_listener($event) { return ctx.filter.to = $event; })("ngModelChange", function PrbComponent_Template_p_calendar_ngModelChange_12_listener() { return ctx.getDataPrb(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](13, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "table", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "tr", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](19, "No. SEP");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](21, "No. SRB");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](22, "th", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23, "Tgl. SRB");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](25, "DPJP");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](27, "Program PRB");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](29, "Keterangan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](30, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](31, "Saran");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](32, PrbComponent_tbody_32_Template, 2, 1, "tbody", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](33, PrbComponent_tfoot_33_Template, 4, 0, "tfoot", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](34, "p-dialog", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("visibleChange", function PrbComponent_Template_p_dialog_visibleChange_34_listener($event) { return ctx.dialogFormPrb = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](35, "app-form-prb");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](16, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx.filter.from)("readonlyInput", true)("maxDate", ctx.today);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](17, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx.filter.to)("readonlyInput", true)("maxDate", ctx.today);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.dataPrb);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.dataPrb);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](18, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("visible", ctx.dialogFormPrb)("modal", true);
    } }, directives: [primeng_calendar__WEBPACK_IMPORTED_MODULE_5__.Calendar, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, primeng_dialog__WEBPACK_IMPORTED_MODULE_8__.Dialog, _form_prb_form_prb_component__WEBPACK_IMPORTED_MODULE_3__.FormPrbComponent, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcmIuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 68610:
/*!**********************************************************!*\
  !*** ./src/app/modules/shared/vclaim/prb/prb.service.ts ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrbService": function() { return /* binding */ PrbService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var src_app_services_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/app.service */ 66475);





class PrbService {
    constructor(http, appService) {
        this.http = http;
        this.appService = appService;
        this.dataPrb = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject('');
    }
    getDataPrb(nomorKartu, from, to) {
        let dateStart = this.appService.reformatDate(from);
        let dateEnd = this.appService.reformatDate(to);
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_vclaim('prb/data/from/' + dateStart + '/to/' + dateEnd))
            .subscribe(data => this.dataPrb.next(data.response));
    }
}
PrbService.ɵfac = function PrbService_Factory(t) { return new (t || PrbService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](src_app_services_app_service__WEBPACK_IMPORTED_MODULE_1__.AppService)); };
PrbService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: PrbService, factory: PrbService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 99691:
/*!**************************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/pulang-sep/pulang-sep.component.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PulangSepComponent": function() { return /* binding */ PulangSepComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 54364);


function PulangSepComponent_tbody_29_tr_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function PulangSepComponent_tbody_29_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, PulangSepComponent_tbody_29_tr_1_Template, 8, 0, "tr", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r0.dataSep);
} }
function PulangSepComponent_tfoot_30_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tfoot");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "td", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Tidak ada data saat ini.");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class PulangSepComponent {
    constructor() { }
    ngOnInit() {
    }
}
PulangSepComponent.ɵfac = function PulangSepComponent_Factory(t) { return new (t || PulangSepComponent)(); };
PulangSepComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PulangSepComponent, selectors: [["app-pulang-sep"]], decls: 31, vars: 2, consts: [[1, "row", "pt-3", "pb-3"], [1, "col", "mb-2", "clearfix"], [1, "float-left"], [1, "float-left", "ml-3"], [1, "input-group"], ["type", "text", 1, "form-control"], [1, "input-group-append"], [1, "btn", "btn-secondary"], [1, "bi", "bi-search"], [1, "w-100", "border-bottom"], [1, "col", "p-0"], [1, "table", "table-striped", "table-hover", "border-bottom"], [1, "bg-gray-300"], [4, "ngIf"], [4, "ngFor", "ngForOf"], ["colspan", "7", 1, "tx-center"]], template: function PulangSepComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, " Nomor SEP : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "input", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "i", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "table", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "tr", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "SEP");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Tgl. SEP");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "Tgl. Pulang");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Jns. Pelayanan");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, "Poli / Ruangan");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "No. Rujukan");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "PPK");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](29, PulangSepComponent_tbody_29_Template, 2, 1, "tbody", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](30, PulangSepComponent_tfoot_30_Template, 4, 0, "tfoot", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.dataSep);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.dataSep);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwdWxhbmctc2VwLmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 65375:
/*!****************************************************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/rujukan/form-rujukan-keluar/form-rujukan-keluar.component.ts ***!
  \****************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormRujukanKeluarComponent": function() { return /* binding */ FormRujukanKeluarComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/calendar */ 11454);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/dropdown */ 14170);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/autocomplete */ 91900);




const _c0 = function () { return { width: "100%" }; };
const _c1 = function () { return { "width": "100%" }; };
class FormRujukanKeluarComponent {
    constructor() { }
    ngOnInit() {
    }
}
FormRujukanKeluarComponent.ɵfac = function FormRujukanKeluarComponent_Factory(t) { return new (t || FormRujukanKeluarComponent)(); };
FormRujukanKeluarComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FormRujukanKeluarComponent, selectors: [["app-form-rujukan-keluar"]], decls: 60, vars: 24, consts: [[1, "row", "mb-1"], [1, "col-4", "col-form-label"], ["ng-show", "formRujukanBaru.tglRujukan.$error.required", 1, "fontello-icon-attention-circle", "error"], [1, "col"], ["appendTo", "body", 3, "showIcon"], ["ng-show", "formRujukanBaru.tglRencanaKunjungan.$error.required", 1, "fontello-icon-attention-circle", "error"], ["ng-show", "formRujukanBaru.jnsPelayanan.$error.required", 1, "fontello-icon-attention-circle", "error"], ["appendTo", "body"], ["ng-show", "formRujukanBaru.sep.$error.required", 1, "fontello-icon-attention-circle", "error"], ["appendTo", "body", "styleClass", "mb-1"], ["type", "text", "ng-model", "rujukanBaru.noSep", "placeholder", "Ketikkan Manual No.SEP", 1, "form-control"], ["ng-show", "formRujukanBaru.tipeRujukan.$error.required", 1, "fontello-icon-attention-circle", "error"], ["ng-show", "formRujukanBaru.poli.$error.required", 1, "fontello-icon-attention-circle", "error"], ["ng-show", "formRujukanBaru.ppk.$error.required || !rujukanBaru.ppk", 1, "fontello-icon-attention-circle", "error"], ["placeholder", "Cari...", 3, "inputStyle"], ["ng-show", "formRujukanBaru.diagnosa.$error.required || !rujukanBaru.diagAwal", 1, "fontello-icon-attention-circle", "error"], ["ng-show", "formRujukanBaru.catatan.$error.required", 1, "fontello-icon-attention-circle", "error"], ["type", "text", "ng-model", "rujukanBaru.catatan", 1, "form-control"], [1, "row", "mb-1", "bg-gray-500", "p-3", "mt-3"], [1, "col", "tx-right"], [1, "btn", "btn-sm", "btn-primary"], [1, "bi", "bi-save", "mr-1"]], template: function FormRujukanKeluarComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Tgl. Rujukan ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "span", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "p-calendar", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Tgl. Rencana Kunjungan ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "p-calendar", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "Jns. Pelayanan ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "p-dropdown", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "No. SEP ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "span", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "p-dropdown", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](24, "input", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Tipe Rujukan ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "span", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](30, "p-dropdown", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "Poliklinik / Spesialis ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](34, "span", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](36, "p-dropdown", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, "PPK Tujuan ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](40, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](42, "p-autoComplete", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "Diagnosa ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](46, "span", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](48, "p-autoComplete", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](51, "Catatan ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](52, "span", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](54, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](56, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](58, "i", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](59, " Simpan");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("showIcon", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("showIcon", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](16, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](17, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](18, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](19, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](20, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("inputStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](21, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](22, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("inputStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](23, _c1));
    } }, directives: [primeng_calendar__WEBPACK_IMPORTED_MODULE_1__.Calendar, primeng_dropdown__WEBPACK_IMPORTED_MODULE_2__.Dropdown, primeng_autocomplete__WEBPACK_IMPORTED_MODULE_3__.AutoComplete], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb3JtLXJ1anVrYW4ta2VsdWFyLmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 86904:
/*!**************************************************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/rujukan/form-rujukan-keluar/form-rujukan-keluar.service.ts ***!
  \**************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormRujukanKeluarService": function() { return /* binding */ FormRujukanKeluarService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);


class FormRujukanKeluarService {
    constructor() {
        this.dialog = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(false);
    }
    openDialog() {
        this.dialog.next(true);
    }
    closeDialog() {
        this.dialog.next(false);
    }
}
FormRujukanKeluarService.ɵfac = function FormRujukanKeluarService_Factory(t) { return new (t || FormRujukanKeluarService)(); };
FormRujukanKeluarService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: FormRujukanKeluarService, factory: FormRujukanKeluarService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 44794:
/*!********************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/rujukan/rujukan.component.ts ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RujukanComponent": function() { return /* binding */ RujukanComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _form_rujukan_keluar_form_rujukan_keluar_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-rujukan-keluar/form-rujukan-keluar.service */ 86904);
/* harmony import */ var _rujukan_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rujukan.service */ 32922);
/* harmony import */ var _vclaim_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../vclaim.service */ 82398);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/dialog */ 75657);
/* harmony import */ var _form_rujukan_keluar_form_rujukan_keluar_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./form-rujukan-keluar/form-rujukan-keluar.component */ 65375);







function RujukanComponent_tbody_29_tr_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](8, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r8.noKunjungan);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r8.tglKunjungan);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](8, 7, item_r8.pelayanan.nama));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r8.poliRujukan.nama);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r8.provPerujuk.nama);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"]("", item_r8.diagnosa.kode, " - ", item_r8.diagnosa.nama, "");
} }
function RujukanComponent_tbody_29_td_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "td", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, "Tidak ada saat ini.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function RujukanComponent_tbody_29_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, RujukanComponent_tbody_29_tr_1_Template, 15, 9, "tr", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, RujukanComponent_tbody_29_td_3_Template, 2, 0, "td", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r0.dataRujukanFaskes.rujukan);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.dataRujukanFaskes.length === 0);
} }
function RujukanComponent_tfoot_30_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tfoot");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "td", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Tidak ada saat ini.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function RujukanComponent_tbody_50_tr_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](7, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r10.noKunjungan);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r10.tglKunjungan);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](7, 7, item_r10.pelayanan.nama));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r10.poliRujukan.nama);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r10.provPerujuk.nama);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"]("", item_r10.diagnosa.kode, " - ", item_r10.diagnosa.nama, "");
} }
function RujukanComponent_tbody_50_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, RujukanComponent_tbody_50_tr_1_Template, 14, 9, "tr", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r2.dataRujukanRs.rujukan);
} }
function RujukanComponent_tfoot_51_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tfoot");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "td", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Tidak ada saat ini.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function RujukanComponent_tbody_71_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function RujukanComponent_tfoot_72_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tfoot");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "td", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Tidak ada saat ini.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
const _c0 = function () { return { width: "600px" }; };
class RujukanComponent {
    constructor(formRujukanKeluarService, rujukanService, vclaimService) {
        this.formRujukanKeluarService = formRujukanKeluarService;
        this.rujukanService = rujukanService;
        this.vclaimService = vclaimService;
        this.dialogFormRujukanKeluar = false;
        this.dataRujukanFaskes = [];
        this.dataRujukanRs = [];
        this.dataRujukanKeluar = [];
    }
    ngOnInit() {
        this.formRujukanKeluarService.dialog.subscribe(data => this.dialogFormRujukanKeluar = data);
        this.vclaimService.peserta.subscribe(data => this.handlePeserta(data));
        this.rujukanService.dataRujukanFaskes.subscribe(data => this.dataRujukanFaskes = data);
        this.rujukanService.dataRujukanRs.subscribe(data => this.dataRujukanRs = data);
        this.rujukanService.dataRujukanKeluar.subscribe(data => this.dataRujukanKeluar = data);
    }
    handlePeserta(data) {
        if (data) {
            this.peserta = data.peserta;
            this.getDataRujukan();
        }
    }
    getDataRujukan() {
        this.rujukanService.getDataRujukanFaskes(this.peserta.noKartu);
        this.rujukanService.getDataRujukanRs(this.peserta.noKartu);
    }
}
RujukanComponent.ɵfac = function RujukanComponent_Factory(t) { return new (t || RujukanComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_form_rujukan_keluar_form_rujukan_keluar_service__WEBPACK_IMPORTED_MODULE_0__.FormRujukanKeluarService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_rujukan_service__WEBPACK_IMPORTED_MODULE_1__.RujukanService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_vclaim_service__WEBPACK_IMPORTED_MODULE_2__.VclaimService)); };
RujukanComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: RujukanComponent, selectors: [["app-rujukan"]], decls: 75, vars: 11, consts: [[1, "row", "pt-3", "pb-3"], [1, "col", "mb-2", "clearfix"], [1, "float-left"], [1, "btn", "btn-sm", "btn-primary", "mr-1", 3, "click"], [1, "bi", "bi-plus-lg"], [1, "btn", "btn-sm", "btn-secondary", 3, "click"], [1, "bi", "bi-arrow-clockwise"], [1, "w-100", "border-bottom"], [1, "col", "p-0"], [1, "table", "table-striped", "table-hover", "mb-3", "border-bottom"], ["colspan", "6", 1, "tx-15", "p-2"], [1, "bg-gray-300"], ["width", "100"], [4, "ngIf"], ["header", "Form Rujuk Keluar RS", "appendTo", "body", 3, "visible", "modal", "visibleChange"], [4, "ngFor", "ngForOf"], ["colspan", "6", "class", "tx-center", 4, "ngIf"], [1, "btn", "btn-secondary", "btn-sm"], ["colspan", "6", 1, "tx-center"]], template: function RujukanComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function RujukanComponent_Template_button_click_3_listener() { return ctx.formRujukanKeluarService.openDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "i", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, " Form Rujukan Keluar");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function RujukanComponent_Template_button_click_6_listener() { return ctx.getDataRujukan(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "i", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](8, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "table", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "th", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14, "Puskesmas / PCare");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "tr", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, "No. Rujukan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "th", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](20, "Tgl. Rujukan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22, "Jns. Pelayanan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](23, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](24, "Spesialis");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](25, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](26, "PPK");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28, "Diagnosa");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](29, RujukanComponent_tbody_29_Template, 4, 2, "tbody", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](30, RujukanComponent_tfoot_30_Template, 4, 0, "tfoot", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "table", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](32, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](33, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](34, "th", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](35, "Rumah Sakit");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](36, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](37, "tr", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](38, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](39, "No. Rujukan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](40, "th", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](41, "Tgl. Rujukan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](42, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](43, "Jns. Pelayanan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](44, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](45, "Poliklinik / Spesialis");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](46, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](47, "PPK");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](48, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](49, "Diagnosa");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](50, RujukanComponent_tbody_50_Template, 2, 1, "tbody", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](51, RujukanComponent_tfoot_51_Template, 4, 0, "tfoot", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](52, "table", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](53, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](54, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](55, "th", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](56, "Rujukan Keluar");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](57, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](58, "tr", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](59, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](60, "No. Rujukan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](61, "th", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](62, "Tgl. Rujukan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](63, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](64, "Jns. Pelayanan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](65, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](66, "Spesialis");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](67, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](68, "PPK");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](69, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](70, "Diagnosa");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](71, RujukanComponent_tbody_71_Template, 8, 0, "tbody", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](72, RujukanComponent_tfoot_72_Template, 4, 0, "tfoot", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](73, "p-dialog", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("visibleChange", function RujukanComponent_Template_p_dialog_visibleChange_73_listener($event) { return ctx.dialogFormRujukanKeluar = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](74, "app-form-rujukan-keluar");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](29);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.dataRujukanFaskes);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.dataRujukanFaskes);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.dataRujukanRs);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.dataRujukanRs);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.dataRujukanKeluar);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.dataRujukanKeluar);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](10, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("visible", ctx.dialogFormRujukanKeluar)("modal", true);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, primeng_dialog__WEBPACK_IMPORTED_MODULE_6__.Dialog, _form_rujukan_keluar_form_rujukan_keluar_component__WEBPACK_IMPORTED_MODULE_3__.FormRujukanKeluarComponent, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.UpperCasePipe], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJydWp1a2FuLmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 32922:
/*!******************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/rujukan/rujukan.service.ts ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RujukanService": function() { return /* binding */ RujukanService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 53882);




class RujukanService {
    constructor(http) {
        this.http = http;
        this.dataRujukanFaskes = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
        this.dataRujukanRs = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
        this.dataRujukanKeluar = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
    }
    getDataRujukanFaskes(nomorKartu) {
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_vclaim('rujukan/faskes/nomorKartu/' + nomorKartu))
            .subscribe(data => this.dataRujukanFaskes.next(data.response));
    }
    getDataRujukanRs(nomorKartu) {
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_vclaim('rujukan/rs/nomorKartu/' + nomorKartu))
            .subscribe(data => this.dataRujukanFaskes.next(data.response));
    }
    getDataRujukanKeluar(nomorKartu) {
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_vclaim('rujukan/rs/nomorKartu/' + nomorKartu))
            .subscribe(data => this.dataRujukanKeluar.next(data.response));
    }
}
RujukanService.ɵfac = function RujukanService_Factory(t) { return new (t || RujukanService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient)); };
RujukanService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: RujukanService, factory: RujukanService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 36972:
/*!********************************************************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/surat-kontrol/form-surat-kontrol/form-surat-kontrol.component.ts ***!
  \********************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormSuratKontrolComponent": function() { return /* binding */ FormSuratKontrolComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/calendar */ 11454);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/dropdown */ 14170);




const _c0 = function () { return { width: "100%" }; };
class FormSuratKontrolComponent {
    constructor() { }
    ngOnInit() {
    }
}
FormSuratKontrolComponent.ɵfac = function FormSuratKontrolComponent_Factory(t) { return new (t || FormSuratKontrolComponent)(); };
FormSuratKontrolComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FormSuratKontrolComponent, selectors: [["app-form-surat-kontrol"]], decls: 31, vars: 10, consts: [["name", "formSuratKontrol"], [1, "row", "mb-1"], [1, "col-4", "col-form-label"], ["ng-show", "tgl.$error.required", 1, "fontello-icon-attention-circle", "error"], [1, "col"], ["appendTo", "body", 3, "showIcon"], ["ng-show", "jnsPelayanan=='kontrolKembali'", 1, "row", "mb-1"], ["ng-show", "formSuratKontrol.sep.$error.required", 1, "fontello-icon-attention-circle", "error"], ["appendTo", "body", "styleClass", "mb-1"], ["type", "text", "placeholder", "Ketikkan Manual No.SEP", "ng-required", "jnsPelayanan=='kontrolKembali'", 1, "form-control"], ["ng-show", "formSuratKontrol.poli.$error.required", 1, "fontello-icon-attention-circle", "error"], ["appendTo", "body"], ["ng-show", "formSuratKontrol.dokter.$error.required", 1, "fontello-icon-attention-circle", "error"], [1, "row", "mb-1", "bg-gray-500", "p-3", "mt-3"], [1, "col", "tx-right"], [1, "btn", "btn-sm", "btn-primary"], [1, "bi", "bi-save", "mr-1"]], template: function FormSuratKontrolComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "form", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "label", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Tanggal ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "p-calendar", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "label", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "No. SEP Sebelumnya ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "p-dropdown", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](13, "input", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "label", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Poliklinik Asal Rujukan ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](19, "p-dropdown", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "label", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Dokter / DPJP ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "span", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](25, "p-dropdown", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "i", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, " Simpan");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("showIcon", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](7, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](8, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](9, _c0));
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgForm, primeng_calendar__WEBPACK_IMPORTED_MODULE_2__.Calendar, primeng_dropdown__WEBPACK_IMPORTED_MODULE_3__.Dropdown], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb3JtLXN1cmF0LWtvbnRyb2wuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 36491:
/*!******************************************************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/surat-kontrol/form-surat-kontrol/form-surat-kontrol.service.ts ***!
  \******************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormSuratKontrolService": function() { return /* binding */ FormSuratKontrolService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 53882);



class FormSuratKontrolService {
    constructor(http) {
        this.http = http;
        this.dialog = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(false);
    }
    save() {
    }
    openDialog() {
        this.dialog.next(true);
    }
    closeDialog() {
        this.dialog.next(false);
    }
}
FormSuratKontrolService.ɵfac = function FormSuratKontrolService_Factory(t) { return new (t || FormSuratKontrolService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient)); };
FormSuratKontrolService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: FormSuratKontrolService, factory: FormSuratKontrolService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 4690:
/*!********************************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/surat-kontrol/surat-kontrol.component.ts ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SuratKontrolComponent": function() { return /* binding */ SuratKontrolComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _surat_kontrol_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./surat-kontrol.service */ 84356);
/* harmony import */ var _form_surat_kontrol_form_surat_kontrol_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./form-surat-kontrol/form-surat-kontrol.service */ 36491);
/* harmony import */ var _vclaim_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../vclaim.service */ 82398);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/calendar */ 11454);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/dialog */ 75657);
/* harmony import */ var _form_surat_kontrol_form_surat_kontrol_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./form-surat-kontrol/form-surat-kontrol.component */ 36972);









function SuratKontrolComponent_tbody_32_tr_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](8, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.noSuratKontrol);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.noSepAsalKontrol);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](8, 8, item_r3.jnsPelayanan));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.namaPoliAsal);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.namaPoliTujuan);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.namaDokter);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.tglTerbitKontrol);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r3.tglRencanaKontrol);
} }
function SuratKontrolComponent_tbody_32_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, SuratKontrolComponent_tbody_32_tr_1_Template, 19, 10, "tr", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r0.dataSuratKontrol.list);
} }
function SuratKontrolComponent_tfoot_33_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tfoot");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "td", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Tidak ada data saat ini.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
const _c0 = function () { return { width: "120px" }; };
const _c1 = function () { return { width: "600px" }; };
class SuratKontrolComponent {
    constructor(suratKontrolService, formSuratKontrolService, vclaimService) {
        this.suratKontrolService = suratKontrolService;
        this.formSuratKontrolService = formSuratKontrolService;
        this.vclaimService = vclaimService;
        this.dataSuratKontrol = [];
        this.dialogFormSuratKontrol = false;
        this.filter = { from: new Date };
    }
    ngOnInit() {
        this.suratKontrolService.dataSuratKontrol.subscribe(data => this.dataSuratKontrol = data);
        this.formSuratKontrolService.dialog.subscribe(data => this.dialogFormSuratKontrol = data);
        this.vclaimService.peserta.subscribe(data => this.handlePeserta(data));
    }
    handlePeserta(data) {
        if (data) {
            this.peserta = data.peserta;
            this.getDataSuratKontrol();
        }
    }
    getDataSuratKontrol() {
        setTimeout(() => {
            this.suratKontrolService.getDataSuratKontrol(this.peserta.noKartu, this.filter.from, '1');
        }, 50);
    }
}
SuratKontrolComponent.ɵfac = function SuratKontrolComponent_Factory(t) { return new (t || SuratKontrolComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_surat_kontrol_service__WEBPACK_IMPORTED_MODULE_0__.SuratKontrolService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_form_surat_kontrol_form_surat_kontrol_service__WEBPACK_IMPORTED_MODULE_1__.FormSuratKontrolService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_vclaim_service__WEBPACK_IMPORTED_MODULE_2__.VclaimService)); };
SuratKontrolComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: SuratKontrolComponent, selectors: [["app-surat-kontrol"]], decls: 36, vars: 12, consts: [[1, "row", "pt-3", "pb-3"], [1, "col", "mb-2", "clearfix"], [1, "float-left"], [1, "btn", "btn-sm", "btn-primary", "mr-1", 3, "click"], [1, "bi", "bi-plus-lg"], [1, "btn", "btn-sm", "btn-secondary", 3, "click"], [1, "bi", "bi-arrow-clockwise"], [1, "float-left", "ml-3", "pl-3", "border-left"], ["view", "month", "dateFormat", "M yy", "appendTo", "body", 3, "ngModel", "readonlyInput", "ngModelChange"], [1, "w-100", "border-bottom"], [1, "col", "p-0"], [1, "table", "table-striped", "table-hover", "border-bottom"], [1, "bg-gray-300"], ["width", "100"], [4, "ngIf"], ["header", "Form Surat Kontrol", "appendTo", "body", 3, "visible", "modal", "onHide", "visibleChange"], [4, "ngFor", "ngForOf"], [1, "btn", "btn-secondary", "btn-sm"], ["colspan", "8", 1, "tx-center"]], template: function SuratKontrolComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SuratKontrolComponent_Template_button_click_3_listener() { return ctx.formSuratKontrolService.openDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "i", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, " Data Baru");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SuratKontrolComponent_Template_button_click_6_listener() { return ctx.getDataSuratKontrol(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "i", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, " Bulan : ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "p-calendar", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function SuratKontrolComponent_Template_p_calendar_ngModelChange_10_listener() { return ctx.getDataSuratKontrol(); })("ngModelChange", function SuratKontrolComponent_Template_p_calendar_ngModelChange_10_listener($event) { return ctx.filter.from = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](11, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "table", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "tr", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17, "No. Surat Kontrol");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](19, "SEP Asal");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](21, "Jns. Pelayanan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](22, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23, "Poli Asal");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](25, "Poli Tujuan");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](27, "Dokter");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "th", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](29, "Tgl. Terbit");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](30, "th", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](31, "Tgl. Kontrol");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](32, SuratKontrolComponent_tbody_32_Template, 2, 1, "tbody", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](33, SuratKontrolComponent_tfoot_33_Template, 4, 0, "tfoot", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](34, "p-dialog", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("onHide", function SuratKontrolComponent_Template_p_dialog_onHide_34_listener() { return ctx.formSuratKontrolService.closeDialog(); })("visibleChange", function SuratKontrolComponent_Template_p_dialog_visibleChange_34_listener($event) { return ctx.dialogFormSuratKontrol = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](35, "app-form-surat-kontrol");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](10, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx.filter.from)("readonlyInput", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](22);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.dataSuratKontrol);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.dataSuratKontrol);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](11, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("visible", ctx.dialogFormSuratKontrol)("modal", true);
    } }, directives: [primeng_calendar__WEBPACK_IMPORTED_MODULE_5__.Calendar, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, primeng_dialog__WEBPACK_IMPORTED_MODULE_8__.Dialog, _form_surat_kontrol_form_surat_kontrol_component__WEBPACK_IMPORTED_MODULE_3__.FormSuratKontrolComponent, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.UpperCasePipe], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzdXJhdC1rb250cm9sLmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 84356:
/*!******************************************************************************!*\
  !*** ./src/app/modules/shared/vclaim/surat-kontrol/surat-kontrol.service.ts ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SuratKontrolService": function() { return /* binding */ SuratKontrolService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var src_app_services_app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/app.service */ 66475);





class SuratKontrolService {
    constructor(http, appService) {
        this.http = http;
        this.appService = appService;
        this.dataSuratKontrol = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject('');
        this.dialog = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject(false);
    }
    getDataSuratKontrol(nomorKartu, bulan, filter) {
        let filterBulan = this.appService.reformatDate(bulan);
        this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_vclaim('suratKontrol/byPeserta/nomorKartu/' + nomorKartu + '/bulan/' + filterBulan + '/filter/' + filter))
            .subscribe(data => this.dataSuratKontrol.next(data.response));
    }
    openDialog() {
        this.dialog.next(true);
    }
    closeDialog() {
        this.dialog.next(false);
    }
}
SuratKontrolService.ɵfac = function SuratKontrolService_Factory(t) { return new (t || SuratKontrolService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](src_app_services_app_service__WEBPACK_IMPORTED_MODULE_1__.AppService)); };
SuratKontrolService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: SuratKontrolService, factory: SuratKontrolService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 90107:
/*!***********************************************************!*\
  !*** ./src/app/modules/shared/vclaim/vclaim.component.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VclaimComponent": function() { return /* binding */ VclaimComponent; }
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _vclaim_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vclaim.service */ 82398);
/* harmony import */ var _surat_kontrol_form_surat_kontrol_form_surat_kontrol_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./surat-kontrol/form-surat-kontrol/form-surat-kontrol.service */ 36491);
/* harmony import */ var _registrasi_components_data_pasien_data_pasien_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../registrasi/components/data-pasien/data-pasien.service */ 95819);
/* harmony import */ var primeng_tabview__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/tabview */ 46304);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/calendar */ 11454);
/* harmony import */ var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! primeng/radiobutton */ 41751);
/* harmony import */ var primeng_autocomplete__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/autocomplete */ 91900);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! primeng/dropdown */ 14170);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _surat_kontrol_surat_kontrol_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./surat-kontrol/surat-kontrol.component */ 4690);
/* harmony import */ var _rujukan_rujukan_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./rujukan/rujukan.component */ 44794);
/* harmony import */ var _prb_prb_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./prb/prb.component */ 46092);
/* harmony import */ var _history_history_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./history/history.component */ 25917);
/* harmony import */ var _pulang_sep_pulang_sep_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pulang-sep/pulang-sep.component */ 99691);

















const _c0 = function () { return { width: "100%" }; };
function VclaimComponent_div_216_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "label", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2, "Naik Kelas");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](4, "p-dropdown", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "div", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](6, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "div", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](8, "Pembiayaan :");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](10, "p-dropdown", 92);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](11, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](12, "div", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](13, "Penanggung Jawab :");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](14, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](15, "p-dropdown", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](9, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("options", ctx_r0.results);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](10, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("options", ctx_r0.results);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](11, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("options", ctx_r0.results);
} }
function VclaimComponent_div_237_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "label", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](4, "Tgl. Kejadian");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](6, "p-calendar", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](8, "label", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](9, "No. Lap. Polisi");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](10, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](11, "input", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](12, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](13, "label", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](14, "Keterangan");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](15, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](16, "input", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](17, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](18, "label", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](19, "Suplesi");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](20, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](21, "p-dropdown", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](22, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](23, "label", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](24, "No. Suplesi");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](25, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](26, "input", 99);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](27, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](28, "div", 100);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](29, "label", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](30, "Lokasi Laka");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](31, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](32, "label", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](33, "Provinsi");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](34, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](35, "p-dropdown", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](36, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](37, "label", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](38, "Kabupaten");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](39, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](40, "p-dropdown", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](41, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](42, "label", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](43, "Kecamatan");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](44, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](45, "p-dropdown", 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("showIcon", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](13, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("options", ctx_r1.results);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](14, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("options", ctx_r1.results);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](15, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("options", ctx_r1.results);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](16, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("options", ctx_r1.results);
} }
const _c1 = function () { return { width: "150px" }; };
const _c2 = function () { return { "width": "100%" }; };
class VclaimComponent {
    constructor(fb, vclaimService, formSuratKontrolService, dataPasienService) {
        this.fb = fb;
        this.vclaimService = vclaimService;
        this.formSuratKontrolService = formSuratKontrolService;
        this.dataPasienService = dataPasienService;
        this.keyNomorKartu = '';
        this.keyNik = '';
        this.dialogFormPrb = false;
        this.dialogFormRujukKeluar = false;
    }
    ngOnInit() {
        this.initFormSep();
        this.initFormPeserta();
        this.vclaimService.peserta.subscribe(data => this.setFormPeserta(data));
        this.dataPasienService.pasien.subscribe(data => this.vclaimService.getPesertaByNomorKartu());
    }
    initFormSep() {
        this.formSep = this.fb.group({
            tanggal: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            noKartu: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            jnsKunjungan: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            suratKontrol: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            noRujukan: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            diagnosa: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            poliklinik: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            dokter: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            assessmentPel: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            hakKelas: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            naikKelas: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            norm: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            tlp: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            catatan: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            naikKelasPembiayaan: [''],
            naikKelasPenanggungJawab: [''],
            statusKecelakaan: [''],
            tglKejadian: [''],
            noLapPolisi: [''],
            keterangan: [''],
            suplesi: [''],
            noSuplesi: [''],
            provinsi: [''],
            kabupaten: [''],
            kecamatan: [''],
        });
    }
    initFormPeserta() {
        this.formPeserta = this.fb.group({
            nama: [''],
            noKartu: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            nik: [''],
            kelamin: [''],
            tglLahir: [''],
            usia: [''],
            status: [''],
            jnsPeserta: [''],
            hakKelas: [''],
            provider: [''],
            cobAsuransi: [''],
            cobNoAsuransi: [''],
            cobTglTat: [''],
            cobTglTmt: [''],
            norm: [''],
            tlp: [''],
            dinsos: [''],
            noSktm: [''],
            prb: ['']
        });
    }
    setFormPeserta(data) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u;
        if (data) {
            let peserta = data.peserta;
            (_a = this.formPeserta.get('nama')) === null || _a === void 0 ? void 0 : _a.patchValue(peserta.nama);
            (_b = this.formPeserta.get('noKartu')) === null || _b === void 0 ? void 0 : _b.patchValue(peserta.noKartu);
            (_c = this.formPeserta.get('nik')) === null || _c === void 0 ? void 0 : _c.patchValue(peserta.nik);
            (_d = this.formPeserta.get('kelamin')) === null || _d === void 0 ? void 0 : _d.patchValue(peserta.sex);
            (_e = this.formPeserta.get('tglLahir')) === null || _e === void 0 ? void 0 : _e.patchValue(peserta.tglLahir);
            (_f = this.formPeserta.get('usia')) === null || _f === void 0 ? void 0 : _f.patchValue(peserta.umur.umurSekarang);
            (_g = this.formPeserta.get('status')) === null || _g === void 0 ? void 0 : _g.patchValue(peserta.statusPeserta.keterangan);
            (_h = this.formPeserta.get('jnsPeserta')) === null || _h === void 0 ? void 0 : _h.patchValue(peserta.jenisPeserta.keterangan);
            (_j = this.formPeserta.get('hakKelas')) === null || _j === void 0 ? void 0 : _j.patchValue(peserta.hakKelas.keterangan);
            (_k = this.formPeserta.get('provider')) === null || _k === void 0 ? void 0 : _k.patchValue(peserta.provUmum.nmProvider);
            (_l = this.formPeserta.get('cobAsuransi')) === null || _l === void 0 ? void 0 : _l.patchValue(peserta.cob.nmAsuransi);
            (_m = this.formPeserta.get('cobNoAsuransi')) === null || _m === void 0 ? void 0 : _m.patchValue(peserta.cob.noAsuransi);
            (_o = this.formPeserta.get('cobTglTat')) === null || _o === void 0 ? void 0 : _o.patchValue(peserta.cob.tglTAT);
            (_p = this.formPeserta.get('cobTglTmt')) === null || _p === void 0 ? void 0 : _p.patchValue(peserta.cob.tglTMT);
            (_q = this.formPeserta.get('norm')) === null || _q === void 0 ? void 0 : _q.patchValue(peserta.mr.noMR);
            (_r = this.formPeserta.get('tlp')) === null || _r === void 0 ? void 0 : _r.patchValue(peserta.mr.noTelepon);
            (_s = this.formPeserta.get('dinsos')) === null || _s === void 0 ? void 0 : _s.patchValue(peserta.informasi.dinsos);
            (_t = this.formPeserta.get('noSktm')) === null || _t === void 0 ? void 0 : _t.patchValue(peserta.informasi.noSKTM);
            (_u = this.formPeserta.get('prb')) === null || _u === void 0 ? void 0 : _u.patchValue(peserta.informasi.prolanisPRB);
        }
    }
    getPesertaByNomorKartu(e) {
        if (e.code === 'Enter') {
            this.vclaimService.getPesertaByNomorKartu();
        }
    }
    getPesertaByNik(e) {
        if (e.code === 'Enter') {
            this.vclaimService.getPesertaByNik();
        }
    }
    search(e) {
    }
}
VclaimComponent.ɵfac = function VclaimComponent_Factory(t) { return new (t || VclaimComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_vclaim_service__WEBPACK_IMPORTED_MODULE_0__.VclaimService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_surat_kontrol_form_surat_kontrol_form_surat_kontrol_service__WEBPACK_IMPORTED_MODULE_1__.FormSuratKontrolService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_registrasi_components_data_pasien_data_pasien_service__WEBPACK_IMPORTED_MODULE_2__.DataPasienService)); };
VclaimComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({ type: VclaimComponent, selectors: [["app-vclaim"]], decls: 257, vars: 35, consts: [[1, "row", "mt-1"], [1, "col-4"], [1, "row", "mb-1"], [1, "col-4", "col-form-label"], [1, "col"], [1, "input-group"], ["type", "text", "placeholder", "No. Kartu BPJS", 1, "form-control", 3, "ngModel", "ngModelChange", "keyup"], [1, "input-group-append"], [1, "btn", "btn-primary", 3, "click"], [1, "bi", "bi-search"], [1, "input-append"], ["type", "text", "placeholder", "No. KTP / NIK", 1, "form-control", 3, "ngModel", "ngModelChange", "keyup"], [3, "formGroup"], ["type", "text", "formControlName", "nama", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "noKartu", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "nik", "readonly", "", 1, "form-control"], [1, "col", "pr-2"], ["type", "text", "formControlName", "kelamin", "readonly", "", 1, "form-control"], [1, "col", "pl-0"], ["type", "text", "formControlName", "tglLahir", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "usia", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "status", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "jnsPeserta", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "hakKelas", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "provider", "readonly", "", 1, "form-control"], [1, "btn", "btn-outline-light", "btn-xs"], [1, "bi", "bi-plus-lg", "mr-1"], [1, "row", "mb-1", "border-bottom"], [1, "col", "border-left"], ["type", "text", "formControlName", "cobAsuransi", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "cobNoAsuransi", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "cobTglTat", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "cobTglTmt", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "norm", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "tlp", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "dinsos", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "noSktm", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "prb", "readonly", "", 1, "form-control"], [1, "col-8"], [3, "scrollable"], ["header", "Form SEP"], [1, "row", "pt-3", "pb-3"], [1, "col-3", "col-form-label"], [1, "col-auto"], ["formControlName", "tanggal", "appendTo", "body", 3, "showIcon"], [1, "btn", "btn-secondary"], [1, "bi", "bi-file-earmark", "mr-1"], [1, "col", "pt-2"], ["name", "jnsKunjungan", "formControlName", "jnsKunjungan", "value", "rujukanBaru"], ["name", "jnsKunjungan", "formControlName", "jnsKunjungan", "value", "kontrolKembali", "styleClass", "ml-2"], ["name", "jnsKunjungan", "formControlName", "jnsKunjungan", "value", "rawatInap", "styleClass", "ml-2"], ["name", "jnsKunjungan", "formControlName", "jnsKunjungan", "value", "igd", "styleClass", "ml-2"], ["name", "jnsKunjungan", "formControlName", "jnsKunjungan", "value", "antarPoli", "styleClass", "ml-2"], ["ng-show", "jnsPelayanan=='kontrolKembali'"], ["type", "text", "formControlName", "suratKontrol", 1, "form-control"], [1, "btn", "btn-secondary", 3, "click"], [1, "bi", "bi-table", "mr-1"], ["ng-show", "jnsPelayanan == 'rujukanBaru' || formSep.skdp.noSurat || jnsPelayanan == 'antarPoli' ", 1, "row", "mb-1"], ["type", "text", "formControlName", "noRujukan", 1, "form-control"], ["ng-show", "formSepBaru.diagnosa.$error.required || !formSep.diagAwal", 1, "fontello-icon-attention-circle", "error"], [1, "col-5"], ["formControlName", "diagnosa", 3, "suggestions", "inputStyle", "completeMethod"], ["ng-show", "jnsPelayanan!='rawatInap' && jnsPelayanan!='igd'", 1, "row", "mb-1"], ["formControlName", "poliklinik", 3, "suggestions", "inputStyle", "completeMethod"], ["ng-show", "jnsPelayanan!='rawatInap'", 1, "row", "mb-1"], ["optionLabel", "name", "formControlName", "dokter", 3, "options"], ["ng-show", "formSep.poli.tujuan != poliRujukan && jnsPelayanan=='kontrolKembali' || jnsPelayanan=='antarPoli' ", 1, "row", "mb-1"], ["ng-show", "formSepBaru.assesmentPel.$error.required", 1, "fontello-icon-attention-circle", "error"], ["optionLabel", "name", "formControlName", "assessmentPel", 3, "options"], [1, "col-auto", "pr-2"], ["type", "text", "formControlName", "hakKelas", 1, "form-control"], [1, "col-auto", "pl-0", "pr-2", "col-form-label"], [1, "col-auto", "pl-0"], ["class", "row mb-1", 4, "ngIf"], ["type", "text", "formControlName", "norm", 1, "form-control"], ["type", "text", "formControlName", "tlp", 1, "form-control"], ["type", "text", "formControlName", "catatan", 1, "form-control"], ["optionLabel", "name", "formControlName", "statusKecelakaan", 3, "options"], ["class", "row mt-3 pt-3 border-top", 4, "ngIf"], [1, "w-100"], [1, "row", "bg-gray-500", "pt-3", "pb-3", "mt-3"], [1, "col-3"], [1, "btn", "btn-sm", "btn-primary"], [1, "bi", "bi-save", "mr-1"], ["header", "Surat Kontrol"], ["header", "Rujukan"], ["header", "PRB"], ["header", "History SEP"], ["header", "Pulang Rawat Inap / IGD"], ["optionLabel", "name", "formControlName", "naikKelas", 3, "options"], [1, "row", "pb-2", "mb-2"], [1, "mb-1"], ["optionLabel", "name", "formControlName", "naikKelasPembiayaan", 3, "options"], ["optionLabel", "name", "formControlName", "naikKelasPenanggungJawab", 3, "options"], [1, "row", "mt-3", "pt-3", "border-top"], ["formControlName", "tglKejadian", 3, "showIcon"], ["type", "text", "formControlName", "noLapPolisi", 1, "form-control"], ["type", "text", "formControlName", "keterangan", 1, "form-control"], ["optionLabel", "name", "formControlName", "suplesi", 3, "options"], ["type", "text", "formControlName", "noSuplesi", 1, "form-control"], [1, "row", "mb-1", "border-bottom", "tx-bold"], ["optionLabel", "name", "formControlName", "provinsi", 3, "options"], ["optionLabel", "name", "formControlName", "kabupaten", 3, "options"], ["optionLabel", "name", "formControlName", "kecamatan", 3, "options"]], template: function VclaimComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](4, "Cari");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "input", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("ngModelChange", function VclaimComponent_Template_input_ngModelChange_7_listener($event) { return ctx.keyNomorKartu = $event; })("keyup", function VclaimComponent_Template_input_keyup_7_listener($event) { return ctx.getPesertaByNomorKartu($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](8, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function VclaimComponent_Template_button_click_9_listener() { return ctx.vclaimService.getPesertaByNomorKartu(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](10, "i", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](11, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](12, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](13, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](14, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](15, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](16, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("ngModelChange", function VclaimComponent_Template_input_ngModelChange_16_listener($event) { return ctx.keyNik = $event; })("keyup", function VclaimComponent_Template_input_keyup_16_listener($event) { return ctx.getPesertaByNik($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](17, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](18, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function VclaimComponent_Template_button_click_18_listener() { return ctx.vclaimService.getPesertaByNik(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](19, "i", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](20, "form", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](21, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](22, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](23, "Nama");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](24, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](25, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](26, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](27, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](28, "No. Kartu");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](29, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](30, "input", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](31, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](32, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](33, "NIK");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](34, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](35, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](36, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](37, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](38, "Kelamin - Tgl. Lahir");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](39, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](40, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](41, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](42, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](43, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](44, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](45, "Usia");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](46, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](47, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](48, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](49, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](50, "Status Peserta");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](51, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](52, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](53, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](54, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](55, "Jenis Peserta");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](56, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](57, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](58, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](59, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](60, "Hak Kelas");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](61, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](62, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](63, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](64, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](65, "Provider");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](66, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](67, "input", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](68, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](69, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](70, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](71, "i", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](72, "Lebih Detail");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](73, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](74, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](75, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](76, "COB");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](77, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](78, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](79, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](80, "Nama Asuransi");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](81, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](82, "input", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](83, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](84, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](85, "No. Asuransi");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](86, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](87, "input", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](88, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](89, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](90, "Tgl. TAT");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](91, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](92, "input", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](93, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](94, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](95, "Tgl. TMT");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](96, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](97, "input", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](98, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](99, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](100, "Med. Record");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](101, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](102, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](103, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](104, " No. MR");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](105, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](106, "input", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](107, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](108, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](109, " No. Tlp");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](110, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](111, "input", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](112, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](113, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](114, "Informasi");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](115, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](116, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](117, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](118, " Dinsos");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](119, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](120, "input", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](121, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](122, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](123, " No. SKTM");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](124, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](125, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](126, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](127, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](128, " PRB");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](129, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](130, "input", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](131, "div", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](132, "p-tabView", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](133, "p-tabPanel", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](134, "div", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](135, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](136, "form", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](137, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](138, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](139, "Tanggal SEP");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](140, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](141, "p-calendar", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](142, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](143, "button", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](144, "i", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](145, " SEP Backdate / Fingerprint");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](146, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](147, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](148, "Jenis Kunjungan");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](149, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](150, "p-radioButton", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](151, "Rujukan Baru ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](152, "p-radioButton", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](153, "Kontrol Kembali ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](154, "p-radioButton", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](155, "Rawat Inap ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](156, "p-radioButton", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](157, "IGD ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](158, "p-radioButton", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](159, "Rujukan Internal ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](160, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](161, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](162, "span", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](163, "Surat Kontrol");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](164, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](165, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](166, "input", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](167, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](168, "button", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function VclaimComponent_Template_button_click_168_listener() { return ctx.formSuratKontrolService.openDialog(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](169, "i", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](170, "Data Baru");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](171, "button", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](172, "i", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](173, " View Data");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](174, "div", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](175, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](176, "No. Rujukan");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](177, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](178, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](179, "input", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](180, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](181, "button", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](182, "i", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](183, " View Data");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](184, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](185, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](186, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](187, "Diagnosa ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](188, "span", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](189, "div", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](190, "p-autoComplete", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("completeMethod", function VclaimComponent_Template_p_autoComplete_completeMethod_190_listener($event) { return ctx.search($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](191, "div", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](192, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](193, "Poliklinik");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](194, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](195, "p-autoComplete", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("completeMethod", function VclaimComponent_Template_p_autoComplete_completeMethod_195_listener($event) { return ctx.search($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](196, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](197, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](198, "Dokter / DPJP");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](199, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](200, "p-dropdown", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](201, "div", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](202, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](203, "Assessment Pelayanan ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](204, "span", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](205, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](206, "p-dropdown", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](207, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](208, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](209, "Hak Kelas");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](210, "div", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](211, "input", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](212, "label", 71);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](213, "Naik Kelas");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](214, "div", 72);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](215, "input", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](216, VclaimComponent_div_216_Template, 16, 12, "div", 73);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](217, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](218, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](219, "No. RM");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](220, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](221, "input", 74);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](222, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](223, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](224, "No. Tlp");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](225, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](226, "input", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](227, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](228, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](229, "Catatan");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](230, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](231, "input", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](232, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](233, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](234, "Status Kecelakaan");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](235, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](236, "p-dropdown", 77);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](237, VclaimComponent_div_237_Template, 46, 17, "div", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](238, "div", 79);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](239, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](240, "div", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](241, "div", 81);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](242, "\u00A0");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](243, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](244, "button", 82);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](245, "i", 83);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](246, " Simpan");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](247, "p-tabPanel", 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](248, "app-surat-kontrol");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](249, "p-tabPanel", 85);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](250, "app-rujukan");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](251, "p-tabPanel", 86);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](252, "app-prb");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](253, "p-tabPanel", 87);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](254, "app-history");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](255, "p-tabPanel", 88);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](256, "app-pulang-sep");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    } if (rf & 2) {
        let tmp_17_0;
        let tmp_20_0;
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngModel", ctx.keyNomorKartu);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngModel", ctx.keyNik);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("formGroup", ctx.formPeserta);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](112);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("scrollable", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("formGroup", ctx.formSep);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](27, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("showIcon", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](49);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](28, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("suggestions", ctx.results)("inputStyle", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](29, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](30, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("suggestions", ctx.results)("inputStyle", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](31, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](32, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("options", ctx.results);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](33, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("options", ctx.results);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ((tmp_17_0 = ctx.formSep.get("hakKelas")) == null ? null : tmp_17_0.value) == "1");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](34, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("options", ctx.results);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ((tmp_20_0 = ctx.formSep.get("statusKecelakaan")) == null ? null : tmp_20_0.value) == "2");
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControlName, primeng_tabview__WEBPACK_IMPORTED_MODULE_10__.TabView, primeng_tabview__WEBPACK_IMPORTED_MODULE_10__.TabPanel, primeng_calendar__WEBPACK_IMPORTED_MODULE_11__.Calendar, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_12__.RadioButton, primeng_autocomplete__WEBPACK_IMPORTED_MODULE_13__.AutoComplete, primeng_dropdown__WEBPACK_IMPORTED_MODULE_14__.Dropdown, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _surat_kontrol_surat_kontrol_component__WEBPACK_IMPORTED_MODULE_3__.SuratKontrolComponent, _rujukan_rujukan_component__WEBPACK_IMPORTED_MODULE_4__.RujukanComponent, _prb_prb_component__WEBPACK_IMPORTED_MODULE_5__.PrbComponent, _history_history_component__WEBPACK_IMPORTED_MODULE_6__.HistoryComponent, _pulang_sep_pulang_sep_component__WEBPACK_IMPORTED_MODULE_7__.PulangSepComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ2Y2xhaW0uY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 82398:
/*!*********************************************************!*\
  !*** ./src/app/modules/shared/vclaim/vclaim.service.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VclaimService": function() { return /* binding */ VclaimService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var _registrasi_components_data_pasien_data_pasien_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../registrasi/components/data-pasien/data-pasien.service */ 95819);





class VclaimService {
    constructor(http, dataPasienService) {
        this.http = http;
        this.dataPasienService = dataPasienService;
        this.peserta = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject('');
        this.dialog = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject(false);
        this.dataPasienService.pasien.subscribe(data => this.dataPasien = data);
    }
    getPesertaByNomorKartu() {
        if (this.dataPasien.no_asuransi) {
            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_vclaim('peserta/nomorKartu/' + this.dataPasien.no_asuransi)).subscribe(data => this.peserta.next(data.response));
        }
    }
    getPesertaByNik() {
        if (this.dataPasien.nik) {
            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_vclaim('peserta/nik/' + this.dataPasien.nik)).subscribe(data => this.peserta.next(data.response));
        }
    }
    openDialog() {
        this.dialog.next(true);
    }
    closeDialog() {
        this.dialog.next(false);
    }
}
VclaimService.ɵfac = function VclaimService_Factory(t) { return new (t || VclaimService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_registrasi_components_data_pasien_data_pasien_service__WEBPACK_IMPORTED_MODULE_1__.DataPasienService)); };
VclaimService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: VclaimService, factory: VclaimService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 57829:
/*!***********************************************!*\
  !*** ./src/app/providers/http.interceptor.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DEFAULT_TIMEOUT": function() { return /* binding */ DEFAULT_TIMEOUT; },
/* harmony export */   "HttpProvider": function() { return /* binding */ HttpProvider; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 8117);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 53803);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 97859);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 71435);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 18293);
/* harmony import */ var _error_handler_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../error-handler.service */ 40946);
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/loading.service */ 4471);






const DEFAULT_TIMEOUT = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.InjectionToken('defaultTimeout');
class HttpProvider {
    constructor(defaultTimeout, errorHandleService, loadingService) {
        this.defaultTimeout = defaultTimeout;
        this.errorHandleService = errorHandleService;
        this.loadingService = loadingService;
    }
    intercept(req, next) {
        const timeoutValue = req.headers.get('timeout') || this.defaultTimeout;
        const timeoutValueNumeric = Number(timeoutValue);
        return next.handle(req).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.timeout)(timeoutValueNumeric), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.retry)(3), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.finalize)(() => {
            this.loadingService.status.next(false);
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.catchError)((error) => {
            return rxjs__WEBPACK_IMPORTED_MODULE_7__.EMPTY;
        }));
    }
}
HttpProvider.ɵfac = function HttpProvider_Factory(t) { return new (t || HttpProvider)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](DEFAULT_TIMEOUT), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_error_handler_service__WEBPACK_IMPORTED_MODULE_0__.ErrorHandlerService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_services_loading_service__WEBPACK_IMPORTED_MODULE_1__.LoadingService)); };
HttpProvider.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: HttpProvider, factory: HttpProvider.ɵfac });


/***/ }),

/***/ 66475:
/*!*****************************************!*\
  !*** ./src/app/services/app.service.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppService": function() { return /* binding */ AppService; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2316);

class AppService {
    constructor() { }
    reformatDate(date) {
        let parsingTanggal = date.toLocaleDateString('id-ID').toString().split('/');
        return parsingTanggal[2].toString() + '-' + parsingTanggal[1].toString().padStart(2, '0') + '-' + parsingTanggal[0].toString().padStart(2, '0');
    }
}
AppService.ɵfac = function AppService_Factory(t) { return new (t || AppService)(); };
AppService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: AppService, factory: AppService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 4471:
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoadingService": function() { return /* binding */ LoadingService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);


class LoadingService {
    constructor() {
        this.status = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(false);
    }
}
LoadingService.ɵfac = function LoadingService_Factory(t) { return new (t || LoadingService)(); };
LoadingService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: LoadingService, factory: LoadingService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 66367:
/*!**********************************************************!*\
  !*** ./src/app/templates/calendar/calendar.component.ts ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CalendarComponent": function() { return /* binding */ CalendarComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2316);

class CalendarComponent {
    constructor() { }
    ngOnInit() {
    }
}
CalendarComponent.ɵfac = function CalendarComponent_Factory(t) { return new (t || CalendarComponent)(); };
CalendarComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CalendarComponent, selectors: [["app-calendar"]], decls: 7, vars: 0, consts: [[1, "top-menu", "tx-left", "p-pr-3", "p-pt-1"], [2, "color", "#654417"], [1, "p-pt-1", 2, "color", "white", "font-size", "1rem"], [1, "pi", "pi-calendar"]], template: function CalendarComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "small", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Kalender");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Jumat, 1 Juli 2021 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "i", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjYWxlbmRhci5jb21wb25lbnQuY3NzIn0= */"] });


/***/ }),

/***/ 15710:
/*!****************************************************!*\
  !*** ./src/app/templates/login/login.component.ts ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginComponent": function() { return /* binding */ LoginComponent; }
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _login_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.service */ 75426);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);






function LoginComponent_p_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "p", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r0.messageErrorLogin);
} }
class LoginComponent {
    constructor(form, loginService, router) {
        this.form = form;
        this.loginService = loginService;
        this.router = router;
        this.messageErrorLogin = '';
    }
    ngOnInit() {
        this.loginService.loginData.subscribe(data => this.handleLogin(data));
        this.loginService.errorMessage.subscribe(data => this.messageErrorLogin = data);
        this.formLogin = this.form.group({
            username: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required],
            password: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]
        });
    }
    listenLogin(e) {
        if (e.code == 'Enter') {
            this.doLogin();
        }
    }
    doLogin() {
        this.gotoDashboarPage();
        // this.loginService.userData.next(this.formLogin.value);
        // this.loginService.login();
    }
    handleLogin(responseLogin) {
        if (responseLogin && responseLogin.auth) {
            localStorage.setItem('login', JSON.stringify(responseLogin));
            this.gotoDashboarPage();
        }
    }
    gotoDashboarPage() {
        this.router.navigateByUrl('rikkes');
    }
}
LoginComponent.ɵfac = function LoginComponent_Factory(t) { return new (t || LoginComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_login_service__WEBPACK_IMPORTED_MODULE_0__.LoginService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.Router)); };
LoginComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: LoginComponent, selectors: [["app-login"]], decls: 21, vars: 2, consts: [[1, "login-page"], [1, "row", "justify-content-center"], [1, "col-auto", "login-container", "sign-wrapper", "rounded"], [1, "wd-100p"], [1, "tx-color-01", "mg-b-5"], [1, "tx-16", "mg-b-20"], [3, "formGroup"], [1, "form-group"], ["type", "email", "formControlName", "username", "placeholder", "Enter your username", 1, "form-control", 3, "keyup"], [1, "form-group", "p-mt-2"], [1, "d-flex", "justify-content-between", "mg-b-5"], [1, "mg-b-0-f"], ["type", "password", "formControlName", "password", "placeholder", "Enter your password", 1, "form-control", 3, "keyup"], ["class", "alert alert-danger p-mt-1 p-mb-1 tx-center", 4, "ngIf"], [1, "btn", "btn-brand-02", "btn-block", "p-mt-2", 3, "click"], [1, "alert", "alert-danger", "p-mt-1", "p-mb-1", "tx-center"]], template: function LoginComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "h3", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5, "Sign In");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "p", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7, "Welcome back! Please signin to continue.");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "form", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11, "Username");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("keyup", function LoginComponent_Template_input_keyup_12_listener($event) { return ctx.listenLogin($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "label", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, "Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "input", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("keyup", function LoginComponent_Template_input_keyup_17_listener($event) { return ctx.listenLogin($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](18, LoginComponent_p_18_Template, 2, 1, "p", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function LoginComponent_Template_button_click_19_listener() { return ctx.doLogin(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20, "Sign In");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.formLogin);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.messageErrorLogin);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsb2dpbi5jb21wb25lbnQuY3NzIn0= */"] });


/***/ }),

/***/ 75426:
/*!**************************************************!*\
  !*** ./src/app/templates/login/login.service.ts ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginService": function() { return /* binding */ LoginService; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 53882);




class LoginService {
    constructor(http) {
        this.http = http;
        this.userData = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
        this.errorMessage = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
        this.loginData = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    }
    login() {
        this.http.post(_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('do_login'), this.userData.value)
            .subscribe(data => {
            if (data.auth) {
                this.loginData.next(data);
            }
            else {
                this.errorMessage.next('Username atau Password anda salah.');
            }
        });
    }
}
LoginService.ɵfac = function LoginService_Factory(t) { return new (t || LoginService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient)); };
LoginService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: LoginService, factory: LoginService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 74905:
/*!**********************************************************!*\
  !*** ./src/app/templates/menu-emr/menu-emr.component.ts ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuEmrComponent": function() { return /* binding */ MenuEmrComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2316);

class MenuEmrComponent {
    constructor() {
        this.term = '';
        this.subMenu = [];
    }
    ngOnInit() {
        this.subMenu = [
            { label: 'Subjective', routerLink: 'medical_record/subjective' },
            { label: 'Pemeriksaan', routerLink: 'medical_record/pemeriksaan' },
            { label: 'Diagnosa & Prosedur', routerLink: 'medical_record/diagnosa_prosedur' },
            { label: 'E-Resep', routerLink: 'medical_record/farmasi' },
            {
                label: 'Penunjang',
                items: [
                    { label: 'Laboratorium' },
                    { label: 'Radiologi' },
                ]
            },
            { label: 'Planning', routerLink: 'medical_record/planning' },
            { label: 'Summary Review', routerLink: 'medical_record' },
        ];
        this.items = [{
                label: 'Menu',
                items: [
                    { label: 'SOAP', link: '/cppt' },
                    { label: 'Pengkajian Awal Medis', link: '/pengkajian_awal_medis' },
                    { label: 'Laporan Pembedahaan Dengan Anestesi Lokal', link: '/lap_bedah_anest_lokal' },
                    { label: 'Surat Masuk Perawatan', link: '/surat_masuk_perawatan' },
                    { label: 'Pengajuan Pembedahaan', link: '/pengajuan_pembedahaan' },
                    // {label: 'Catatan Edukasi dan Informasi Terintegrasi Pasien / Keluarga'},
                    // {label: 'Persetujuan Tindakan Medis'},
                    // {label: 'DPJP dan PPJA'},
                    // {label: 'Catatan Pemindahan Pasien Antar Ruangan'},
                    // {label: 'Penandaaan Lokasi Operasi'},
                    // {label: 'Daftar Tilik Catatan Keperawatan Perioperatif'},
                ]
            }, {
                label: 'Penunjang',
                items: [
                    { label: 'Laboratorium', link: '/laboratorium' },
                    { label: 'Radiologi', link: '/radiologi' },
                    { label: 'Farmasi', link: '/e_resep' },
                ]
            }];
    }
    setActiveMenu(e) {
        let childs = document.getElementsByClassName('nav-link');
        Array.prototype.forEach.call(childs, function (el) {
            el.classList.remove('active');
        });
        e.target.classList.add('active');
    }
}
MenuEmrComponent.ɵfac = function MenuEmrComponent_Factory(t) { return new (t || MenuEmrComponent)(); };
MenuEmrComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: MenuEmrComponent, selectors: [["app-menu-emr"]], decls: 0, vars: 0, template: function MenuEmrComponent_Template(rf, ctx) { }, styles: [".sub-menu[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    list-style: none;\r\n    margin: 0;\r\n    padding: 0;\r\n}\r\n\r\n.sub-menu[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\r\n    display: list-item;\r\n    margin: 0;\r\n    padding: 0;\r\n}\r\n\r\n.p-menubar[_ngcontent-%COMP%]{\r\n    padding: 0 !important;\r\n    background: none !important;\r\n    border: none !important;\r\n    font-size: 12px !important;\r\n}\r\n\r\n.nav-link[_ngcontent-%COMP%] {\r\n    cursor: pointer;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lbnUtZW1yLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxhQUFhO0lBQ2IsZ0JBQWdCO0lBQ2hCLFNBQVM7SUFDVCxVQUFVO0FBQ2Q7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsU0FBUztJQUNULFVBQVU7QUFDZDs7QUFFQTtJQUNJLHFCQUFxQjtJQUNyQiwyQkFBMkI7SUFDM0IsdUJBQXVCO0lBQ3ZCLDBCQUEwQjtBQUM5Qjs7QUFFQTtJQUNJLGVBQWU7QUFDbkIiLCJmaWxlIjoibWVudS1lbXIuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zdWItbWVudSB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgbGlzdC1zdHlsZTogbm9uZTtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIHBhZGRpbmc6IDA7XHJcbn1cclxuXHJcbi5zdWItbWVudSBsaSB7XHJcbiAgICBkaXNwbGF5OiBsaXN0LWl0ZW07XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG59XHJcblxyXG4ucC1tZW51YmFye1xyXG4gICAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyOiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXNpemU6IDEycHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLm5hdi1saW5rIHtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufSJdfQ== */"] });


/***/ }),

/***/ 72462:
/*!**************************************************!*\
  !*** ./src/app/templates/menu/menu.component.ts ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuComponent": function() { return /* binding */ MenuComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var primeng_menubar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/menubar */ 46103);


class MenuComponent {
    constructor() {
        this.menus = [];
    }
    ngOnInit() {
        this.menus = [
            { label: 'Rikkes', icon: 'bi bi-file-text', routerLink: 'rikkes' },
            { label: 'Admisi & Pendaftaran', icon: 'bi bi-file-earmark-person', routerLink: 'registrasi' },
            { label: 'Medical Record', icon: 'bi bi-file-earmark-text', routerLink: 'medicalRecord' },
            { label: 'Rawat Jalan', icon: 'bi bi-clipboard-pulse', routerLink: 'rawatJalan' },
            { label: 'Rawat Inap', icon: 'bi bi-hospital' },
            { label: 'Kasir', icon: 'bi bi-cash-coin' }
        ];
    }
}
MenuComponent.ɵfac = function MenuComponent_Factory(t) { return new (t || MenuComponent)(); };
MenuComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: MenuComponent, selectors: [["app-menu"]], decls: 1, vars: 1, consts: [["name", "", 3, "model"]], template: function MenuComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "p-menubar", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("model", ctx.menus);
    } }, directives: [primeng_menubar__WEBPACK_IMPORTED_MODULE_1__.Menubar], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtZW51LmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 44906:
/*!**************************************************!*\
  !*** ./src/app/templates/user/user.component.ts ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserComponent": function() { return /* binding */ UserComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/overlaypanel */ 59502);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/api */ 88055);
/* harmony import */ var primeng_menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/menu */ 63493);




function UserComponent_ng_template_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "p-menu", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("model", ctx_r1.menuItems);
} }
class UserComponent {
    constructor() {
        this.menuItems = [];
    }
    ngOnInit() {
        this.menuItems = [
            { label: 'Edit Profile', icon: 'pi pi-pencil' },
            { label: 'Change Password', icon: 'pi pi-lock' },
            { label: 'Logout', icon: 'pi pi-sign-out' },
        ];
    }
}
UserComponent.ɵfac = function UserComponent_Factory(t) { return new (t || UserComponent)(); };
UserComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: UserComponent, selectors: [["app-user"]], decls: 13, vars: 1, consts: [[1, "user-login", "p-pl-4", "p-pb-2", "p-pr-3", "p-pt-1", "clickable", 2, "display", "inline-flex", 3, "click"], [1, "avatar", "p-mr-3", "p-mt-2"], [1, "rounded-circle", 3, "src"], [1, "p-pt-1", "p-pb-2", "p-pr-1", "tx-left"], [2, "color", "#ffc77c"], [1, "p-pl-2", "p-pr-2", 2, "padding-top", "20px", "color", "#f9d2a0"], [1, "pi", "pi-chevron-circle-down"], ["op", ""], ["pTemplate", ""], [2, "width", "200px"], [3, "model"]], template: function UserComponent_Template(rf, ctx) { if (rf & 1) {
        const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UserComponent_Template_div_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r2); const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](11); return _r0.toggle($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "img", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "small", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Dokter");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, " dr. R. Bebet Prasetyo SpU ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "i", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "p-overlayPanel", null, 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, UserComponent_ng_template_12_Template, 2, 1, "ng-template", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", "assets/drbebet.jpg", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
    } }, directives: [primeng_overlaypanel__WEBPACK_IMPORTED_MODULE_1__.OverlayPanel, primeng_api__WEBPACK_IMPORTED_MODULE_2__.PrimeTemplate, primeng_menu__WEBPACK_IMPORTED_MODULE_3__.Menu], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ1c2VyLmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 92340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": function() { return /* binding */ environment; }
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    appVersion: __webpack_require__(/*! ../../package.json */ 4147).version,
    production: true,
    base: 'area',
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 14431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 71570);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 36747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 92340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.error(err));


/***/ }),

/***/ 4147:
/*!**********************!*\
  !*** ./package.json ***!
  \**********************/
/***/ (function(module) {

"use strict";
module.exports = JSON.parse('{"name":"iniapps","version":"0.0.0","scripts":{"ng":"ng","start":"ng serve","build":"ng build","test":"ng test","lint":"ng lint","e2e":"ng e2e"},"private":true,"dependencies":{"@angular/animations":"^12.1.2","@angular/cdk":"^12.1.2","@angular/common":"^12.1.2","@angular/compiler":"^12.1.2","@angular/core":"^12.1.2","@angular/forms":"^12.1.2","@angular/material":"^12.1.2","@angular/platform-browser":"^12.1.2","@angular/platform-browser-dynamic":"^12.1.2","@angular/router":"^12.1.2","@ckeditor/ckeditor5-angular":"^2.0.2","bootstrap-icons":"^1.8.1","cornerstone-core":"^2.3.0","cornerstone-math":"^0.1.9","cornerstone-tools":"^5.1.2","cornerstone-wado-image-loader":"^3.3.2","dicom-parser":"^1.8.7","hammerjs":"^2.0.8","konva":"^8.3.6","ng-dicomviewer":"^0.1.38","ng2-search-filter":"^0.5.1","primeflex":"^2.0.0","primeicons":"^4.1.0","primeng":"^12.2.3","quill":"^1.3.7","rxjs":"~6.6.0","tslib":"^2.3.0","zone.js":"~0.11.4"},"devDependencies":{"@angular-devkit/build-angular":"^12.1.2","@angular/cli":"^12.1.2","@angular/compiler-cli":"^12.1.2","@ckeditor/ckeditor5-build-classic":"^27.1.0","@types/jasmine":"^3.8.1","@types/node":"^12.20.54","codelyzer":"^6.0.2","jasmine-core":"~3.6.0","jasmine-spec-reporter":"~5.0.0","karma":"^6.3.4","karma-chrome-launcher":"~3.1.0","karma-coverage":"~2.0.3","karma-jasmine":"~4.0.0","karma-jasmine-html-reporter":"^1.7.0","protractor":"~7.0.0","ts-node":"~8.3.0","tslint":"~6.1.0","typescript":"~4.2"}}');

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, ["vendor"], function() { return __webpack_exec__(14431); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main-es2015.js.map