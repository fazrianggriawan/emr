(function () {
  "use strict";

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

  (self["webpackChunkiniapps"] = self["webpackChunkiniapps"] || []).push([["default-src_app_modules_registrasi_registrasi_module_ts"], {
    /***/
    81016:
    /*!************************************************************************************!*\
      !*** ./src/app/modules/registrasi/components/data-pasien/data-pasien.component.ts ***!
      \************************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "DataPasienComponent": function DataPasienComponent() {
          return (
            /* binding */
            _DataPasienComponent
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/forms */
      1707);
      /* harmony import */


      var _data_pasien_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./data-pasien.service */
      95819);
      /* harmony import */


      var primeng_table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! primeng/table */
      6536);
      /* harmony import */


      var primeng_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! primeng/api */
      88055);
      /* harmony import */


      var primeng_inputmask__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! primeng/inputmask */
      71838);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/common */
      54364);

      function DataPasienComponent_ng_template_2_Template(rf, ctx) {
        if (rf & 1) {
          var _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "tr");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "No.RM");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "Nama");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6, "Tgl. Lahir");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8, "Alamat");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10, "No. Telp");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12, "No. Asuransi / BPJS");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "tr");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "input", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("keyup", function DataPasienComponent_ng_template_2_Template_input_keyup_15_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r4);

            var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();

            return ctx_r3.sorting($event);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "input", 6);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("keyup", function DataPasienComponent_ng_template_2_Template_input_keyup_17_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r4);

            var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();

            return ctx_r5.sorting($event);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "p-inputMask", 7);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("keyup", function DataPasienComponent_ng_template_2_Template_p_inputMask_keyup_19_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r4);

            var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();

            return ctx_r6.sorting($event);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "input", 8);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("keyup", function DataPasienComponent_ng_template_2_Template_input_keyup_21_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r4);

            var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();

            return ctx_r7.sorting($event);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](23, "input", 9);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("keyup", function DataPasienComponent_ng_template_2_Template_input_keyup_23_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r4);

            var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();

            return ctx_r8.sorting($event);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](25, "input", 10);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("keyup", function DataPasienComponent_ng_template_2_Template_input_keyup_25_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r4);

            var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();

            return ctx_r9.sorting($event);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        }
      }

      function DataPasienComponent_ng_template_3_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "tr", 11);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var item_r10 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("pSelectableRow", item_r10);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item_r10.norm);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item_r10.nama);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item_r10.tgl_lahir);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item_r10.alamat);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item_r10.tlp);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](item_r10.no_asuransi);
        }
      }

      function DataPasienComponent_ng_template_4_tr_0_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "tr");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "td", 13);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "i", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, " Silahkan Melakukan Pencarian.");

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        }
      }

      function DataPasienComponent_ng_template_4_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, DataPasienComponent_ng_template_4_tr_0_Template, 4, 0, "tr", 12);
        }

        if (rf & 2) {
          var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r2.dataPasien.length == 0);
        }
      }

      var _c0 = function _c0() {
        return {
          "min-height": "200px"
        };
      };

      var _DataPasienComponent = /*#__PURE__*/function () {
        function _DataPasienComponent(fb, dataPasienService) {
          _classCallCheck(this, _DataPasienComponent);

          this.fb = fb;
          this.dataPasienService = dataPasienService;
          this.showDialog = true;
          this.dataPasien = [];
        }

        _createClass(_DataPasienComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.initForm();
            this.dataPasienService.dataPasien.subscribe(function (data) {
              return _this.dataPasien = data;
            });
            this.dataPasienService.dialog.subscribe(function (data) {
              return _this.showDialog = data;
            });
          }
        }, {
          key: "initForm",
          value: function initForm() {
            this.form = this.fb.group({
              norm: [''],
              nama: [''],
              tglLahir: [''],
              alamat: [''],
              tlp: [''],
              noAsuransi: ['']
            });
          }
        }, {
          key: "sorting",
          value: function sorting(e) {
            var _a, _b;

            if (e.code == 'Enter') {
              var tglLahir = this.form.value.tglLahir;

              if (tglLahir) {
                var lahir = tglLahir.substr(6, 4) + '-' + tglLahir.substr(3, 2) + '-' + tglLahir.substr(0, 2);
                (_a = this.form.get('tglLahir')) === null || _a === void 0 ? void 0 : _a.patchValue(lahir);
              }

              this.dataPasienService.getDataPasien(this.form.value);
              (_b = this.form.get('tglLahir')) === null || _b === void 0 ? void 0 : _b.patchValue(tglLahir);
            }
          }
        }, {
          key: "onSelectPasien",
          value: function onSelectPasien() {
            this.dataPasienService.pasien.next(this.selectedPasien);
            this.closeDialog();
          }
        }, {
          key: "closeDialog",
          value: function closeDialog() {
            this.dataPasienService.dataPasien.next([]);
            this.dataPasienService.dialog.next(false);
            this.form.reset();
          }
        }]);

        return _DataPasienComponent;
      }();

      _DataPasienComponent.ɵfac = function DataPasienComponent_Factory(t) {
        return new (t || _DataPasienComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_data_pasien_service__WEBPACK_IMPORTED_MODULE_0__.DataPasienService));
      };

      _DataPasienComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
        type: _DataPasienComponent,
        selectors: [["app-data-pasien"]],
        decls: 5,
        vars: 6,
        consts: [[3, "formGroup"], ["responsiveLayout", "scroll", "selectionMode", "single", 3, "value", "selection", "selectionChange", "onRowSelect"], ["pTemplate", "header"], ["pTemplate", "body"], ["pTemplate", "footer"], ["type", "text", "placeholder", "Cari No. RM", "formControlName", "norm", 1, "form-control", 3, "keyup"], ["type", "text", "placeholder", "Cari Nama", "formControlName", "nama", 1, "form-control", 3, "keyup"], ["formControlName", "tglLahir", "mask", "99-99-9999", "placeholder", "Cari Tgl. Lahir", "styleClass", "form-control", 3, "keyup"], ["type", "text", "placeholder", "Cari Alamat", "formControlName", "alamat", 1, "form-control", 3, "keyup"], ["type", "text", "placeholder", "Cari No. Telp", "formControlName", "tlp", 1, "form-control", 3, "keyup"], ["type", "text", "placeholder", "Cari No. Asuransi / BPJS", "formControlName", "noAsuransi", 1, "form-control", 3, "keyup"], [3, "pSelectableRow"], [4, "ngIf"], ["colspan", "6", 1, "tx-light", 2, "text-align", "center"], [1, "bi", "bi-search", "mr-2"]],
        template: function DataPasienComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "form", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "p-table", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("selectionChange", function DataPasienComponent_Template_p_table_selectionChange_1_listener($event) {
              return ctx.selectedPasien = $event;
            })("onRowSelect", function DataPasienComponent_Template_p_table_onRowSelect_1_listener() {
              return ctx.onSelectPasien();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, DataPasienComponent_ng_template_2_Template, 26, 0, "ng-template", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, DataPasienComponent_ng_template_3_Template, 13, 7, "ng-template", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, DataPasienComponent_ng_template_4_Template, 1, 1, "ng-template", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.form);

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](5, _c0));

            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", ctx.dataPasien)("selection", ctx.selectedPasien);
          }
        },
        directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, primeng_table__WEBPACK_IMPORTED_MODULE_3__.Table, primeng_api__WEBPACK_IMPORTED_MODULE_4__.PrimeTemplate, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName, primeng_inputmask__WEBPACK_IMPORTED_MODULE_5__.InputMask, primeng_table__WEBPACK_IMPORTED_MODULE_3__.SelectableRow, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf],
        styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkYXRhLXBhc2llbi5jb21wb25lbnQuY3NzIn0= */"]
      });
      /***/
    },

    /***/
    20744:
    /*!********************************************************************************************!*\
      !*** ./src/app/modules/registrasi/components/data-registrasi/data-registrasi.component.ts ***!
      \********************************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "DataRegistrasiComponent": function DataRegistrasiComponent() {
          return (
            /* binding */
            _DataRegistrasiComponent
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _form_registrasi_form_registrasi_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../form-registrasi/form-registrasi.service */
      38463);
      /* harmony import */


      var src_app_modules_shared_vclaim_vclaim_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! src/app/modules/shared/vclaim/vclaim.service */
      82398);
      /* harmony import */


      var primeng_table__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! primeng/table */
      6536);
      /* harmony import */


      var primeng_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! primeng/api */
      88055);
      /* harmony import */


      var primeng_dialog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! primeng/dialog */
      75657);
      /* harmony import */


      var _form_registrasi_form_registrasi_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../form-registrasi/form-registrasi.component */
      18413);
      /* harmony import */


      var _shared_vclaim_vclaim_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../../../shared/vclaim/vclaim.component */
      90107);

      function DataRegistrasiComponent_ng_template_21_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "No. Antrian");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Tanggal");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6, "Nama");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "No. RM");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10, "Jns. Perawatan");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12, "Ruangan / Poliklinik");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14, "Dokter");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16, "Jenis Tagihan");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "tr");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "th", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](19, "input", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "th", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](21, "input", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](22, "th", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](23, "input", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "th", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](25, "input", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "th", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](27, "input", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "th", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](29, "input", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](30, "th", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](31, "input", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](32, "th", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](33, "input", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        }
      }

      function DataRegistrasiComponent_ng_template_22_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "A1-01");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var item_r2 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r2.tanggal);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r2.nama);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r2.norm);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r2.jnsPerawatan);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r2.ruanganPoli);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r2.dokter);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](item_r2.jnsTagihan);
        }
      }

      var _c0 = function _c0() {
        return {
          width: "75%"
        };
      };

      var _c1 = function _c1() {
        return {
          width: "80vw"
        };
      };

      var _c2 = function _c2() {
        return {
          "960px": "80vw",
          "640px": "100vw"
        };
      };

      var _DataRegistrasiComponent = /*#__PURE__*/function () {
        function _DataRegistrasiComponent(formRegistrasiService, vclaimService) {
          _classCallCheck(this, _DataRegistrasiComponent);

          this.formRegistrasiService = formRegistrasiService;
          this.vclaimService = vclaimService;
          this.dataRegistrasi = [];
          this.dialogFormRegistrasi = false;
          this.dialogVclaim = false;
        }

        _createClass(_DataRegistrasiComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this2 = this;

            this.dataRegistrasi = [{
              tanggal: '12-08-2022',
              nama: 'Fazri Anggriawan',
              norm: '808112',
              jnsPerawatan: 'RAWAT JALAN',
              ruanganPoli: 'POLIKLINIK ANAK',
              dokter: 'dr. Ahmad subagja, Sp.B',
              jnsTagihan: 'BPJS'
            }, {
              tanggal: '12-08-2022',
              nama: 'Fazri Anggriawan',
              norm: '808112',
              jnsPerawatan: 'RAWAT JALAN',
              ruanganPoli: 'POLIKLINIK ANAK',
              dokter: 'dr. Ahmad subagja, Sp.B',
              jnsTagihan: 'BPJS'
            }, {
              tanggal: '12-08-2022',
              nama: 'Fazri Anggriawan',
              norm: '808112',
              jnsPerawatan: 'RAWAT JALAN',
              ruanganPoli: 'POLIKLINIK ANAK',
              dokter: 'dr. Ahmad subagja, Sp.B',
              jnsTagihan: 'BPJS'
            }, {
              tanggal: '12-08-2022',
              nama: 'Fazri Anggriawan',
              norm: '808112',
              jnsPerawatan: 'RAWAT JALAN',
              ruanganPoli: 'POLIKLINIK ANAK',
              dokter: 'dr. Ahmad subagja, Sp.B',
              jnsTagihan: 'BPJS'
            }, {
              tanggal: '12-08-2022',
              nama: 'Fazri Anggriawan',
              norm: '808112',
              jnsPerawatan: 'RAWAT JALAN',
              ruanganPoli: 'POLIKLINIK ANAK',
              dokter: 'dr. Ahmad subagja, Sp.B',
              jnsTagihan: 'BPJS'
            }];
            this.formRegistrasiService.dialog.subscribe(function (data) {
              return _this2.dialogFormRegistrasi = data;
            });
            this.vclaimService.dialog.subscribe(function (data) {
              return _this2.dialogVclaim = data;
            });
          }
        }]);

        return _DataRegistrasiComponent;
      }();

      _DataRegistrasiComponent.ɵfac = function DataRegistrasiComponent_Factory(t) {
        return new (t || _DataRegistrasiComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_form_registrasi_form_registrasi_service__WEBPACK_IMPORTED_MODULE_0__.FormRegistrasiService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_modules_shared_vclaim_vclaim_service__WEBPACK_IMPORTED_MODULE_1__.VclaimService));
      };

      _DataRegistrasiComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
        type: _DataRegistrasiComponent,
        selectors: [["app-data-registrasi"]],
        decls: 27,
        vars: 15,
        consts: [[1, "row", "p-2", "sticky-top", "caption-title"], [1, "col-auto", "border-right"], [1, "col"], [1, "btn", "btn-sm", "p-1", "pl-2", "pr-2", "btn-secondary", "mr-1", 3, "click"], [1, "bi", "bi-plus-lg", "mr-1"], [1, "bi", "bi-credit-card", "mr-1"], [1, "btn", "btn-sm", "p-1", "pl-2", "pr-2", "btn-secondary", "mr-1"], [1, "bi", "bi-printer", "mr-1"], [1, "bi", "bi-chevron-down", "ml-2"], [1, "bi", "bi-arrow-repeat", "mr-1"], [1, "row", "mt-3"], ["styleClass", "p-datatable-sm table-striped table-hover border-top mb-3", "responsiveLayout", "scroll", 3, "value"], ["pTemplate", "header"], ["pTemplate", "body"], ["header", "Form Registrasi", 3, "visible", "modal", "draggable", "visibleChange", "onHide"], ["header", "Bridging VClaim BPJS", "appendTo", "body", 3, "visible", "modal", "draggable", "breakpoints", "visibleChange", "onHide"], [1, "bg-white"], ["type", "text", 1, "form-control"]],
        template: function DataRegistrasiComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "h5");

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Data Registrasi");

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "button", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function DataRegistrasiComponent_Template_button_click_5_listener() {
              return ctx.formRegistrasiService.openDialog();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "i", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, " Registrasi Baru");

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "button", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function DataRegistrasiComponent_Template_button_click_8_listener() {
              return ctx.vclaimService.openDialog();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "i", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10, " Vclaim BPJS");

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "button", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](12, "i", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, " Print ");

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](14, "i", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "button", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](16, "i", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17, " Refresh");

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "div", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "p-table", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](21, DataRegistrasiComponent_ng_template_21_Template, 34, 0, "ng-template", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](22, DataRegistrasiComponent_ng_template_22_Template, 17, 7, "ng-template", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](23, "p-dialog", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("visibleChange", function DataRegistrasiComponent_Template_p_dialog_visibleChange_23_listener($event) {
              return ctx.dialogFormRegistrasi = $event;
            })("onHide", function DataRegistrasiComponent_Template_p_dialog_onHide_23_listener() {
              return ctx.formRegistrasiService.closeDialog();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](24, "app-form-registrasi");

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](25, "p-dialog", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("visibleChange", function DataRegistrasiComponent_Template_p_dialog_visibleChange_25_listener($event) {
              return ctx.dialogVclaim = $event;
            })("onHide", function DataRegistrasiComponent_Template_p_dialog_onHide_25_listener() {
              return ctx.vclaimService.closeDialog();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](26, "app-vclaim");

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](20);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", ctx.dataRegistrasi);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](12, _c0));

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("visible", ctx.dialogFormRegistrasi)("modal", true)("draggable", true);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](13, _c1));

            _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("visible", ctx.dialogVclaim)("modal", true)("draggable", true)("breakpoints", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](14, _c2));
          }
        },
        directives: [primeng_table__WEBPACK_IMPORTED_MODULE_5__.Table, primeng_api__WEBPACK_IMPORTED_MODULE_6__.PrimeTemplate, primeng_dialog__WEBPACK_IMPORTED_MODULE_7__.Dialog, _form_registrasi_form_registrasi_component__WEBPACK_IMPORTED_MODULE_2__.FormRegistrasiComponent, _shared_vclaim_vclaim_component__WEBPACK_IMPORTED_MODULE_3__.VclaimComponent],
        styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkYXRhLXJlZ2lzdHJhc2kuY29tcG9uZW50LmNzcyJ9 */"]
      });
      /***/
    },

    /***/
    48457:
    /*!**********************************************************************************************!*\
      !*** ./src/app/modules/registrasi/components/form-rawat-jalan/form-rawat-jalan.component.ts ***!
      \**********************************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "FormRawatJalanComponent": function FormRawatJalanComponent() {
          return (
            /* binding */
            _FormRawatJalanComponent
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      1707);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _services_master_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../../services/master.service */
      54667);
      /* harmony import */


      var _data_pasien_data_pasien_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../data-pasien/data-pasien.service */
      95819);
      /* harmony import */


      var src_app_modules_shared_vclaim_vclaim_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! src/app/modules/shared/vclaim/vclaim.service */
      82398);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/common */
      54364);
      /* harmony import */


      var primeng_calendar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! primeng/calendar */
      11454);
      /* harmony import */


      var primeng_dropdown__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! primeng/dropdown */
      14170);

      function FormRawatJalanComponent_span_6_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "span", 27);
        }
      }

      function FormRawatJalanComponent_span_12_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "span", 27);
        }
      }

      function FormRawatJalanComponent_span_18_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "span", 27);
        }
      }

      function FormRawatJalanComponent_span_29_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "span", 27);
        }
      }

      function FormRawatJalanComponent_span_35_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "span", 27);
        }
      }

      function FormRawatJalanComponent_span_48_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "span", 27);
        }
      }

      function FormRawatJalanComponent_span_59_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "span", 27);
        }
      }

      function FormRawatJalanComponent_span_65_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "span", 27);
        }
      }

      function FormRawatJalanComponent_span_71_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "span", 27);
        }
      }

      var _c0 = function _c0() {
        return {
          width: "100%"
        };
      };

      var _FormRawatJalanComponent = /*#__PURE__*/function () {
        function _FormRawatJalanComponent(fb, masterService, dataPasienService, vclaimService) {
          _classCallCheck(this, _FormRawatJalanComponent);

          this.fb = fb;
          this.masterService = masterService;
          this.dataPasienService = dataPasienService;
          this.vclaimService = vclaimService;
          this.rs = [];
          this.results = [];
          this.dialogVclaim = false;
          this.pasien = {};
        }

        _createClass(_FormRawatJalanComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this3 = this;

            this.initForm();
            this.masterService.rs.subscribe(function (data) {
              return _this3.rs = data;
            });
            this.dataPasienService.pasien.subscribe(function (data) {
              return _this3.setToForm(data);
            });
          }
        }, {
          key: "setToForm",
          value: function setToForm(pasien) {
            var _a, _b, _c, _d, _e, _f, _g;

            if (pasien) {
              var tanggal = new Date();
              (_a = this.formRawatJalan.get('tanggal')) === null || _a === void 0 ? void 0 : _a.patchValue(tanggal);
              (_b = this.formRawatJalan.get('nama')) === null || _b === void 0 ? void 0 : _b.patchValue(pasien.nama);
              (_c = this.formRawatJalan.get('norm')) === null || _c === void 0 ? void 0 : _c.patchValue(pasien.norm);
              (_d = this.formRawatJalan.get('rs')) === null || _d === void 0 ? void 0 : _d.patchValue(pasien.rs);
              (_e = this.formRawatJalan.get('noAsuransi')) === null || _e === void 0 ? void 0 : _e.patchValue(pasien.no_asuransi);
              (_f = this.formRawatJalan.get('nik')) === null || _f === void 0 ? void 0 : _f.patchValue(pasien.nik);
              (_g = this.formRawatJalan.get('tglLahir')) === null || _g === void 0 ? void 0 : _g.patchValue(pasien.tgl_lahir);
            }
          }
        }, {
          key: "initForm",
          value: function initForm() {
            this.formRawatJalan = this.fb.group({
              tanggal: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              rs: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              norm: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              id_pasien: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              noAsuransi: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              nik: [''],
              nama: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              tglLahir: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              noSep: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              poliklinik: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              dokter: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              jnsPembayaran: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              catatan: [''],
              noreg: [''],
              status: ['']
            });
          }
        }]);

        return _FormRawatJalanComponent;
      }();

      _FormRawatJalanComponent.ɵfac = function FormRawatJalanComponent_Factory(t) {
        return new (t || _FormRawatJalanComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_master_service__WEBPACK_IMPORTED_MODULE_0__.MasterService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_data_pasien_data_pasien_service__WEBPACK_IMPORTED_MODULE_1__.DataPasienService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_modules_shared_vclaim_vclaim_service__WEBPACK_IMPORTED_MODULE_2__.VclaimService));
      };

      _FormRawatJalanComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
        type: _FormRawatJalanComponent,
        selectors: [["app-form-rawat-jalan"]],
        decls: 97,
        vars: 29,
        consts: [[1, "row"], [1, "col"], [3, "formGroup"], [1, "row", "mb-2"], [1, "col-5", "col-form-label"], ["class", "bi bi-exclamation-circle-fill tx-danger ml-1 tx-13", 4, "ngIf"], ["appendTo", "body", "formControlName", "tanggal", 3, "showIcon"], ["optionLabel", "name", "optionValue", "id", "formControlName", "rs", 3, "options", "autoDisplayFirst"], ["type", "text", "formControlName", "nama", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "tglLahir", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "norm", 1, "form-control"], ["type", "text", "formControlName", "noAsuransi", 1, "form-control"], ["type", "text", "formControlName", "nik", 1, "form-control"], [1, "input-group"], ["type", "text", "formControlName", "noSep", 1, "form-control"], [1, "input-group-append"], [1, "btn", "btn-sm", "btn-secondary", 3, "click"], [1, "bi", "bi-credit-card", "mr-1"], ["optionLabel", "name", "formControlName", "poliklinik", 3, "options"], ["optionLabel", "name", "formControlName", "dokter", 3, "options"], ["optionLabel", "name", "formControlName", "jnsPembayaran", 3, "options"], ["type", "text", "formControlName", "catatan", "formControlName", "catatan", 1, "form-control"], ["type", "text", "formControlName", "noreg", "formControlName", "noreg", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "status", "formControlName", "status", "readonly", "", 1, "form-control"], [1, "col", "bg-gray-500", "p-3", "mt-3", "tx-right"], [1, "btn", "btn-sm", "btn-primary", "mr-1"], [1, "bi", "bi-save", "mr-1"], [1, "bi", "bi-exclamation-circle-fill", "tx-danger", "ml-1", "tx-13"]],
        template: function FormRawatJalanComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "form", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5, " Tanggal ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](6, FormRawatJalanComponent_span_6_Template, 1, 0, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](8, "p-calendar", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](11, " RS ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](12, FormRawatJalanComponent_span_12_Template, 1, 0, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](13, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](14, "p-dropdown", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](17, " Nama ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](18, FormRawatJalanComponent_span_18_Template, 1, 0, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](19, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](20, "input", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](21, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](22, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](23, " Tgl. Lahir & Usia ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](24, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](25, "input", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](26, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](27, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](28, " No. RM ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](29, FormRawatJalanComponent_span_29_Template, 1, 0, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](30, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](31, "input", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](32, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](33, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](34, " No. Kartu BPJS / Asuransi ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](35, FormRawatJalanComponent_span_35_Template, 1, 0, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](36, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](37, "input", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](38, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](39, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](40, " NIK ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](41, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](42, "input", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](43, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](44, "form", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](45, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](46, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](47, " No. SEP ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](48, FormRawatJalanComponent_span_48_Template, 1, 0, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](49, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](50, "div", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](51, "input", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](52, "div", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](53, "button", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function FormRawatJalanComponent_Template_button_click_53_listener() {
              return ctx.vclaimService.openDialog();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](54, "i", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](55, " Vclaim BPJS");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](56, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](57, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](58, " Poliklinik ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](59, FormRawatJalanComponent_span_59_Template, 1, 0, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](60, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](61, "p-dropdown", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](62, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](63, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](64, " Dokter ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](65, FormRawatJalanComponent_span_65_Template, 1, 0, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](66, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](67, "p-dropdown", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](68, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](69, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](70, " Jenis Pembayaran ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](71, FormRawatJalanComponent_span_71_Template, 1, 0, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](72, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](73, "p-dropdown", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](74, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](75, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](76, " Catatan ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](77, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](78, "input", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](79, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](80, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](81, " No. Registrasi ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](82, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](83, "input", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](84, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](85, "label", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](86, " Status ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](87, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](88, "input", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](89, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](90, "div", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](91, "button", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](92, "i", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](93, " Simpan");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](94, "button", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](95, "i", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](96, " Update");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            var tmp_1_0;
            var tmp_3_0;
            var tmp_7_0;
            var tmp_8_0;
            var tmp_9_0;
            var tmp_11_0;
            var tmp_12_0;
            var tmp_15_0;
            var tmp_18_0;

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.formRawatJalan);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (tmp_1_0 = ctx.formRawatJalan.get("tanggal")) == null ? null : tmp_1_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("showIcon", true);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (tmp_3_0 = ctx.formRawatJalan.get("rs")) == null ? null : tmp_3_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](25, _c0));

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("options", ctx.rs)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (tmp_7_0 = ctx.formRawatJalan.get("nama")) == null ? null : tmp_7_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](11);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (tmp_8_0 = ctx.formRawatJalan.get("norm")) == null ? null : tmp_8_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (tmp_9_0 = ctx.formRawatJalan.get("noAsuransi")) == null ? null : tmp_9_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](9);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.formRawatJalan);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (tmp_11_0 = ctx.formRawatJalan.get("nama")) == null ? null : tmp_11_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](11);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (tmp_12_0 = ctx.formRawatJalan.get("poliklinik")) == null ? null : tmp_12_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](26, _c0));

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("options", ctx.results);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (tmp_15_0 = ctx.formRawatJalan.get("dokter")) == null ? null : tmp_15_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](27, _c0));

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("options", ctx.results);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (tmp_18_0 = ctx.formRawatJalan.get("jnsPembayaran")) == null ? null : tmp_18_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](28, _c0));

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("options", ctx.results);
          }
        },
        directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, primeng_calendar__WEBPACK_IMPORTED_MODULE_6__.Calendar, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName, primeng_dropdown__WEBPACK_IMPORTED_MODULE_7__.Dropdown, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor],
        styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb3JtLXJhd2F0LWphbGFuLmNvbXBvbmVudC5jc3MifQ== */"]
      });
      /***/
    },

    /***/
    18413:
    /*!********************************************************************************************!*\
      !*** ./src/app/modules/registrasi/components/form-registrasi/form-registrasi.component.ts ***!
      \********************************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "FormRegistrasiComponent": function FormRegistrasiComponent() {
          return (
            /* binding */
            _FormRegistrasiComponent
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var src_app_modules_shared_vclaim_vclaim_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! src/app/modules/shared/vclaim/vclaim.service */
      82398);
      /* harmony import */


      var _data_pasien_data_pasien_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../data-pasien/data-pasien.service */
      95819);
      /* harmony import */


      var primeng_table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! primeng/table */
      6536);
      /* harmony import */


      var primeng_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! primeng/api */
      88055);
      /* harmony import */


      var primeng_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! primeng/dialog */
      75657);
      /* harmony import */


      var _data_pasien_data_pasien_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../data-pasien/data-pasien.component */
      81016);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/common */
      54364);

      function FormRegistrasiComponent_ng_template_82_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "tr");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2, "Jns. Perawatan");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, "Ruangan / Poliklinik");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6, "Tanggal Masuk");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](8, "Tanggal Pulang");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10, "Dokter / DPJP");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        }
      }

      function FormRegistrasiComponent_ng_template_83_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "tr");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](8);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var item_r2 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](item_r2.jnsPerawatan);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](item_r2.ruanganPoli);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](item_r2.tanggal);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](item_r2.tanggal);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](item_r2.dokter);
        }
      }

      var _c0 = function _c0() {
        return {
          width: "75%"
        };
      };

      var _FormRegistrasiComponent = /*#__PURE__*/function () {
        function _FormRegistrasiComponent(vclaimService, dataPasienService) {
          _classCallCheck(this, _FormRegistrasiComponent);

          this.vclaimService = vclaimService;
          this.dataPasienService = dataPasienService;
          this.dialogDataPasien = false;
        }

        _createClass(_FormRegistrasiComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this4 = this;

            this.dataRegistrasi = [{
              tanggal: '12-08-2022',
              nama: 'Fazri Anggriawan',
              norm: '808112',
              jnsPerawatan: 'RAWAT JALAN',
              ruanganPoli: 'POLIKLINIK ANAK',
              dokter: 'dr. Ahmad subagja, Sp.B',
              jnsTagihan: 'BPJS'
            }, {
              tanggal: '12-08-2022',
              nama: 'Fazri Anggriawan',
              norm: '808112',
              jnsPerawatan: 'RAWAT JALAN',
              ruanganPoli: 'POLIKLINIK ANAK',
              dokter: 'dr. Ahmad subagja, Sp.B',
              jnsTagihan: 'BPJS'
            }, {
              tanggal: '12-08-2022',
              nama: 'Fazri Anggriawan',
              norm: '808112',
              jnsPerawatan: 'RAWAT JALAN',
              ruanganPoli: 'POLIKLINIK ANAK',
              dokter: 'dr. Ahmad subagja, Sp.B',
              jnsTagihan: 'BPJS'
            }, {
              tanggal: '12-08-2022',
              nama: 'Fazri Anggriawan',
              norm: '808112',
              jnsPerawatan: 'RAWAT JALAN',
              ruanganPoli: 'POLIKLINIK ANAK',
              dokter: 'dr. Ahmad subagja, Sp.B',
              jnsTagihan: 'BPJS'
            }, {
              tanggal: '12-08-2022',
              nama: 'Fazri Anggriawan',
              norm: '808112',
              jnsPerawatan: 'RAWAT JALAN',
              ruanganPoli: 'POLIKLINIK ANAK',
              dokter: 'dr. Ahmad subagja, Sp.B',
              jnsTagihan: 'BPJS'
            }];
            this.dataPasienService.dialog.subscribe(function (data) {
              return _this4.dialogDataPasien = data;
            });
            this.dataPasienService.pasien.subscribe(function (data) {
              return _this4.handleDataPasien(data);
            });
          }
        }, {
          key: "handleDataPasien",
          value: function handleDataPasien(data) {
            this.pasien = data;
          }
        }, {
          key: "showDialog",
          value: function showDialog() {
            alert('show dialog');
          }
        }]);

        return _FormRegistrasiComponent;
      }();

      _FormRegistrasiComponent.ɵfac = function FormRegistrasiComponent_Factory(t) {
        return new (t || _FormRegistrasiComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_modules_shared_vclaim_vclaim_service__WEBPACK_IMPORTED_MODULE_0__.VclaimService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_data_pasien_data_pasien_service__WEBPACK_IMPORTED_MODULE_1__.DataPasienService));
      };

      _FormRegistrasiComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
        type: _FormRegistrasiComponent,
        selectors: [["app-form-registrasi"]],
        decls: 138,
        vars: 14,
        consts: [[1, "row", "m-0", "pb-2", "border-bottom", "sticky-top"], [1, "col", "pl-0"], [1, "btn", "btn-secondary", "btn-sm", "mr-1", 3, "click"], [1, "bi", "bi-search", "mr-1"], [1, "bi", "bi-credit-card", "mr-1"], [1, "btn", "btn-primary", "btn-sm", "mr-1"], [1, "bi", "bi-save", "mr-1"], [1, "row", "mt-2"], [1, "col"], [1, "row"], [1, "col-auto"], [1, "bg-light", "p-3", "rounded", "border", "tx-center", "tx-gray-500", "mb-2"], [1, "bi", "bi-person-bounding-box", 2, "font-size", "4rem"], [1, "btn", "btn-xs", "btn-outline-light", "btn-block", "mt-1"], [1, "bi", "bi-camera", "mr-1"], [1, "bi", "bi-pencil", "mr-1"], [1, "row", "mb-1"], [1, "col-4", "col-form-label"], [1, "input-group"], ["type", "text", 1, "form-control", 3, "value"], [1, "input-group-append"], [1, "btn", "btn-secondary"], [1, "bi", "bi-search"], ["type", "text", "value", "", 1, "form-control"], ["styleClass", "p-datatable-sm table-striped table-hover border-top mb-3", "responsiveLayout", "scroll", 3, "value"], ["pTemplate", "header"], ["pTemplate", "body"], ["type", "text", "value", "OPEN", 1, "form-control"], ["type", "text", "value", "RJ220902000001", 1, "form-control"], ["type", "text", "value", "22-02-2022", 1, "form-control"], [1, "btn", "btn-secondary", 3, "click"], [1, "bi", "bi-plus-lg"], ["type", "text", "value", "RAWAT JALAN - KONTROL KEMBALI", 1, "form-control"], ["type", "text", "value", "POLIKLINIK ANAK", 1, "form-control"], ["type", "text", "value", "dr. Bambang Budiarto Sp.B", 1, "form-control"], ["type", "text", "value", "BPJS Kesehatan", 1, "form-control"], ["header", "Cari Data Pasien", "appendTo", "body", 3, "visible", "modal", "draggable", "visibleChange", "onHide"]],
        template: function FormRegistrasiComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "button", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function FormRegistrasiComponent_Template_button_click_2_listener() {
              return ctx.dataPasienService.openDialog();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "i", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, " Cari Pasien");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "button", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function FormRegistrasiComponent_Template_button_click_5_listener() {
              return ctx.vclaimService.openDialog();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](6, "i", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7, " VClaim BPJS");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "button", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](9, "i", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10, " Simpan");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "div", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "div", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](13, "h4");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](14, "Data Pasien");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "div", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](17, "div", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](18, "div", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](19, "button", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](20, "i", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](21, " Ambil Photo");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](22, "button", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](23, "i", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](24, " Edit Pasien");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](25, "div", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](26, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](27, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](28, "Nama");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](29, "div", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](30, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](31, "input", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](32, "uppercase");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](33, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](34, "button", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](35, "i", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](36, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](37, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](38, "No. RM");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](39, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](40, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](41, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](42, "input", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](43, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](44, "button", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](45, "i", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](46, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](47, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](48, "No. Asuransi / BPJS");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](49, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](50, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](51, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](52, "input", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](53, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](54, "button", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](55, "i", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](56, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](57, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](58, "No. Tlp");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](59, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](60, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](61, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](62, "input", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](63, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](64, "button", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](65, "i", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](66, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](67, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](68, "Jns. Kelamin");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](69, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](70, "input", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](71, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](72, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](73, "Usia");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](74, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](75, "input", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](76, "hr");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](77, "h4");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](78, "Riwayat Kunjungan");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](79, "div", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](80, "div", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](81, "p-table", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](82, FormRegistrasiComponent_ng_template_82_Template, 11, 0, "ng-template", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](83, FormRegistrasiComponent_ng_template_83_Template, 11, 5, "ng-template", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](84, "div", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](85, "h4");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](86, "Data Registrasi");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](87, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](88, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](89, "Status");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](90, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](91, "input", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](92, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](93, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](94, "No. Registrasi");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](95, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](96, "input", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](97, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](98, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](99, "Tanggal");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](100, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](101, "input", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](102, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](103, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](104, "No. SEP");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](105, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](106, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](107, "input", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](108, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](109, "button", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function FormRegistrasiComponent_Template_button_click_109_listener() {
              return ctx.vclaimService.openDialog();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](110, "i", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](111, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](112, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](113, "Jns. Kunjungan");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](114, "div", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](115, "input", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](116, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](117, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](118, "Ruangan / Poliklinik");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](119, "div", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](120, "input", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](121, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](122, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](123, "Dokter / DPJP");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](124, "div", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](125, "input", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](126, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](127, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](128, "Jenis Pembayaran");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](129, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](130, "input", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](131, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](132, "label", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](133, "Catatan");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](134, "div", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](135, "input", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](136, "p-dialog", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("visibleChange", function FormRegistrasiComponent_Template_p_dialog_visibleChange_136_listener($event) {
              return ctx.dialogDataPasien = $event;
            })("onHide", function FormRegistrasiComponent_Template_p_dialog_onHide_136_listener() {
              return ctx.dataPasienService.closeDialog();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](137, "app-data-pasien");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](31);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpropertyInterpolate"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](32, 11, ctx.pasien.nama));

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](11);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpropertyInterpolate"]("value", ctx.pasien.norm);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpropertyInterpolate"]("value", ctx.pasien.no_asuransi);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpropertyInterpolate"]("value", ctx.pasien.tlp);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpropertyInterpolate"]("value", ctx.pasien.jns_kelamin);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](11);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("value", ctx.dataRegistrasi);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](55);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](13, _c0));

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("visible", ctx.dialogDataPasien)("modal", true)("draggable", true);
          }
        },
        directives: [primeng_table__WEBPACK_IMPORTED_MODULE_4__.Table, primeng_api__WEBPACK_IMPORTED_MODULE_5__.PrimeTemplate, primeng_dialog__WEBPACK_IMPORTED_MODULE_6__.Dialog, _data_pasien_data_pasien_component__WEBPACK_IMPORTED_MODULE_2__.DataPasienComponent],
        pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.UpperCasePipe],
        styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb3JtLXJlZ2lzdHJhc2kuY29tcG9uZW50LmNzcyJ9 */"]
      });
      /***/
    },

    /***/
    38463:
    /*!******************************************************************************************!*\
      !*** ./src/app/modules/registrasi/components/form-registrasi/form-registrasi.service.ts ***!
      \******************************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "FormRegistrasiService": function FormRegistrasiService() {
          return (
            /* binding */
            _FormRegistrasiService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! rxjs */
      76491);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      2316);

      var _FormRegistrasiService = /*#__PURE__*/function () {
        function _FormRegistrasiService() {
          _classCallCheck(this, _FormRegistrasiService);

          this.dialog = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(false);
        }

        _createClass(_FormRegistrasiService, [{
          key: "openDialog",
          value: function openDialog() {
            this.dialog.next(true);
          }
        }, {
          key: "closeDialog",
          value: function closeDialog() {
            this.dialog.next(false);
          }
        }]);

        return _FormRegistrasiService;
      }();

      _FormRegistrasiService.ɵfac = function FormRegistrasiService_Factory(t) {
        return new (t || _FormRegistrasiService)();
      };

      _FormRegistrasiService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
        token: _FormRegistrasiService,
        factory: _FormRegistrasiService.ɵfac,
        providedIn: 'root'
      });
      /***/
    },

    /***/
    35487:
    /*!*****************************************************************!*\
      !*** ./src/app/modules/registrasi/registrasi-routing.module.ts ***!
      \*****************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "RegistrasiRoutingModule": function RegistrasiRoutingModule() {
          return (
            /* binding */
            _RegistrasiRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      71258);
      /* harmony import */


      var _registrasi_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./registrasi.component */
      7317);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      2316);

      var routes = [{
        path: '',
        component: _registrasi_component__WEBPACK_IMPORTED_MODULE_0__.RegistrasiComponent
      }];

      var _RegistrasiRoutingModule = /*#__PURE__*/_createClass(function _RegistrasiRoutingModule() {
        _classCallCheck(this, _RegistrasiRoutingModule);
      });

      _RegistrasiRoutingModule.ɵfac = function RegistrasiRoutingModule_Factory(t) {
        return new (t || _RegistrasiRoutingModule)();
      };

      _RegistrasiRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
        type: _RegistrasiRoutingModule
      });
      _RegistrasiRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
        imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](_RegistrasiRoutingModule, {
          imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule],
          exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
        });
      })();
      /***/

    },

    /***/
    7317:
    /*!************************************************************!*\
      !*** ./src/app/modules/registrasi/registrasi.component.ts ***!
      \************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "RegistrasiComponent": function RegistrasiComponent() {
          return (
            /* binding */
            _RegistrasiComponent
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/forms */
      1707);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _services_master_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./services/master.service */
      54667);
      /* harmony import */


      var _components_data_pasien_data_pasien_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./components/data-pasien/data-pasien.service */
      95819);
      /* harmony import */


      var _services_registrasi_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./services/registrasi.service */
      92881);
      /* harmony import */


      var _shared_vclaim_vclaim_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../shared/vclaim/vclaim.service */
      82398);
      /* harmony import */


      var primeng_dialog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! primeng/dialog */
      75657);
      /* harmony import */


      var _shared_vclaim_vclaim_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../shared/vclaim/vclaim.component */
      90107);
      /* harmony import */


      var _components_data_pasien_data_pasien_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./components/data-pasien/data-pasien.component */
      81016);
      /* harmony import */


      var _components_form_rawat_jalan_form_rawat_jalan_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./components/form-rawat-jalan/form-rawat-jalan.component */
      48457);
      /* harmony import */


      var primeng_menu__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! primeng/menu */
      63493);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/common */
      54364);
      /* harmony import */


      var primeng_dropdown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! primeng/dropdown */
      14170);
      /* harmony import */


      var primeng_calendar__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! primeng/calendar */
      11454);
      /* harmony import */


      var primeng_radiobutton__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! primeng/radiobutton */
      41751);
      /* harmony import */


      var primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! primeng/inputtextarea */
      90777);

      function RegistrasiComponent_button_30_Template(rf, ctx) {
        if (rf & 1) {
          var _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "button", 95);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function RegistrasiComponent_button_30_Template_button_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r22);

            var ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();

            return ctx_r21.save();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "i", 96);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](2, " Simpan Pasien Baru");

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("disabled", ctx_r1.form.invalid);
        }
      }

      function RegistrasiComponent_button_31_Template(rf, ctx) {
        if (rf & 1) {
          var _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "button", 95);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function RegistrasiComponent_button_31_Template_button_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r24);

            var ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();

            return ctx_r23.update();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "i", 96);

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](2, " Update");

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("disabled", ctx_r2.form.invalid);
        }
      }

      function RegistrasiComponent_span_55_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_71_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_77_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_86_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_92_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_98_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_113_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_119_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_125_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_131_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_157_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_163_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_169_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_175_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_216_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_242_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_248_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      function RegistrasiComponent_span_254_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "span", 97);
        }
      }

      var _c0 = function _c0() {
        return {
          width: "85%"
        };
      };

      var _c1 = function _c1() {
        return {
          width: "75%"
        };
      };

      var _c2 = function _c2() {
        return {
          width: "100%"
        };
      };

      var _RegistrasiComponent = /*#__PURE__*/function () {
        function _RegistrasiComponent(masterService, fb, dataPasienService, registrasiService, vclaimService) {
          _classCallCheck(this, _RegistrasiComponent);

          this.masterService = masterService;
          this.fb = fb;
          this.dataPasienService = dataPasienService;
          this.registrasiService = registrasiService;
          this.vclaimService = vclaimService;
          this.rs = [];
          this.awalanNama = [];
          this.negara = [];
          this.provinsi = [];
          this.kota = [];
          this.kecamatan = [];
          this.kelurahan = [];
          this.suku = [];
          this.statusNikah = [];
          this.agama = [];
          this.pekerjaan = [];
          this.pendidikan = [];
          this.angkatan = [];
          this.pangkat = [];
          this.groupPasien = [];
          this.golonganPasien = [];
          this.dialogVclaim = false;
          this.dialogDataPasien = false;
          this.dialogFormRawatJalan = false;
        }

        _createClass(_RegistrasiComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this5 = this;

            this.initForm();
            this.masterService.rs.subscribe(function (data) {
              return _this5.rs = data;
            });
            this.masterService.awalanNama.subscribe(function (data) {
              return _this5.awalanNama = data;
            });
            this.masterService.negara.subscribe(function (data) {
              return _this5.negara = data;
            });
            this.masterService.provinsi.subscribe(function (data) {
              return _this5.provinsi = data;
            });
            this.masterService.kota.subscribe(function (data) {
              return _this5.kota = data;
            });
            this.masterService.kecamatan.subscribe(function (data) {
              return _this5.kecamatan = data;
            });
            this.masterService.kelurahan.subscribe(function (data) {
              return _this5.kelurahan = data;
            });
            this.masterService.suku.subscribe(function (data) {
              return _this5.suku = data;
            });
            this.masterService.statusNikah.subscribe(function (data) {
              return _this5.statusNikah = data;
            });
            this.masterService.agama.subscribe(function (data) {
              return _this5.agama = data;
            });
            this.masterService.pekerjaan.subscribe(function (data) {
              return _this5.pekerjaan = data;
            });
            this.masterService.pendidikan.subscribe(function (data) {
              return _this5.pendidikan = data;
            });
            this.masterService.angkatan.subscribe(function (data) {
              return _this5.angkatan = data;
            });
            this.masterService.pangkat.subscribe(function (data) {
              return _this5.pangkat = data;
            });
            this.masterService.groupPasien.subscribe(function (data) {
              return _this5.groupPasien = data;
            });
            this.masterService.golonganPasien.subscribe(function (data) {
              return _this5.golonganPasien = data;
            });
            this.dataPasienService.pasien.subscribe(function (data) {
              return _this5.setToForm(data);
            });
            this.dataPasienService.dialog.subscribe(function (data) {
              return _this5.dialogDataPasien = data;
            });
            this.vclaimService.dialog.subscribe(function (data) {
              return _this5.dialogVclaim = data;
            });
            this.menuPendaftaran = [{
              label: 'Rawat Jalan',
              icon: 'bi bi-clipboard-pulse',
              command: function command() {
                _this5.openFormRawatJalan();
              }
            }, {
              label: 'Rawat Inap',
              icon: 'bi bi-hospital'
            }];
          }
        }, {
          key: "openFormRawatJalan",
          value: function openFormRawatJalan() {
            this.dialogFormRawatJalan = true;
          }
        }, {
          key: "getPesertaBpjs",
          value: function getPesertaBpjs() {
            var _a, _b;

            if ((_a = this.form.get('nomorAsuransi')) === null || _a === void 0 ? void 0 : _a.value) {
              this.vclaimService.getPesertaByNomorKartu();
            } else {
              if ((_b = this.form.get('nik')) === null || _b === void 0 ? void 0 : _b.value) {
                this.vclaimService.getPesertaByNik();
              }
            }
          }
        }, {
          key: "handleDataPasien",
          value: function handleDataPasien(data) {
            if (data) {
              this.setToForm(data);
            }
          }
        }, {
          key: "setToForm",
          value: function setToForm(data) {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6;

            if (data) {
              (_a = this.form.get('id')) === null || _a === void 0 ? void 0 : _a.patchValue(data.id);
              (_b = this.form.get('nomorRm')) === null || _b === void 0 ? void 0 : _b.patchValue(data.norm);
              (_c = this.form.get('rs')) === null || _c === void 0 ? void 0 : _c.patchValue(data.rs);
              (_d = this.form.get('awalanNama')) === null || _d === void 0 ? void 0 : _d.patchValue(data.awalan);
              (_e = this.form.get('nama')) === null || _e === void 0 ? void 0 : _e.patchValue(data.nama);
              (_f = this.form.get('tempatLahir')) === null || _f === void 0 ? void 0 : _f.patchValue(data.tmpt_lahir);
              (_g = this.form.get('jnsKelamin')) === null || _g === void 0 ? void 0 : _g.patchValue(data.jns_kelamin);
              (_h = this.form.get('alamat')) === null || _h === void 0 ? void 0 : _h.patchValue(data.alamat);
              (_j = this.form.get('negara')) === null || _j === void 0 ? void 0 : _j.patchValue(data.negara);
              (_k = this.form.get('provinsi')) === null || _k === void 0 ? void 0 : _k.patchValue(data.provinsi);
              (_l = this.form.get('kota')) === null || _l === void 0 ? void 0 : _l.patchValue(data.kota);
              (_m = this.form.get('kecamatan')) === null || _m === void 0 ? void 0 : _m.patchValue(data.kecamatan);
              (_o = this.form.get('kelurahan')) === null || _o === void 0 ? void 0 : _o.patchValue(data.kelurahan);
              (_p = this.form.get('suku')) === null || _p === void 0 ? void 0 : _p.patchValue(data.suku);
              (_q = this.form.get('statusNikah')) === null || _q === void 0 ? void 0 : _q.patchValue(data.status_nikah);
              (_r = this.form.get('agama')) === null || _r === void 0 ? void 0 : _r.patchValue(data.agama);
              (_s = this.form.get('tlpPasien')) === null || _s === void 0 ? void 0 : _s.patchValue(data.tlp);
              (_t = this.form.get('tlpKeluarga')) === null || _t === void 0 ? void 0 : _t.patchValue(data.tlp_keluarga);
              (_u = this.form.get('pekerjaan')) === null || _u === void 0 ? void 0 : _u.patchValue(data.pekerjaan);
              (_v = this.form.get('pendidikan')) === null || _v === void 0 ? void 0 : _v.patchValue(data.pendidikan);
              (_w = this.form.get('golonganDarah')) === null || _w === void 0 ? void 0 : _w.patchValue(data.gol_darah);
              (_x = this.form.get('nik')) === null || _x === void 0 ? void 0 : _x.patchValue(data.nik);
              (_y = this.form.get('nrpNip')) === null || _y === void 0 ? void 0 : _y.patchValue(data.nrp_nip);
              (_z = this.form.get('angkatan')) === null || _z === void 0 ? void 0 : _z.patchValue(data.angkatan);
              (_0 = this.form.get('pangkat')) === null || _0 === void 0 ? void 0 : _0.patchValue(data.pangkat);
              (_1 = this.form.get('kesatuan')) === null || _1 === void 0 ? void 0 : _1.patchValue(data.kesatuan);
              (_2 = this.form.get('jabatan')) === null || _2 === void 0 ? void 0 : _2.patchValue(data.jabatan);
              (_3 = this.form.get('groupPasien')) === null || _3 === void 0 ? void 0 : _3.patchValue(data.group_pasien);
              (_4 = this.form.get('golonganPasien')) === null || _4 === void 0 ? void 0 : _4.patchValue(data.gol_pasien);
              (_5 = this.form.get('nomorAsuransi')) === null || _5 === void 0 ? void 0 : _5.patchValue(data.no_asuransi);

              if (data.tgl_lahir) {
                var tglLahir = new Date(data.tgl_lahir);
                (_6 = this.form.get('tglLahir')) === null || _6 === void 0 ? void 0 : _6.patchValue(tglLahir);
              }
            }
          }
        }, {
          key: "handleDataPeserta",
          value: function handleDataPeserta(data) {
            var _a, _b, _c, _d, _e, _f;

            if (data) {
              var peserta = this.dataPesertaBpjs.response.peserta;
              (_a = this.form.get('nama')) === null || _a === void 0 ? void 0 : _a.patchValue(peserta.nama);
              (_b = this.form.get('nomorAsuransi')) === null || _b === void 0 ? void 0 : _b.patchValue(peserta.noKartu);
              (_c = this.form.get('nik')) === null || _c === void 0 ? void 0 : _c.patchValue(peserta.nik);
              (_d = this.form.get('jnsKelamin')) === null || _d === void 0 ? void 0 : _d.patchValue(peserta.sex);
              if (peserta.sex == 'L') (_e = this.form.get('awalanNama')) === null || _e === void 0 ? void 0 : _e.patchValue(1);
              if (peserta.sex == 'P') (_f = this.form.get('awalanNama')) === null || _f === void 0 ? void 0 : _f.patchValue(2);
            }
          }
        }, {
          key: "initForm",
          value: function initForm() {
            this.form = this.fb.group({
              id: [''],
              nomorRm: [''],
              rs: [1, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              awalanNama: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              nama: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              tempatLahir: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              tglLahir: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              jnsKelamin: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              alamat: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              negara: [101, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              provinsi: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              kota: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              kecamatan: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              kelurahan: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              suku: [''],
              statusNikah: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              agama: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              tlpPasien: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              tlpKeluarga: [''],
              pekerjaan: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              pendidikan: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              golonganDarah: [''],
              nik: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              nrpNip: [''],
              angkatan: [''],
              pangkat: [''],
              kesatuan: [''],
              jabatan: [''],
              groupPasien: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              golonganPasien: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
              nomorAsuransi: ['']
            });
          }
        }, {
          key: "getKota",
          value: function getKota(provinsi) {
            this.masterService.getKota(provinsi);
          }
        }, {
          key: "getKecamatan",
          value: function getKecamatan(kota) {
            this.masterService.getKecamatan(kota);
          }
        }, {
          key: "getKelurahan",
          value: function getKelurahan(kecamatan) {
            this.masterService.getKelurahan(kecamatan);
          }
        }, {
          key: "getGolonganPasien",
          value: function getGolonganPasien(groupPasien) {
            this.masterService.getGolonganPasien(groupPasien);
          }
        }, {
          key: "save",
          value: function save() {}
        }, {
          key: "update",
          value: function update() {
            var _a;

            var tglLahir = this.reformatDate((_a = this.form.get('tglLahir')) === null || _a === void 0 ? void 0 : _a.value); // this.form.get('tglLahir')?.patchValue(tglLahir);

            this.form.value.tglLahir = tglLahir;
            this.registrasiService.updatePasien(this.form.value);
          }
        }, {
          key: "reformatDate",
          value: function reformatDate(date) {
            return date.toISOString().substr(0, 10);
          }
        }]);

        return _RegistrasiComponent;
      }();

      _RegistrasiComponent.ɵfac = function RegistrasiComponent_Factory(t) {
        return new (t || _RegistrasiComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_services_master_service__WEBPACK_IMPORTED_MODULE_0__.MasterService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_components_data_pasien_data_pasien_service__WEBPACK_IMPORTED_MODULE_1__.DataPasienService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_services_registrasi_service__WEBPACK_IMPORTED_MODULE_2__.RegistrasiService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_shared_vclaim_vclaim_service__WEBPACK_IMPORTED_MODULE_3__.VclaimService));
      };

      _RegistrasiComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
        type: _RegistrasiComponent,
        selectors: [["app-registrasi"]],
        decls: 257,
        vars: 130,
        consts: [["header", "Bridging VClaim BPJS", 3, "visible", "modal", "draggable", "visibleChange", "onHide", "onShow"], ["header", "Cari Data Pasien", 3, "visible", "modal", "draggable", "visibleChange", "onHide"], ["header", "Form Rawat Jalan", 3, "visible", "modal", "draggable", "visibleChange"], [1, "row", "p-3", 2, "margin-left", "-14px", "margin-right", "-14px"], [1, "col", "p-3", "bg-gray-500", "mb-3", "sticky-top", 2, "top", "60px"], [1, "row"], [1, "col-auto", "border-right", "border-light"], [1, "btn", "btn-sm", "btn-secondary", "mr-1", 3, "click"], [1, "bi", "bi-search", "mr-1"], [1, "bi", "bi-plus-lg", "mr-1"], [1, "bi", "bi-chevron-down", "ml-2"], ["appendTo", "body", "appendTo", "body", 3, "popup", "model"], ["submenuPendaftaran", ""], [1, "btn", "btn-sm", "btn-secondary", "mr-1"], [1, "bi", "bi-printer", "mr-1"], [1, "bi", "bi-credit-card", "mr-1"], [1, "bi", "bi-arrow-repeat", "mr-1"], [1, "col-auto"], ["class", "btn btn-sm btn-primary", 3, "disabled", "click", 4, "ngIf"], [1, "col", "tx-right"], [1, "bi", "bi-trash", "mr-1"], [1, "w-100"], [1, "col"], ["name", "form", 3, "formGroup"], [1, "bg-light", "p-3", "rounded", "border", "tx-center", "tx-gray-500"], [1, "bi", "bi-person-bounding-box", 2, "font-size", "4rem"], [1, "btn", "btn-xs", "btn-light", "btn-block", "mt-2"], [1, "bi", "bi-camera", "mr-1"], [1, "row", "mb-2", 2, "display", "none"], [1, "col-4", "col-form-label"], ["type", "text", "formControlName", "id", "readonly", "readonly"], [1, "row", "mb-2"], ["class", "bi bi-exclamation-circle-fill tx-danger ml-1 tx-13", 4, "ngIf"], ["formControlName", "rs", "optionValue", "id", "optionLabel", "name", 3, "options", "autoDisplayFirst"], ["type", "text", "formControlName", "nomorRm", "placeholder", "Cari...", 1, "form-control"], ["for", "noAsuransi", 1, "col-4", "col-form-label"], ["type", "text", "formControlName", "nomorAsuransi", "placeholder", "Cari...", 1, "form-control"], ["for", "nik", 1, "col-4", "col-form-label"], ["type", "text", "formControlName", "nik", 1, "form-control"], ["for", "nama", 1, "col-4", "col-form-label"], [1, "input-group"], [1, "input-group-prepend"], ["formControlName", "awalanNama", "optionValue", "id", "optionLabel", "ket", 3, "options", "autoDisplayFirst"], ["type", "text", "formControlName", "nama", 1, "form-control"], ["for", "tmptLahir", 1, "col-4", "col-form-label"], ["type", "text", "formControlName", "tempatLahir", 1, "form-control"], ["for", "tglLahir", 1, "col-4", "col-form-label"], ["formControlName", "tglLahir", "dateFormat", "dd-mm-yy", 3, "showIcon"], ["for", "jnsKelamin", 1, "col-4", "col-form-label"], [1, "col", "pt-2"], ["name", "jnsKelamin", "value", "L", "formControlName", "jnsKelamin"], ["name", "jnsKelamin", "value", "P", "formControlName", "jnsKelamin", 1, "ml-3"], ["for", "alamat", 1, "col-4", "col-form-label"], ["pInputTextarea", "", "formControlName", "alamat", 3, "autoResize"], ["for", "notlp", 1, "col-4", "col-form-label"], ["type", "text", "formControlName", "tlpPasien", 1, "form-control"], ["for", "provinsi", 1, "col-4", "col-form-label"], ["formControlName", "negara", "optionValue", "id", "optionLabel", "name", 3, "options", "filter", "autoDisplayFirst"], [1, "col-8"], ["formControlName", "provinsi", "optionValue", "id", "optionLabel", "name", 3, "options", "filter", "autoDisplayFirst", "ngModelChange"], ["for", "kota", 1, "col-4", "col-form-label"], ["ng-show", "form1.kota.$error.required", 1, "fontello-icon-attention-circle", "error"], ["formControlName", "kota", "optionValue", "id", "optionLabel", "name", 3, "options", "filter", "autoDisplayFirst", "ngModelChange"], ["for", "kecamatan", 1, "col-4", "col-form-label"], ["ng-show", "form1.kecamatan.$error.required", 1, "fontello-icon-attention-circle", "error"], ["formControlName", "kecamatan", "optionValue", "id", "optionLabel", "name", 3, "options", "filter", "autoDisplayFirst", "ngModelChange"], ["for", "kelurahan", 1, "col-4", "col-form-label"], ["ng-show", "form1.kelurahan.$error.required", 1, "fontello-icon-attention-circle", "error"], ["formControlName", "kelurahan", "optionValue", "id", "optionLabel", "name", 3, "options", "filter", "autoDisplayFirst"], [3, "formGroup"], ["for", "statusKawin", 1, "col-4", "col-form-label"], ["formControlName", "statusNikah", "optionValue", "statusNikahID", "optionLabel", "name", 3, "options", "autoDisplayFirst"], ["for", "agama", 1, "col-4", "col-form-label"], ["formControlName", "agama", "optionValue", "agamaID", "optionLabel", "name", 3, "options", "autoDisplayFirst"], ["for", "pekerjaan", 1, "col-4", "col-form-label"], ["formControlName", "pekerjaan", "optionValue", "pekerjaanid", "optionLabel", "name", 3, "options", "autoDisplayFirst"], ["for", "pendidikan", 1, "col-4", "col-form-label"], ["formControlName", "pendidikan", "optionValue", "pendidikanID", "optionLabel", "name", 3, "options", "autoDisplayFirst"], ["for", "goldar", 1, "col-4", "col-form-label"], ["type", "text", "formControlName", "golonganDarah", "maxlength", "3", 1, "form-control"], ["for", "suku", 1, "col-4", "col-form-label"], ["type", "text", 1, "form-control"], ["formControlName", "suku", "optionValue", "id", "optionLabel", "name", 3, "options", "filter", "autoDisplayFirst"], ["for", "nrp", 1, "col-4", "col-form-label"], ["type", "text", "formControlName", "nrpNip", 1, "form-control"], ["for", "angkatan", 1, "col-4", "col-form-label"], ["formControlName", "angkatan", "optionValue", "angkatanID", "optionLabel", "name", 3, "options", "autoDisplayFirst"], ["for", "pangkat", 1, "col-4", "col-form-label"], ["formControlName", "pangkat", "optionValue", "pangkatID", "optionLabel", "name", 3, "options", "autoDisplayFirst"], ["for", "kesatuan", 1, "col-4", "col-form-label"], ["type", "text", "formControlName", "kesatuan", 1, "form-control"], ["for", "jabatan", 1, "col-4", "col-form-label"], ["type", "text", "formControlName", "jabatan", 1, "form-control"], ["for", "golpas", 1, "col-4", "col-form-label"], ["formControlName", "groupPasien", "optionValue", "id", "optionLabel", "name", 3, "options", "autoDisplayFirst", "ngModelChange"], [1, "btn", "btn-sm", "btn-primary", 3, "disabled", "click"], [1, "bi", "bi-save", "mr-1"], [1, "bi", "bi-exclamation-circle-fill", "tx-danger", "ml-1", "tx-13"]],
        template: function RegistrasiComponent_Template(rf, ctx) {
          if (rf & 1) {
            var _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "p-dialog", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("visibleChange", function RegistrasiComponent_Template_p_dialog_visibleChange_0_listener($event) {
              return ctx.dialogVclaim = $event;
            })("onHide", function RegistrasiComponent_Template_p_dialog_onHide_0_listener() {
              return ctx.vclaimService.closeDialog();
            })("onShow", function RegistrasiComponent_Template_p_dialog_onShow_0_listener() {
              return ctx.getPesertaBpjs();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "app-vclaim");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "p-dialog", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("visibleChange", function RegistrasiComponent_Template_p_dialog_visibleChange_2_listener($event) {
              return ctx.dialogDataPasien = $event;
            })("onHide", function RegistrasiComponent_Template_p_dialog_onHide_2_listener() {
              return ctx.dataPasienService.closeDialog();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](3, "app-data-pasien");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "p-dialog", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("visibleChange", function RegistrasiComponent_Template_p_dialog_visibleChange_4_listener($event) {
              return ctx.dialogFormRawatJalan = $event;
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](5, "app-form-rawat-jalan");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](6, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](7, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](8, "div", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](9, "div", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](10, "button", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function RegistrasiComponent_Template_button_click_10_listener() {
              return ctx.dialogDataPasien = true;
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](11, "i", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](12, " Cari Pasien");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](13, "button", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function RegistrasiComponent_Template_button_click_13_listener($event) {
              _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r25);

              var _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵreference"](18);

              return _r0.toggle($event);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](14, "i", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](15, " Pendaftaran ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](16, "i", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](17, "p-menu", 11, 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](19, "button", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](20, "i", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](21, " Print ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](22, "i", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](23, "button", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function RegistrasiComponent_Template_button_click_23_listener() {
              return ctx.vclaimService.openDialog();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](24, "i", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](25, " VClaim BPJS");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](26, "button", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function RegistrasiComponent_Template_button_click_26_listener() {
              return ctx.form.reset();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](27, "i", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](28, " Refresh");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](29, "div", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](30, RegistrasiComponent_button_30_Template, 3, 1, "button", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](31, RegistrasiComponent_button_31_Template, 3, 1, "button", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](32, "div", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](33, "button", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](34, "i", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](35, " Batal");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](36, "div", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](37, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](38, "form", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](39, "div", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](40, "div", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](41, "div", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](42, "div", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](43, "button", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](44, "i", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](45, " Ambil Photo");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](46, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](47, "div", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](48, "label", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](49, " ID Pasien ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](50, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](51, "input", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](52, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](53, "label", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](54, " RS ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](55, RegistrasiComponent_span_55_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](56, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](57, "p-dropdown", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](58, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](59, "label", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](60, " No. RM ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](61, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](62, "input", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](63, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](64, "label", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](65, " No. BPJS / Asuransi ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](66, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](67, "input", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](68, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](69, "label", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](70, " NIK ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](71, RegistrasiComponent_span_71_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](72, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](73, "input", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](74, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](75, "label", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](76, " Nama ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](77, RegistrasiComponent_span_77_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](78, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](79, "div", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](80, "div", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](81, "p-dropdown", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](82, "input", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](83, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](84, "label", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](85, " Tempat Lahir ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](86, RegistrasiComponent_span_86_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](87, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](88, "input", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](89, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](90, "label", 46);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](91, " Tanggal Lahir ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](92, RegistrasiComponent_span_92_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](93, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](94, "p-calendar", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](95, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](96, "label", 48);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](97, " Jenis Kelamin ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](98, RegistrasiComponent_span_98_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](99, "div", 49);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](100, "p-radioButton", 50);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](101, " LAKI-LAKI ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](102, "p-radioButton", 51);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](103, "span");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](104, "PEREMPUAN");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](105, "hr");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](106, "div", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](107, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](108, "h4");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](109, "ALAMAT PASIEN");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](110, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](111, "label", 52);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](112, " Alamat ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](113, RegistrasiComponent_span_113_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](114, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](115, "textarea", 53);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](116, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](117, "label", 54);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](118, " Telepon Pasien ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](119, RegistrasiComponent_span_119_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](120, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](121, "input", 55);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](122, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](123, "label", 56);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](124, " Warga Negara ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](125, RegistrasiComponent_span_125_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](126, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](127, "p-dropdown", 57);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](128, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](129, "label", 56);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](130, " Provinsi ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](131, RegistrasiComponent_span_131_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](132, "div", 58);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](133, "p-dropdown", 59);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function RegistrasiComponent_Template_p_dropdown_ngModelChange_133_listener() {
              var tmp_b_0;
              return ctx.getKota((tmp_b_0 = ctx.form.get("provinsi")) == null ? null : tmp_b_0.value);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](134, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](135, "label", 60);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](136, " Kota ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](137, "span", 61);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](138, "div", 58);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](139, "p-dropdown", 62);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function RegistrasiComponent_Template_p_dropdown_ngModelChange_139_listener() {
              var tmp_b_0;
              return ctx.getKecamatan((tmp_b_0 = ctx.form.get("kota")) == null ? null : tmp_b_0.value);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](140, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](141, "label", 63);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](142, " Kecamatan");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](143, "span", 64);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](144, "div", 58);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](145, "p-dropdown", 65);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function RegistrasiComponent_Template_p_dropdown_ngModelChange_145_listener() {
              var tmp_b_0;
              return ctx.getKelurahan((tmp_b_0 = ctx.form.get("kecamatan")) == null ? null : tmp_b_0.value);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](146, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](147, "label", 66);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](148, " Kelurahan");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](149, "span", 67);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](150, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](151, "p-dropdown", 68);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](152, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](153, "form", 69);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](154, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](155, "label", 70);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](156, " Status Perkawinan ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](157, RegistrasiComponent_span_157_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](158, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](159, "p-dropdown", 71);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](160, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](161, "label", 72);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](162, " Agama ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](163, RegistrasiComponent_span_163_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](164, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](165, "p-dropdown", 73);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](166, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](167, "label", 74);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](168, " Pekerjaan ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](169, RegistrasiComponent_span_169_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](170, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](171, "p-dropdown", 75);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](172, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](173, "label", 76);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](174, " Pendidikan ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](175, RegistrasiComponent_span_175_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](176, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](177, "p-dropdown", 77);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](178, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](179, "label", 78);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](180, " Golongan Darah ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](181, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](182, "input", 79);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](183, "hr");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](184, "div", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](185, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](186, "h4");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](187, "KELUARGA / KONTAK DARURAT");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](188, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](189, "label", 80);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](190, " Nama Kerabat / Keluarga ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](191, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](192, "input", 81);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](193, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](194, "label", 80);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](195, " Hubungan dengan pasien ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](196, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](197, "p-dropdown", 82);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](198, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](199, "label", 80);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](200, " No. Telepon ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](201, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](202, "input", 81);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](203, "hr");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](204, "div", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](205, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](206, "h4");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](207, "DATA KEANGGOTAAN");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](208, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](209, "label", 83);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](210, " NRP / NIP ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](211, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](212, "input", 84);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](213, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](214, "label", 85);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](215, " Angkatan ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](216, RegistrasiComponent_span_216_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](217, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](218, "p-dropdown", 86);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](219, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](220, "label", 87);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](221, " Pangkat / Golongan ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](222, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](223, "p-dropdown", 88);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](224, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](225, "label", 89);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](226, " Kesatuan ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](227, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](228, "input", 90);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](229, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](230, "label", 91);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](231, " Jabatan ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](232, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](233, "input", 92);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](234, "hr");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](235, "div", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](236, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](237, "h4");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](238, "DATA PENJAMIN / ASURANSI");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](239, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](240, "label", 93);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](241, " Asuransi / Penjamin ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](242, RegistrasiComponent_span_242_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](243, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](244, "p-dropdown", 94);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function RegistrasiComponent_Template_p_dropdown_ngModelChange_244_listener() {
              var tmp_b_0;
              return ctx.getGolonganPasien((tmp_b_0 = ctx.form.get("groupPasien")) == null ? null : tmp_b_0.value);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](245, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](246, "label", 93);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](247, " Jenis Asuransi ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](248, RegistrasiComponent_span_248_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](249, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](250, "p-dropdown", 94);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function RegistrasiComponent_Template_p_dropdown_ngModelChange_250_listener() {
              var tmp_b_0;
              return ctx.getGolonganPasien((tmp_b_0 = ctx.form.get("groupPasien")) == null ? null : tmp_b_0.value);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](251, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](252, "label", 93);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](253, " No. Asuransi ");

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](254, RegistrasiComponent_span_254_Template, 1, 0, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](255, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](256, "input", 81);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            var tmp_14_0;
            var tmp_15_0;
            var tmp_17_0;
            var tmp_21_0;
            var tmp_22_0;
            var tmp_25_0;
            var tmp_26_0;
            var tmp_28_0;
            var tmp_29_0;
            var tmp_32_0;
            var tmp_33_0;
            var tmp_38_0;
            var tmp_56_0;
            var tmp_60_0;
            var tmp_64_0;
            var tmp_68_0;
            var tmp_76_0;
            var tmp_83_0;
            var tmp_87_0;
            var tmp_91_0;

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](111, _c0));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("visible", ctx.dialogVclaim)("modal", true)("draggable", true);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](112, _c1));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("visible", ctx.dialogDataPasien)("modal", true)("draggable", true);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](113, _c1));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("visible", ctx.dialogFormRawatJalan)("modal", true)("draggable", true);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](13);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("popup", true)("model", ctx.menuPendaftaran);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](13);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", !((tmp_14_0 = ctx.form.get("id")) == null ? null : tmp_14_0.value));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_15_0 = ctx.form.get("id")) == null ? null : tmp_15_0.value);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("formGroup", ctx.form);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](17);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_17_0 = ctx.form.get("rs")) == null ? null : tmp_17_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](114, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.rs)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](14);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_21_0 = ctx.form.get("nik")) == null ? null : tmp_21_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ((tmp_22_0 = ctx.form.get("nama")) == null ? null : tmp_22_0.errors) || ((tmp_22_0 = ctx.form.get("awalanNama")) == null ? null : tmp_22_0.errors));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.awalanNama)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_25_0 = ctx.form.get("tempatLahir")) == null ? null : tmp_25_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_26_0 = ctx.form.get("tglLahir")) == null ? null : tmp_26_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("showIcon", true);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_28_0 = ctx.form.get("jnsKelamin")) == null ? null : tmp_28_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](15);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_29_0 = ctx.form.get("alamat")) == null ? null : tmp_29_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](115, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("autoResize", true);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_32_0 = ctx.form.get("tlpPasien")) == null ? null : tmp_32_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_33_0 = ctx.form.get("negara")) == null ? null : tmp_33_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](116, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.negara)("filter", true)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_38_0 = ctx.form.get("provinsi")) == null ? null : tmp_38_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](117, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.provinsi)("filter", true)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](118, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.kota)("filter", true)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](119, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.kecamatan)("filter", true)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](120, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.kelurahan)("filter", true)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("formGroup", ctx.form);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_56_0 = ctx.form.get("statusNikah")) == null ? null : tmp_56_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](121, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.statusNikah)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_60_0 = ctx.form.get("agama")) == null ? null : tmp_60_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](122, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.agama)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_64_0 = ctx.form.get("pekerjaan")) == null ? null : tmp_64_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](123, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.pekerjaan)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_68_0 = ctx.form.get("pendidikan")) == null ? null : tmp_68_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](124, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.pendidikan)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](20);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](125, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.suku)("filter", true)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](19);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_76_0 = ctx.form.get("angkatan")) == null ? null : tmp_76_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](126, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.angkatan)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](127, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.pangkat)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](19);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_83_0 = ctx.form.get("groupPasien")) == null ? null : tmp_83_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](128, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.groupPasien)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_87_0 = ctx.form.get("groupPasien")) == null ? null : tmp_87_0.errors);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction0"](129, _c2));

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx.groupPasien)("autoDisplayFirst", false);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (tmp_91_0 = ctx.form.get("groupPasien")) == null ? null : tmp_91_0.errors);
          }
        },
        directives: [primeng_dialog__WEBPACK_IMPORTED_MODULE_9__.Dialog, _shared_vclaim_vclaim_component__WEBPACK_IMPORTED_MODULE_4__.VclaimComponent, _components_data_pasien_data_pasien_component__WEBPACK_IMPORTED_MODULE_5__.DataPasienComponent, _components_form_rawat_jalan_form_rawat_jalan_component__WEBPACK_IMPORTED_MODULE_6__.FormRawatJalanComponent, primeng_menu__WEBPACK_IMPORTED_MODULE_10__.Menu, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControlName, primeng_dropdown__WEBPACK_IMPORTED_MODULE_12__.Dropdown, primeng_calendar__WEBPACK_IMPORTED_MODULE_13__.Calendar, primeng_radiobutton__WEBPACK_IMPORTED_MODULE_14__.RadioButton, primeng_inputtextarea__WEBPACK_IMPORTED_MODULE_15__.InputTextarea, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.MaxLengthValidator],
        styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWdpc3RyYXNpLmNvbXBvbmVudC5jc3MifQ== */"]
      });
      /***/
    },

    /***/
    23757:
    /*!*********************************************************!*\
      !*** ./src/app/modules/registrasi/registrasi.module.ts ***!
      \*********************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "RegistrasiModule": function RegistrasiModule() {
          return (
            /* binding */
            _RegistrasiModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/common */
      54364);
      /* harmony import */


      var _registrasi_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./registrasi-routing.module */
      35487);
      /* harmony import */


      var _registrasi_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./registrasi.component */
      7317);
      /* harmony import */


      var _components_data_pasien_data_pasien_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./components/data-pasien/data-pasien.component */
      81016);
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../shared/shared.module */
      72271);
      /* harmony import */


      var _components_form_rawat_jalan_form_rawat_jalan_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./components/form-rawat-jalan/form-rawat-jalan.component */
      48457);
      /* harmony import */


      var _components_data_registrasi_data_registrasi_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./components/data-registrasi/data-registrasi.component */
      20744);
      /* harmony import */


      var _components_form_registrasi_form_registrasi_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./components/form-registrasi/form-registrasi.component */
      18413);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/core */
      2316);

      var _RegistrasiModule = /*#__PURE__*/_createClass(function _RegistrasiModule() {
        _classCallCheck(this, _RegistrasiModule);
      });

      _RegistrasiModule.ɵfac = function RegistrasiModule_Factory(t) {
        return new (t || _RegistrasiModule)();
      };

      _RegistrasiModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({
        type: _RegistrasiModule
      });
      _RegistrasiModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({
        imports: [[_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule, _angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule, _registrasi_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegistrasiRoutingModule]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](_RegistrasiModule, {
          declarations: [_registrasi_component__WEBPACK_IMPORTED_MODULE_1__.RegistrasiComponent, _components_data_pasien_data_pasien_component__WEBPACK_IMPORTED_MODULE_2__.DataPasienComponent, _components_form_rawat_jalan_form_rawat_jalan_component__WEBPACK_IMPORTED_MODULE_4__.FormRawatJalanComponent, _components_data_registrasi_data_registrasi_component__WEBPACK_IMPORTED_MODULE_5__.DataRegistrasiComponent, _components_form_registrasi_form_registrasi_component__WEBPACK_IMPORTED_MODULE_6__.FormRegistrasiComponent],
          imports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule, _angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule, _registrasi_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegistrasiRoutingModule],
          exports: [_components_data_registrasi_data_registrasi_component__WEBPACK_IMPORTED_MODULE_5__.DataRegistrasiComponent, _components_form_registrasi_form_registrasi_component__WEBPACK_IMPORTED_MODULE_6__.FormRegistrasiComponent]
        });
      })();
      /***/

    },

    /***/
    54667:
    /*!***************************************************************!*\
      !*** ./src/app/modules/registrasi/services/master.service.ts ***!
      \***************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "MasterService": function MasterService() {
          return (
            /* binding */
            _MasterService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! rxjs */
      76491);
      /* harmony import */


      var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! src/app/config */
      39698);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      53882);

      var _MasterService = /*#__PURE__*/function () {
        function _MasterService(http) {
          _classCallCheck(this, _MasterService);

          this.http = http;
          this.rs = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.awalanNama = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.negara = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.provinsi = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.kota = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.kecamatan = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.kelurahan = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.suku = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.statusNikah = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.agama = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.pekerjaan = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.pendidikan = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.angkatan = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.pangkat = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.groupPasien = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.golonganPasien = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
          this.getRs();
          this.getAwalanNama();
          this.getNegara();
          this.getProvinsi();
          this.getSuku();
          this.getStatusNikah();
          this.getAgama();
          this.getPekerjaan();
          this.getPendidikan();
          this.getAngkatan();
          this.getPangkat();
          this.getGroupPasien();
        }

        _createClass(_MasterService, [{
          key: "getRs",
          value: function getRs() {
            var _this6 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/rs')).subscribe(function (data) {
              return _this6.rs.next(data.data);
            });
          }
        }, {
          key: "getAwalanNama",
          value: function getAwalanNama() {
            var _this7 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/awalan_nama')).subscribe(function (data) {
              return _this7.awalanNama.next(data.data);
            });
          }
        }, {
          key: "getNegara",
          value: function getNegara() {
            var _this8 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/negara')).subscribe(function (data) {
              return _this8.negara.next(data.data);
            });
          }
        }, {
          key: "getProvinsi",
          value: function getProvinsi() {
            var _this9 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/provinsi')).subscribe(function (data) {
              return _this9.provinsi.next(data.data);
            });
          }
        }, {
          key: "getKota",
          value: function getKota(idProvinsi) {
            var _this10 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/kota/id_provinsi/' + idProvinsi)).subscribe(function (data) {
              return _this10.kota.next(data.data);
            });
          }
        }, {
          key: "getKecamatan",
          value: function getKecamatan(idKota) {
            var _this11 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/kecamatan/id_kota/' + idKota)).subscribe(function (data) {
              return _this11.kecamatan.next(data.data);
            });
          }
        }, {
          key: "getKelurahan",
          value: function getKelurahan(idKecamatan) {
            var _this12 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/kelurahan/id_kecamatan/' + idKecamatan)).subscribe(function (data) {
              return _this12.kelurahan.next(data.data);
            });
          }
        }, {
          key: "getSuku",
          value: function getSuku() {
            var _this13 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/suku')).subscribe(function (data) {
              return _this13.suku.next(data.data);
            });
          }
        }, {
          key: "getStatusNikah",
          value: function getStatusNikah() {
            var _this14 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/status_nikah')).subscribe(function (data) {
              return _this14.statusNikah.next(data.data);
            });
          }
        }, {
          key: "getAgama",
          value: function getAgama() {
            var _this15 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/agama')).subscribe(function (data) {
              return _this15.agama.next(data.data);
            });
          }
        }, {
          key: "getPekerjaan",
          value: function getPekerjaan() {
            var _this16 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/pekerjaan')).subscribe(function (data) {
              return _this16.pekerjaan.next(data.data);
            });
          }
        }, {
          key: "getPendidikan",
          value: function getPendidikan() {
            var _this17 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/pendidikan')).subscribe(function (data) {
              return _this17.pendidikan.next(data.data);
            });
          }
        }, {
          key: "getAngkatan",
          value: function getAngkatan() {
            var _this18 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/angkatan')).subscribe(function (data) {
              return _this18.angkatan.next(data.data);
            });
          }
        }, {
          key: "getPangkat",
          value: function getPangkat() {
            var _this19 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/pangkat')).subscribe(function (data) {
              return _this19.pangkat.next(data.data);
            });
          }
        }, {
          key: "getGroupPasien",
          value: function getGroupPasien() {
            var _this20 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/group_pasien')).subscribe(function (data) {
              return _this20.groupPasien.next(data.data);
            });
          }
        }, {
          key: "getGolonganPasien",
          value: function getGolonganPasien(idGroupPasien) {
            var _this21 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('master/golongan_pasien/id_grouppasien/' + idGroupPasien)).subscribe(function (data) {
              return _this21.golonganPasien.next(data.data);
            });
          }
        }]);

        return _MasterService;
      }();

      _MasterService.ɵfac = function MasterService_Factory(t) {
        return new (t || _MasterService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient));
      };

      _MasterService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
        token: _MasterService,
        factory: _MasterService.ɵfac,
        providedIn: 'root'
      });
      /***/
    },

    /***/
    92881:
    /*!*******************************************************************!*\
      !*** ./src/app/modules/registrasi/services/registrasi.service.ts ***!
      \*******************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "RegistrasiService": function RegistrasiService() {
          return (
            /* binding */
            _RegistrasiService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! src/app/config */
      39698);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common/http */
      53882);

      var _RegistrasiService = /*#__PURE__*/function () {
        function _RegistrasiService(http) {
          _classCallCheck(this, _RegistrasiService);

          this.http = http;
        }

        _createClass(_RegistrasiService, [{
          key: "updatePasien",
          value: function updatePasien(data) {
            this.http.post(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('pasien/update'), data).subscribe(function (data) {
              return console.log(data);
            });
          }
        }]);

        return _RegistrasiService;
      }();

      _RegistrasiService.ɵfac = function RegistrasiService_Factory(t) {
        return new (t || _RegistrasiService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
      };

      _RegistrasiService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
        token: _RegistrasiService,
        factory: _RegistrasiService.ɵfac,
        providedIn: 'root'
      });
      /***/
    }
  }]);
})();
//# sourceMappingURL=default-src_app_modules_registrasi_registrasi_module_ts-es5.js.map