(function () {
  "use strict";

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

  (self["webpackChunkiniapps"] = self["webpackChunkiniapps"] || []).push([["src_app_modules_rawat-jalan_rawat-jalan_module_ts"], {
    /***/
    10079:
    /*!*********************************************************************!*\
      !*** ./src/app/modules/kasir/components/billing/billing.service.ts ***!
      \*********************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "BillingService": function BillingService() {
          return (
            /* binding */
            _BillingService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! rxjs */
      76491);
      /* harmony import */


      var src_app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! src/app/config */
      39698);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      53882);

      var _BillingService = /*#__PURE__*/function () {
        function _BillingService(http) {
          _classCallCheck(this, _BillingService);

          this.http = http;
          this.tarif = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
          this.categoryTarif = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
          this.getCategory();
        }

        _createClass(_BillingService, [{
          key: "getTarifByCategory",
          value: function getTarifByCategory(categoryId) {
            var _this = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('tarif/byCategory/' + categoryId)).subscribe(function (data) {
              return _this.tarif.next(data.data);
            });
          }
        }, {
          key: "getCategory",
          value: function getCategory() {
            var _this2 = this;

            this.http.get(src_app_config__WEBPACK_IMPORTED_MODULE_0__.config.api_url('tarif/category')).subscribe(function (data) {
              return _this2.categoryTarif.next(data.data);
            });
          }
        }]);

        return _BillingService;
      }();

      _BillingService.ɵfac = function BillingService_Factory(t) {
        return new (t || _BillingService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient));
      };

      _BillingService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
        token: _BillingService,
        factory: _BillingService.ɵfac,
        providedIn: 'root'
      });
      /***/
    },

    /***/
    94117:
    /*!*******************************************************************!*\
      !*** ./src/app/modules/rawat-jalan/rawat-jalan-routing.module.ts ***!
      \*******************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "RawatJalanRoutingModule": function RawatJalanRoutingModule() {
          return (
            /* binding */
            _RawatJalanRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      71258);
      /* harmony import */


      var _rawat_jalan_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./rawat-jalan.component */
      44570);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      2316);

      var routes = [{
        path: '',
        component: _rawat_jalan_component__WEBPACK_IMPORTED_MODULE_0__.RawatJalanComponent
      }];

      var _RawatJalanRoutingModule = /*#__PURE__*/_createClass(function _RawatJalanRoutingModule() {
        _classCallCheck(this, _RawatJalanRoutingModule);
      });

      _RawatJalanRoutingModule.ɵfac = function RawatJalanRoutingModule_Factory(t) {
        return new (t || _RawatJalanRoutingModule)();
      };

      _RawatJalanRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
        type: _RawatJalanRoutingModule
      });
      _RawatJalanRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
        imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](_RawatJalanRoutingModule, {
          imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule],
          exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
        });
      })();
      /***/

    },

    /***/
    44570:
    /*!**************************************************************!*\
      !*** ./src/app/modules/rawat-jalan/rawat-jalan.component.ts ***!
      \**************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "RawatJalanComponent": function RawatJalanComponent() {
          return (
            /* binding */
            _RawatJalanComponent
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      1707);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      2316);
      /* harmony import */


      var _registrasi_services_master_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../registrasi/services/master.service */
      54667);
      /* harmony import */


      var _kasir_components_billing_billing_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../kasir/components/billing/billing.service */
      10079);
      /* harmony import */


      var primeng_tabview__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! primeng/tabview */
      46304);
      /* harmony import */


      var _registrasi_components_data_registrasi_data_registrasi_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../registrasi/components/data-registrasi/data-registrasi.component */
      20744);
      /* harmony import */


      var primeng_dropdown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! primeng/dropdown */
      14170);
      /* harmony import */


      var primeng_table__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! primeng/table */
      6536);
      /* harmony import */


      var primeng_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! primeng/api */
      88055);
      /* harmony import */


      var primeng_selectbutton__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! primeng/selectbutton */
      27925);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/common */
      54364);

      function RawatJalanComponent_ng_template_44_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "tr");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "th", 52);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2, "Nama Tarif");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "th");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, "Harga");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        }
      }

      function RawatJalanComponent_ng_template_45_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "tr", 53);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "td", 52);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "uppercase");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "td");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "number");

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var item_r2 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("pSelectableRow", item_r2);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 3, item_r2.namaTarif));

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](6, 5, item_r2.harga));
        }
      }

      var _c0 = function _c0() {
        return {
          width: "100%"
        };
      };

      var _c1 = function _c1() {
        return {
          minHeight: "420px"
        };
      };

      var _RawatJalanComponent = /*#__PURE__*/function () {
        function _RawatJalanComponent(fb, masterService, billingService) {
          _classCallCheck(this, _RawatJalanComponent);

          this.fb = fb;
          this.masterService = masterService;
          this.billingService = billingService;
          this.selectedCategoryTarif = '';
          this.tarif = [];
          this.categoryTarif = [];
          this.rs = [];
          this.dialogVclaim = false;
          this.selectedCatTarif = '';
          this.catTarif = [{
            name: 'All'
          }, {
            name: 'Perawatan'
          }, {
            name: 'Laboratorium'
          }, {
            name: 'Radiologi'
          }, {
            name: 'Farmasi'
          }, {
            name: 'Operasi'
          }, {
            name: 'Kamar Rawat'
          }];
        }

        _createClass(_RawatJalanComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this3 = this;

            this.initForm();
            this.masterService.rs.subscribe(function (data) {
              return _this3.rs = data;
            });
            this.billingService.tarif.subscribe(function (data) {
              return _this3.tarif = data;
            });
            this.billingService.categoryTarif.subscribe(function (data) {
              return _this3.categoryTarif = data;
            });
            this.menuPrint = [{
              label: 'Registrasi'
            }, {
              label: 'Kartu Pasien'
            }, {
              label: 'SEP'
            }];
          }
        }, {
          key: "initForm",
          value: function initForm() {
            this.form = this.fb.group({
              rs: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              norm: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              id_pasien: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              noAsuransi: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              nik: [''],
              nama: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              tglLahir: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              tanggal: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              noSep: [''],
              poliklinik: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              dokter: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              jnsPembayaran: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
              catatan: [''],
              noreg: [''],
              status: ['']
            });
          }
        }]);

        return _RawatJalanComponent;
      }();

      _RawatJalanComponent.ɵfac = function RawatJalanComponent_Factory(t) {
        return new (t || _RawatJalanComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_registrasi_services_master_service__WEBPACK_IMPORTED_MODULE_0__.MasterService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_kasir_components_billing_billing_service__WEBPACK_IMPORTED_MODULE_1__.BillingService));
      };

      _RawatJalanComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
        type: _RawatJalanComponent,
        selectors: [["app-rawat-jalan"]],
        decls: 271,
        vars: 14,
        consts: [["header", "Registrasi"], [1, "row"], [1, "col"], ["header", "Billing"], [1, "row", "p-2", "caption-title", "sticky-top"], [1, "col-auto", "border-right"], [1, "col-auto"], [1, "mr-1", "tx-12"], [1, "row", "mt-3"], [1, "col-4"], ["placeholder", "Kategori", "optionLabel", "namaCatTarif", "optionValue", "cat_tarifID", "styleClass", "mb-1", 3, "options", "ngModel", "filter", "ngModelChange"], [1, "input-group"], ["type", "text", "placeholder", "Cari Tarif...", 1, "form-control"], [1, "input-group-append"], [1, "btn", "btn-secondary"], [1, "bi", "bi-search"], ["styleClass", "p-datatable-sm table-striped bg-light", "selectionMode", "single", "responsiveLayout", "scroll", "scrollHeight", "380px", 3, "value", "scrollable", "rows"], ["pTemplate", "header"], ["pTemplate", "body"], [1, "pt-2"], [1, "tx-secondary", "pt-1", "pb-1"], [1, "btn", "btn-xs", "btn-light", "mr-1", "mb-1"], [1, "bi", "bi-archive-fill"], [1, "btn", "btn-xs", "btn-secondary", "mr-1", "mb-1"], [1, "bi", "bi-gear"], [1, "col", "p-0"], [1, "pb-2"], [1, "btn", "btn-outline-light", "btn-xs", "p-1", "pl-2", "pr-2", "mr-1"], [1, "bi", "bi-percent"], [1, "bi", "bi-printer"], [1, "bi", "bi-filetype-xls"], [1, "bi", "bi-trash"], [1, "border-bottom", "pb-2"], ["optionLabel", "name", 3, "options", "ngModel", "ngModelChange"], [1, "table", "table-striped", "table-hover", "border-bottom"], ["colspan", "8", 1, "p-2", "bg-gray-300"], [1, "btn", "btn-xs", "btn-light", "tx-14", "p-0", "pl-3", "pr-3", "w-100"], [1, "btn", "btn-xs", "btn-light", "tx-danger", "tx-14", "p-0", "pl-3", "pr-3", "w-100"], [1, "btn", "btn-xs", "btn-icon", "btn-secondary"], [1, "bi", "bi-list"], ["header", "Riwayat Pelayanan"], [1, "col", "pt-3"], [1, "timeline-group", "tx-14"], [1, "timeline-label", "bg-gray-200"], [1, "timeline-item"], [1, "timeline-time"], [1, "timeline-body"], [1, "mb-0"], [1, "tx-primary"], [1, "badge", "badge-secondary", "pt-1", "pb-1", "tx-12"], [1, "mb-3"], [1, "btn", "btn-xs", "btn-icon", "btn-light"], ["width", "200px"], [3, "pSelectableRow"]],
        template: function RawatJalanComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "p-tabView");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "p-tabPanel", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](4, "app-data-registrasi");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "p-tabPanel", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "div", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "h5");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9, "Billing");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "strong", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](12, "PASIEN :");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](13, "span");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](14, "FAZRI ANGGRIAWAN (34 thn , LAKI-LAKI)");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "div", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "strong", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](17, "NO.RM :");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "span");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](19, "818181");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](20, "div", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](21, "strong", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](22, "PEMBAYARAN :");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "span");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](24, "BPJS KESEHATAN");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](25, "div", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](26, "strong", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](27, "RUANGAN :");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "span");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](29, "POLIKLINIK ANAK");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](30, "div", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "strong", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](32, "DOKTER :");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](33, "span");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](34, "dr. Bambang Budiarto, Sp.B");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](35, "div", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](36, "div", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](37, "p-dropdown", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function RawatJalanComponent_Template_p_dropdown_ngModelChange_37_listener($event) {
              return ctx.selectedCategoryTarif = $event;
            })("ngModelChange", function RawatJalanComponent_Template_p_dropdown_ngModelChange_37_listener() {
              return ctx.billingService.getTarifByCategory(ctx.selectedCategoryTarif);
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](38, "div", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](39, "input", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](40, "div", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](41, "button", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](42, "i", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](43, "p-table", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](44, RawatJalanComponent_ng_template_44_Template, 5, 0, "ng-template", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](45, RawatJalanComponent_ng_template_45_Template, 7, 7, "ng-template", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](46, "div", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](47, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](48, "Paket Tarif : ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](49, "button", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](50, "i", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](51, " Pemeriksaan Dokter");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](52, "button", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](53, "i", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](54, " Pasien Baru");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](55, "button", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](56, "i", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](57, "div", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](58, "div", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](59, "button", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](60, "i", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](61, " Discount");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](62, "button", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](63, "i", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](64, " Print");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](65, "button", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](66, "i", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](67, " XLS");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](68, "button", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](69, "i", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](70, " Hapus");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](71, "div", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](72, "p-selectButton", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function RawatJalanComponent_Template_p_selectButton_ngModelChange_72_listener($event) {
              return ctx.selectedCatTarif = $event;
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](73, "table", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](74, "thead");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](75, "tr");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](76, "th");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](77, "Tanggal");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](78, "th");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](79, "Nama Tarif");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](80, "th");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](81, "Pelaksana Medis / Non Medis");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](82, "th");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](83, "Harga");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](84, "th");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](85, "Qty");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](86, "th");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](87, "Discount");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](88, "th");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](89, "Total");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](90, "th");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](91, "\xA0");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](92, "tbody");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](93, "tr");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](94, "td", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](95, "\xA0");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](96, "strong");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](97, "PERAWATAN");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](98, "tr");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](99, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](100, "11 Jun 2022");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](101, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](102, "KONSULTASI DOKTER SPESIALIS");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](103, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](104, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](105, "dr. Bebet Sunaryo, S.pd");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](106, "button", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](107, "-- Pilih Perawat --");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](108, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](109, "250,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](110, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](111, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](112, "1");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](113, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](114, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](115, "0");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](116, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](117, "250,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](118, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](119, "button", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](120, "i", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](121, "tr");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](122, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](123, "11 Jun 2022");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](124, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](125, "KARTU PASIEN");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](126, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](127, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](128, "dr. Bebet Sunaryo, S.pd");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](129, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](130, "Perawat Bedah");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](131, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](132, "250,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](133, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](134, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](135, "1");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](136, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](137, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](138, "0");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](139, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](140, "250,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](141, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](142, "button", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](143, "i", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](144, "tr");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](145, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](146, "11 Jun 2022");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](147, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](148, "KARTU PASIEN");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](149, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](150, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](151, "dr. Bebet Sunaryo, S.pd");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](152, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](153, "Perawat Bedah");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](154, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](155, "250,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](156, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](157, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](158, "1");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](159, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](160, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](161, "0");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](162, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](163, "250,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](164, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](165, "button", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](166, "i", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](167, "tr");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](168, "td", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](169, "\xA0");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](170, "strong");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](171, "LABORATORIUM");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](172, "tr");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](173, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](174, "11 Jun 2022");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](175, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](176, "DARAH LENGKAP");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](177, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](178, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](179, "dr. Bebet Sunaryo, S.pd");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](180, "button", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](181, "-- Pilih Perawat --");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](182, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](183, "250,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](184, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](185, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](186, "1");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](187, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](188, "button", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](189, "0");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](190, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](191, "250,000");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](192, "td");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](193, "button", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](194, "i", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](195, "p-tabPanel", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](196, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](197, "div", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](198, "div", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](199, "div", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](200, "Hari ini, 18 Sept 2022");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](201, "div", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](202, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](203, "10:30");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](204, "div", 46);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](205, "h6", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](206, "POLIKLINIK ANAK");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](207, "p", 48);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](208, "dr. Bebet Sunaryo S.Pd");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](209, "p", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](210, "Jenis Kunjungan : Kontrol Kembali");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](211, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](212, "Diagnosa : Z10 - Vascular dementia of acute onset");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](213, "p", 49);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](214, "Tunai");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](215, "div", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](216, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](217, "11:30");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](218, "div", 46);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](219, "h6", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](220, "LABORATORIUM");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](221, "p", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](222, "Pemeriksaan : SGOT, SGPT, DARAH LENGKAP");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](223, "div", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](224, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](225, "14:45");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](226, "div", 46);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](227, "h6", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](228, "FARMASI");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](229, "p", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](230, "Panadol, Amoxan");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](231, "div", 50);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](232, "\xA0");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](233, "div", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](234, "10 Agustus 2022");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](235, "div", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](236, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](237, "10:30");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](238, "div", 46);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](239, "h6", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](240, "POLIKLINIK ANAK");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](241, "p", 48);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](242, "dr. Bebet Sunaryo S.Pd");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](243, "p", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](244, "Jenis Kunjungan : Kontrol Kembali");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](245, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](246, "Diagnosa : Z10 - Vascular dementia of acute onset");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](247, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](248, "SEP : ");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](249, "button", 51);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](250, "R1203V00012319992");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](251, "p", 49);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](252, "BPJS Kesehatan");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](253, "div", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](254, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](255, "11:30");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](256, "div", 46);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](257, "h6", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](258, "LABORATORIUM");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](259, "p", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](260, "Pemeriksaan : SGOT, SGPT, DARAH LENGKAP");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](261, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](262, "div", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](263, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](264, "14:45");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](265, "div", 46);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](266, "h6", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](267, "FARMASI");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](268, "p", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](269, "Panadol, Amoxan");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](270, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](37);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](12, _c0));

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("options", ctx.categoryTarif)("ngModel", ctx.selectedCategoryTarif)("filter", true);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](13, _c1));

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("value", ctx.tarif)("scrollable", true)("rows", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](29);

            _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("options", ctx.catTarif)("ngModel", ctx.selectedCatTarif);
          }
        },
        directives: [primeng_tabview__WEBPACK_IMPORTED_MODULE_5__.TabView, primeng_tabview__WEBPACK_IMPORTED_MODULE_5__.TabPanel, _registrasi_components_data_registrasi_data_registrasi_component__WEBPACK_IMPORTED_MODULE_2__.DataRegistrasiComponent, primeng_dropdown__WEBPACK_IMPORTED_MODULE_6__.Dropdown, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgModel, primeng_table__WEBPACK_IMPORTED_MODULE_7__.Table, primeng_api__WEBPACK_IMPORTED_MODULE_8__.PrimeTemplate, primeng_selectbutton__WEBPACK_IMPORTED_MODULE_9__.SelectButton, primeng_table__WEBPACK_IMPORTED_MODULE_7__.SelectableRow],
        pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.UpperCasePipe, _angular_common__WEBPACK_IMPORTED_MODULE_10__.DecimalPipe],
        styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyYXdhdC1qYWxhbi5jb21wb25lbnQuY3NzIn0= */"]
      });
      /***/
    },

    /***/
    10225:
    /*!***********************************************************!*\
      !*** ./src/app/modules/rawat-jalan/rawat-jalan.module.ts ***!
      \***********************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "RawatJalanModule": function RawatJalanModule() {
          return (
            /* binding */
            _RawatJalanModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/common */
      54364);
      /* harmony import */


      var _rawat_jalan_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./rawat-jalan-routing.module */
      94117);
      /* harmony import */


      var _rawat_jalan_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./rawat-jalan.component */
      44570);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/forms */
      1707);
      /* harmony import */


      var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../shared/shared.module */
      72271);
      /* harmony import */


      var _registrasi_registrasi_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../registrasi/registrasi.module */
      23757);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/core */
      2316);

      var _RawatJalanModule = /*#__PURE__*/_createClass(function _RawatJalanModule() {
        _classCallCheck(this, _RawatJalanModule);
      });

      _RawatJalanModule.ɵfac = function RawatJalanModule_Factory(t) {
        return new (t || _RawatJalanModule)();
      };

      _RawatJalanModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
        type: _RawatJalanModule
      });
      _RawatJalanModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
        imports: [[_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _rawat_jalan_routing_module__WEBPACK_IMPORTED_MODULE_0__.RawatJalanRoutingModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule, _registrasi_registrasi_module__WEBPACK_IMPORTED_MODULE_3__.RegistrasiModule]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](_RawatJalanModule, {
          declarations: [_rawat_jalan_component__WEBPACK_IMPORTED_MODULE_1__.RawatJalanComponent],
          imports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _rawat_jalan_routing_module__WEBPACK_IMPORTED_MODULE_0__.RawatJalanRoutingModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule, _registrasi_registrasi_module__WEBPACK_IMPORTED_MODULE_3__.RegistrasiModule]
        });
      })();
      /***/

    }
  }]);
})();
//# sourceMappingURL=src_app_modules_rawat-jalan_rawat-jalan_module_ts-es5.js.map