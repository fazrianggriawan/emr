import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kasir',
  templateUrl: './kasir.component.html',
  styleUrls: ['./kasir.component.css']
})
export class KasirComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
