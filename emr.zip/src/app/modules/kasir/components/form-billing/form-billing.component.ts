import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-billing',
  templateUrl: './form-billing.component.html',
  styleUrls: ['./form-billing.component.css']
})
export class FormBillingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
