import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-farmasi',
  templateUrl: './farmasi.component.html',
  styleUrls: ['./farmasi.component.css']
})
export class FarmasiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
