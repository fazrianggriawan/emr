import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-summary-review',
  templateUrl: './summary-review.component.html',
  styleUrls: ['./summary-review.component.css']
})
export class SummaryReviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
