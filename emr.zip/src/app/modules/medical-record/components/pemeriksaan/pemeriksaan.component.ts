import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pemeriksaan',
  templateUrl: './pemeriksaan.component.html',
  styleUrls: ['./pemeriksaan.component.css']
})
export class PemeriksaanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
