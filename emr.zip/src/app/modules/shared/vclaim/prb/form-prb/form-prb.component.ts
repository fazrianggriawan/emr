import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-form-prb',
    templateUrl: './form-prb.component.html',
    styleUrls: ['./form-prb.component.css']
})
export class FormPrbComponent implements OnInit {

    dataObat: any = [];

    constructor() { }

    ngOnInit(): void {
    }

}
