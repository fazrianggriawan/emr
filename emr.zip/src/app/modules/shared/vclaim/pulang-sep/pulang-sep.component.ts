import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-pulang-sep',
    templateUrl: './pulang-sep.component.html',
    styleUrls: ['./pulang-sep.component.css']
})
export class PulangSepComponent implements OnInit {

    dataSep: any;

    constructor(

    ) { }

    ngOnInit(): void {
    }

}
