import { DateHumanDirective } from './date-human.directive';

describe('DateHumanDirective', () => {
  it('should create an instance', () => {
    const directive = new DateHumanDirective();
    expect(directive).toBeTruthy();
  });
});
