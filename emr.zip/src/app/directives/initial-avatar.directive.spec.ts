import { InitialAvatarDirective } from './initial-avatar.directive';

describe('InitialAvatarDirective', () => {
  it('should create an instance', () => {
    const directive = new InitialAvatarDirective();
    expect(directive).toBeTruthy();
  });
});
