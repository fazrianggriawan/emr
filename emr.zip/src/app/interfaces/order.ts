export interface Order {
    orderId: String,
    customer: String,
    price: String,
    productId: String,
    category: String
}
