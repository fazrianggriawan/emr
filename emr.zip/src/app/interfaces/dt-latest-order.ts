export interface DtLatestOrder {
    code: String,
    name: String,
    category: String,
    quantity: String
}
