export interface Pasien {
    name: string,
    tglLahir: string,
    jnsKelamin: string
}
