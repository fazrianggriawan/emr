<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Farmasi extends Model
{
    protected $table = 'farmasi';
    protected $primaryKey = 'id';
}
