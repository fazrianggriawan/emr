<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Cppt extends Model
{
    protected $table = 'content_answer';
    protected $primaryKey = 'id';
}
